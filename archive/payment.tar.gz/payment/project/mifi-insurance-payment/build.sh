#!/bin/bash

set -e
set -x


JOB_ENV=$1

SCRIPT_DIR=`cd $(dirname $0); pwd -P`
cd $SCRIPT_DIR
rm -rf release/

#install dependent software and files
export SCRIPT_DIR
bash ./dependent.sh

CLUSTER=`python ./deploy-dependents/find_cluster.py ${JOB_ENV}`
SRV_GRP=`python ./deploy-dependents/find_cluster.py ${JOB_ENV} servicegroup`
SERVICE=`python ./deploy-dependents/find_cluster.py ${JOB_ENV} service`
PDL=`python ./deploy-dependents/find_cluster.py ${JOB_ENV} pdl`
rm -rf deploy-dependents/

# Uncomment the following lines to compile the src with jdk7
export JAVA_HOME_7=release/java
export JAVA_HOME=release/java
mvn -U clean package -D${CLUSTER}=true -D${CLUSTER}_${SRV_GRP}=true -D${SERVICE}=true

cp -rp deploy release/
cp -rp local_deploy/local_deploy.sh release/deploy/

TARGET_DIR=$(ls target/*.war|head -1 | sed -e's,.*\/,,' -e's,\.war,,' )
cp -r target/${TARGET_DIR}/* release/webapp/

mvn clean