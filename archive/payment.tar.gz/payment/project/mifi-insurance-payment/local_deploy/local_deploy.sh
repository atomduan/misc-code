echo you need a '- 127.0.0.1' in  /home/xbox/aesir/frigga/conf/ip.yml
HOST=${1:-127.0.0.1}

RELEASE_DIR=$(dirname `pwd`)

INSTALL_ROOT="/home/work/bin/"
prog_name=mifi-insurance-payment
PDL=FI
SRV=$prog_name
CLUSTER=${2:-onebox}

cat << EOF > cluster.conf
cluster:
  name: cop.xiaomi_owt.miui_pdl.${PDL}
  version: 1914
  env: ${CLUSTER}
  jobs:
    - job.${SRV}_service.${SRV}_cluster.${CLUSTER}_pdl.${PDL}_owt.miui_cop.xiaomi

job.${SRV}_service.${SRV}_cluster.${CLUSTER}_pdl.${PDL}_owt.miui_cop.xiaomi:
  tag: job.${SRV}_service.${SRV}_cluster.${CLUSTER}_pdl.${PDL}_owt.miui_cop.xiaomi
  host:
    - ${HOST}
  user: work
  version: 2a69e5ee9
  path: ${INSTALL_ROOT}/${SRV}/
  action: restart
  pkg_url: file://${RELEASE_DIR}
EOF


odin.rb -f cluster.conf -y



