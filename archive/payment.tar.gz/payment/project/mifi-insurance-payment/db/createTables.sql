USE mifi_insurance_payment;

CREATE TABLE IF NOT EXISTS pay_channel (
  `id`           BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT
  COMMENT '自增主键',
  `name`         VARCHAR(16)         NOT NULL
  COMMENT '支付渠道名称，如 alipay,wxpay',
  `display_name` VARCHAR(16)         NOT NULL
  COMMENT '支付渠道的显示名称，如 支付宝、微信支付',
  `icon_url`     VARCHAR(128)        NOT NULL DEFAULT ''
  COMMENT '图标URL',
  `channel_id`   TINYINT             NOT NULL
  COMMENT '支付渠道id，支付宝为1，微信为2，小米钱包为4',

  PRIMARY KEY (`id`),
  KEY `idx_pc_name` (`name`)
)
  ENGINE = InnoDB
  AUTO_INCREMENT = 1
  DEFAULT CHARSET = utf8;

CREATE TABLE IF NOT EXISTS channel_config (
  `id`         BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT
  COMMENT '自增主键',
  `channel_id` TINYINT             NOT NULL
  COMMENT '支付渠道id，支付宝为1，微信为2，小米钱包为4',
  `start_time` BIGINT              NOT NULL DEFAULT 0
  COMMENT '有效期起始时间',
  `end_time`   BIGINT              NOT NULL DEFAULT 0
  COMMENT '有效期结束时间',
  `trade_type` TINYINT             NOT NULL DEFAULT 0
  COMMENT '交易类型',
  `priority`   TINYINT             NOT NULL DEFAULT 0
  COMMENT '展示时的排序，值越大，排名越靠前',
  `subtitle`   VARCHAR(32)         NOT NULL DEFAULT ''
  COMMENT '显示在支付通道正文的子标题',
  `switch_on`  TINYINT             NOT NULL DEFAULT 0
  COMMENT '是否打开该渠道',

  PRIMARY KEY (`id`),
  KEY `idx_cc_tt_st_et` (`trade_type`, `start_time`, `end_time`)
)
  ENGINE = InnoDB
  AUTO_INCREMENT = 1
  DEFAULT CHARSET = utf8;

CREATE TABLE IF NOT EXISTS `trade_detail` (
  `id`             BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT
  COMMENT '自增id作为主键，无业务含义',
  `channel`        TINYINT(4) UNSIGNED NOT NULL DEFAULT 0
  COMMENT '支付渠道 1.支付宝 2.微信 4.小米钱包',
  `trade_type`     TINYINT(4) UNSIGNED NOT NULL DEFAULT 0
  COMMENT '交易类型 1.手动支付 2.代发 3.代扣',
  `trade_status`   TINYINT(4) UNSIGNED NOT NULL DEFAULT 0
  COMMENT '状态 0. 初始化 1. 等待支付 2. 成功 3. 取消 4. 关闭 5. 失败',
  `seller_id`      VARCHAR(128)        NOT NULL DEFAULT '0'
  COMMENT '卖家ID',
  `order_id`       BIGINT(20) UNSIGNED NOT NULL DEFAULT 0
  COMMENT '业务订单号',
  `transaction_id` BIGINT(20)          NOT NULL DEFAULT 0
  COMMENT '收银台支付流水号',
  `trade_id`       VARCHAR(64)         NOT NULL DEFAULT '0'
  COMMENT '第三方支付平台交易号',
  `total_fee`      BIGINT(20) UNSIGNED NOT NULL DEFAULT 0
  COMMENT '交易总金额，单位为分',
  `currency`       TINYINT(4) UNSIGNED NOT NULL DEFAULT 0
  COMMENT '币种 1. CNY(人民币)',
  `product_name`   VARCHAR(128)        NOT NULL DEFAULT ''
  COMMENT '商品名',
  `order_desc`     VARCHAR(128)        NOT NULL DEFAULT ''
  COMMENT '订单描述',
  `payment_status` TINYINT(4)          NOT NULL DEFAULT '0'
  COMMENT '支付状态 0.初始化 1.已提交 2.处理中 3.成功 4.失败 5.交易不存在 6.等待转账 7.超时关闭',
  `pay_time`       BIGINT(20)          NOT NULL DEFAULT '0'
  COMMENT '支付时间',
  `notify_id`      BIGINT(20)          NOT NULL DEFAULT '0'
  COMMENT '通知表id',
  `return_url`     VARCHAR(1024)       NOT NULL DEFAULT ''
  COMMENT '返回url',
  `error_desc`     VARCHAR(128)        NOT NULL DEFAULT ''
  COMMENT '错误描述',
  `error_code`     TINYINT(4) UNSIGNED NOT NULL DEFAULT 0
  COMMENT '错误码',
  `xiaomi_id`      BIGINT(20)                   DEFAULT 0
  COMMENT '小米ID',
  `pay_method`     TINYINT(4)                   DEFAULT 0
  COMMENT '支付方式',
  `expire_time`    BIGINT(20)          NOT NULL DEFAULT 0
  COMMENT '支付超时时间，单位为毫秒',
  `create_time`    BIGINT(20)          NOT NULL DEFAULT 0
  COMMENT '交易创建时间',
  `update_time`    BIGINT(20)          NOT NULL DEFAULT 0
  COMMENT '交易更新时间',
  `receive_time`   BIGINT(20)          NOT NULL DEFAULT 0
  COMMENT '支付机构通知返回的时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UK_TRANSACTION_ID` (`transaction_id`),
  UNIQUE KEY `UK_ORDER_ID` (`order_id`),
  KEY `IDX_TRADE_ID` (`trade_id`),
  KEY `IDX_CREATE_TIME` (`create_time`),
  KEY `IDX_UPDATE_TIME` (`update_time`),
  KEY `IDX_PAY_TIME` (`pay_time`),
  KEY `IDX_RECEIVE_TIME` (`receive_time`),
  KEY `IDX_EXPIRE_TIME` (`expire_time`)
)
  ENGINE = InnoDB
  DEFAULT CHARSET = utf8
  COMMENT = '交易支付详情表';

CREATE TABLE IF NOT EXISTS `refund_detail` (
  `id`                    BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT
  COMMENT '自增id作为主键，无业务含义',
  `channel`               TINYINT(4) UNSIGNED NOT NULL DEFAULT 0
  COMMENT '支付渠道',
  `trade_type`            TINYINT(4) UNSIGNED NOT NULL DEFAULT 0
  COMMENT '交易类型 1.手动支付 2.代发 3.代扣',
  `status`                TINYINT(4) UNSIGNED NOT NULL DEFAULT 0
  COMMENT '状态 0. 初始化 1. 等待支付 2. 成功 3. 取消 4. 关闭 5. 失败',
  `seller_id`             VARCHAR(128)        NOT NULL DEFAULT ''
  COMMENT '卖家ID',
  `order_id`              BIGINT(20) UNSIGNED NOT NULL DEFAULT 0
  COMMENT '业务订单号',
  `refund_transaction_id` BIGINT(20) UNSIGNED NOT NULL DEFAULT 0
  COMMENT '收银台退款流水号',
  `origin_transaction_id` BIGINT(20) UNSIGNED NOT NULL DEFAULT 0
  COMMENT '原订单收银台支付流水号',
  `refund_trade_id`       VARCHAR(64)         NOT NULL DEFAULT ''
  COMMENT '第三方支付平台退款交易号',
  `origin_trade_id`       VARCHAR(64)         NOT NULL DEFAULT ''
  COMMENT '原订单第三方支付平台交易号',
  `currency`              TINYINT(4) UNSIGNED NOT NULL DEFAULT 0
  COMMENT '币种 1. CNY(人民币)',
  `amount`                BIGINT(20) UNSIGNED NOT NULL DEFAULT 0
  COMMENT '交易总金额，单位为分',
  `refund_reason`         VARCHAR(128)        NOT NULL DEFAULT ''
  COMMENT '退款原因',
  `payment_status`        TINYINT(4)          NOT NULL DEFAULT '0'
  COMMENT '支付状态 0.初始化 1.已提交 2.处理中 3.成功 4.失败 5.交易不存在 6.等待转账 7.超时关闭',
  `refund_phase`          TINYINT(4)          NOT NULL DEFAULT '0'
  COMMENT '退款阶段',
  `pay_time`              BIGINT(20)          NOT NULL DEFAULT '0'
  COMMENT '支付时间',
  `error_code`            VARCHAR(128)        NOT NULL DEFAULT ''
  COMMENT '错误码',
  `expire_time`           BIGINT(20)          NOT NULL
  COMMENT '支付超时时间，单位为毫秒',
  `create_time`           BIGINT(20)          NOT NULL
  COMMENT '交易创建时间',
  `update_time`           BIGINT(20)          NOT NULL
  COMMENT '交易更新时间',
  `receive_time`          BIGINT(20)          NOT NULL DEFAULT 0
  COMMENT '支付机构通知返回的时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UIDX_REFUND_TRANSACTION_ID` (`refund_transaction_id`),
  UNIQUE KEY `UIDX_ORDER_ORITRANS_CHANNEL` (`order_id`, `origin_transaction_id`, `channel`),
  KEY `IDX_REFUND_TRADE_ID` (`refund_trade_id`),
  KEY `IDX_ORIGIN_REFUND_TRADE_ID` (`origin_trade_id`),
  KEY `IDX_CREATE_TIME` (`create_time`),
  KEY `IDX_UPDATE_TIME` (`update_time`),
  KEY `IDX_PAY_TIME` (`pay_time`),
  KEY `IDX_RECEIVE_TIME` (`receive_time`)
)
  ENGINE = InnoDB
  DEFAULT CHARSET = utf8
  COMMENT = '交易退款详情表';

CREATE TABLE IF NOT EXISTS `deduct_trade_detail` (
  `id`             BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT
  COMMENT '自增id作为主键，无业务含义',
  `deduct_id`      VARCHAR(64)         NOT NULL DEFAULT ''
  COMMENT '代扣单号',
  `bank_user_name` VARCHAR(128)        NOT NULL DEFAULT ''
  COMMENT '持卡人姓名',
  `bank_card_no`   VARCHAR(128)        NOT NULL DEFAULT ''
  COMMENT '银行账号',
  `bank_card_type` TINYINT(4) UNSIGNED NOT NULL DEFAULT 0
  COMMENT '银行卡类型 1.信用卡 2.借记卡',
  `cert_type`      TINYINT(4) UNSIGNED NOT NULL DEFAULT 0
  COMMENT '证件类型 1.身份证',
  `cert_no`        VARCHAR(128)        NOT NULL DEFAULT ''
  COMMENT '证件号码',
  `trade_status`   TINYINT(4) UNSIGNED NOT NULL DEFAULT 0
  COMMENT '状态 0. 初始化 1. 等待支付 2. 成功 3. 取消 4. 关闭 5. 失败',
  `transaction_id` BIGINT(20)          NOT NULL DEFAULT '0'
  COMMENT '收银台支付流水号',
  `trade_id`       VARCHAR(64)         NOT NULL DEFAULT ''
  COMMENT '第三方支付平台交易号',
  `total_fee`      BIGINT(20) UNSIGNED NOT NULL DEFAULT 0
  COMMENT '交易总金额，单位为分',
  `currency`       TINYINT(4) UNSIGNED NOT NULL DEFAULT 0
  COMMENT '币种 1. CNY(人民币)',
  `product_name`   VARCHAR(128)        NOT NULL DEFAULT ''
  COMMENT '商品名',
  `order_desc`     VARCHAR(128)        NOT NULL DEFAULT ''
  COMMENT '订单描述',
  `payment_status` TINYINT(4)          NOT NULL DEFAULT '0'
  COMMENT '支付状态 0.初始化 1.已提交 2.处理中 3.成功 4.失败 5.交易不存在 6.等待转账 7.超时关闭',
  `pay_time`       BIGINT(20)          NOT NULL DEFAULT '0'
  COMMENT '支付时间',
  `notify_id`      BIGINT(20)          NOT NULL DEFAULT '0'
  COMMENT '通知表id',
  `return_url`     VARCHAR(1024)       NOT NULL DEFAULT ''
  COMMENT '返回url',
  `error_desc`     VARCHAR(128)        NOT NULL DEFAULT ''
  COMMENT '错误描述',
  `error_code`     TINYINT(4) UNSIGNED NOT NULL DEFAULT 0
  COMMENT '错误码',
  `expire_time`    BIGINT(20)          NOT NULL DEFAULT 0
  COMMENT '支付超时时间，单位为毫秒',
  `create_time`    BIGINT(20)          NOT NULL DEFAULT 0
  COMMENT '交易创建时间',
  `update_time`    BIGINT(20)          NOT NULL DEFAULT 0
  COMMENT '交易更新时间',
  `receive_time`   BIGINT(20)          NOT NULL DEFAULT 0
  COMMENT '支付机构通知返回的时间',
  `order_id`       BIGINT(20),         NOT NULL DEFAULT 0
  COMMENT '业务的订单号',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UK_TRANSACTION_ID` (`transaction_id`),
  UNIQUE KEY `UK_DEDUCT_ID` (`deduct_id`),
  KEY `IDX_TRADE_ID` (`trade_id`),
  KEY `IDX_CREATE_TIME` (`create_time`),
  KEY `IDX_UPDATE_TIME` (`update_time`),
  KEY `IDX_PAY_TIME` (`pay_time`),
  KEY `IDX_RECEIVE_TIME` (`receive_time`),
  KEY `IDX_ORDER_ID` (`order_id`)
)
  ENGINE = InnoDB
  DEFAULT CHARSET = utf8
  COMMENT = '代扣支付详情表';

CREATE TABLE IF NOT EXISTS `support_channels` (
  `id`             BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT
  COMMENT '自增id作为主键，无业务含义',
  `order_id`       BIGINT(20) UNSIGNED NOT NULL DEFAULT 0
  COMMENT '业务订单号',
  `transaction_id` BIGINT(20)          NOT NULL DEFAULT '0'
  COMMENT '收银台支付流水号',
  `channel`        TINYINT(4) UNSIGNED NOT NULL DEFAULT 0
  COMMENT '支付渠道 1.支付宝 2.微信 4.小米钱包',
  `card_type`      TINYINT(4) UNSIGNED NOT NULL DEFAULT 0
  COMMENT '银行卡类型 1.借记卡 2.信用卡',
  PRIMARY KEY (`id`)
)
  ENGINE = InnoDB
  DEFAULT CHARSET = utf8
  COMMENT = '交易渠道表';

CREATE TABLE IF NOT EXISTS `notify` (
  `id`                  BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT
  COMMENT '自增id作为主键，无业务含义',
  `notify_id`           BIGINT(20)          NOT NULL DEFAULT '0',
  `trade_type`          TINYINT(4)          NOT NULL DEFAULT '0'
  COMMENT '交易类型 0.未知 1.支付 2.退款 3.代扣',
  `transaction_id`      BIGINT(20)          NOT NULL DEFAULT '0'
  COMMENT '收银台支付流水号',
  `notify_type`         TINYINT(4) UNSIGNED NOT NULL DEFAULT '0'
  COMMENT '回调通知类型 0.不回调 1.thrift 2.http',
  `notify_service_name` VARCHAR(1024)       NOT NULL DEFAULT ''
  COMMENT 'thrift 回调服务名',
  `notify_method_name`  VARCHAR(1024)       NOT NULL DEFAULT ''
  COMMENT 'thrift 回调方法名',
  `notify_url`          VARCHAR(1024)       NOT NULL DEFAULT ''
  COMMENT 'http 回调url',
  `notify_status`       TINYINT(4) UNSIGNED NOT NULL DEFAULT '0'
  COMMENT '回调通知状态 1.成功 2.重试中 3.放弃',
  `notify_retry_times`  INT(10) UNSIGNED    NOT NULL DEFAULT '0'
  COMMENT '回调重试次数',
  `notify_success_time` BIGINT(20)          NOT NULL DEFAULT '0'
  COMMENT '回调成功时间',
  `create_time`         BIGINT(20)          NOT NULL DEFAULT 0
  COMMENT '回调记录创建时间',
  `update_time`         BIGINT(20)          NOT NULL DEFAULT 0
  COMMENT '回调记录更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UK_NOTIFY_ID` (`notify_id`),
  KEY `IDX_TRANSACTION_ID` (`transaction_id`),
  KEY `IDX_CREATE_TIME` (`create_time`),
  KEY `IDX_UPDATE_TIME` (`update_time`)
)
  ENGINE = InnoDB
  DEFAULT CHARSET = utf8
  COMMENT = '回调通知详情表';


CREATE TABLE IF NOT EXISTS `daily_statistic` (
  `id`      BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '自增id作为主键，无业务含义',
  `date`        VARCHAR(32) NOT NULL DEFAULT '' COMMENT '帐期',
  `channel`     INT        UNSIGNED NOT NULL DEFAULT 0 COMMENT '支付渠道 0.未定 1.支付宝 2.微信 4.小米钱包 1024.全部',
  `type`        TINYINT(4) UNSIGNED NOT NULL DEFAULT 0 COMMENT '交易类型 1.付款 2.退款',
  `result_type` INT        UNSIGNED NOT NULL DEFAULT 0 COMMENT '状态 0.初始化 1.等待支付 2.成功 3.取消 4.关闭 5.失败 1024.全部',
  `count`       INT                 NOT NULL DEFAULT 0 COMMENT '统计数量',
  PRIMARY KEY (`id`),
  KEY `IDX_DATE` (`date`)
)
  ENGINE = InnoDB
  DEFAULT CHARSET = utf8
  COMMENT = '日报统计表';


  ALTER TABLE trade_detail ADD COLUMN `create_ip` VARCHAR(32) NOT NULL DEFAULT '' COMMENT 'IP地址';
  
  ALTER TABLE `notify` ADD COLUMN `next_notify_time` BIGINT(20) NOT NULL DEFAULT 0 COMMENT '下一次通知时间';
  ALTER TABLE `notify` ADD KEY `IDX_NEXT_NOTIFY_TIME` (`next_notify_time`);
