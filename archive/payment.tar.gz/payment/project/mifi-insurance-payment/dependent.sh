#!/bin/bash
set -e
set -x

CUR_DIR=`cd $(dirname $0); pwd -P`
DEP_DIR="$CUR_DIR/deploy-dependents"

if [ -e "$DEP_DIR" ]; then
    rm -rf "$DEP_DIR"
fi

git clone http://git.n.xiaomi.com/liuxuebing/deploy-dependents.git && cd $DEP_DIR && git checkout master

cd $CUR_DIR
mkdir -p release/webapp/
python $DEP_DIR/installer.py $CUR_DIR/software.conf

pushd $DEP_DIR/jmxmonitor
bash build.sh
popd

cp -r $DEP_DIR/jmxmonitor/release/libexec $CUR_DIR/release/
cp -r $DEP_DIR/libexec/ $CUR_DIR/release/