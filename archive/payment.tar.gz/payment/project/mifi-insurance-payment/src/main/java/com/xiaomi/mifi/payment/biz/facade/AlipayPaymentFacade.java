package com.xiaomi.mifi.payment.biz.facade;

import static com.xiaomi.mifi.payment.util.ConvertUtils.longToExpireTime;
import static com.xiaomi.mifi.payment.util.ResponseUtils.getTRRefundResponse;

import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.xiaomi.common.perfcounter.PerfCounter;
import com.xiaomi.mifi.common.thrift.model.TRResponse;
import com.xiaomi.mifi.payment.proxy.BServiceProxy;
import com.xiaomi.mifi.insurance.common.util.exception.ErrorCode;
import com.xiaomi.mifi.insurance.common.util.exception.ServiceLogicException;
import com.xiaomi.mifi.insurance.payment.thrift.CommitPaymentMethod;
import com.xiaomi.mifi.insurance.payment.thrift.PaymentRequestParam;
import com.xiaomi.mifi.insurance.payment.thrift.RefundRequestParam;
import com.xiaomi.mifi.payment.biz.NotifyBiz;
import com.xiaomi.mifi.payment.biz.RefundBiz;
import com.xiaomi.mifi.payment.biz.TradeBiz;
import com.xiaomi.mifi.payment.exception.PaymentGatewayResponseException;
import com.xiaomi.mifi.payment.gateway.AlipayPaymentGateway;
import com.xiaomi.mifi.payment.gateway.PaymentGateway;
import com.xiaomi.mifi.payment.model.CommitBindDeductRequest;
import com.xiaomi.mifi.payment.model.CommitBindDeductResult;
import com.xiaomi.mifi.payment.model.CommitDeductRequest;
import com.xiaomi.mifi.payment.model.CommitDeductResult;
import com.xiaomi.mifi.payment.model.CommitPayRequest;
import com.xiaomi.mifi.payment.model.CommitPayResult;
import com.xiaomi.mifi.payment.model.CommitRefundRequest;
import com.xiaomi.mifi.payment.model.CommitRefundResult;
import com.xiaomi.mifi.payment.model.PaymentChannel;
import com.xiaomi.mifi.payment.thrift.*;
import com.xiaomi.mifi.payment.util.ConvertUtils;

/**
 * Created by mars on 17-4-20.
 */
@Service
public class AlipayPaymentFacade extends AbstractPaymentFacade {
    private static final Logger LOGGER = LoggerFactory.getLogger(AlipayPaymentFacade.class);

    @Autowired
    private PaymentFacadeRegistry registry;

    @Autowired
    private AlipayPaymentGateway alipayPaymentGateway;

    @Autowired
    private RefundBiz refundBiz;

    @Autowired
    private NotifyBiz notifyBiz;

    @Autowired
    private TradeBiz tradeBiz;

    @Autowired
    @Qualifier("notifyAlipayUrlPattern")
    private String notifyUrl;

    @Autowired
    @Qualifier("urlAlipay")
    private String urlAlipay;

    @Autowired
    @Qualifier("counterReturnUrlAlipay")
    private String counterReturnUrlAlipay;

    @Autowired
    private BServiceProxy bServiceProxy;

    @PostConstruct
    public void init() {
        registry.register(this);
    }

    @Override
    public PaymentChannel getChannel() {
        return PaymentChannel.ALIPAY;
    }

    @Override
    public CommitPayRequest generatePayment(TradeDetail tradeDetail) {
        LOGGER.info("AlipayPaymentFacade.generatePayment, tradeDetail: {}", tradeDetail);
        CommitPayRequest commitPayRequest = new CommitPayRequest();
        commitPayRequest.setTransactionId(tradeDetail.getTransactionId());
        commitPayRequest.setGoodName(tradeDetail.getProductName());
        commitPayRequest.setOrderDesc(tradeDetail.getOrderDesc());
        commitPayRequest.setReturnUrl(counterReturnUrlAlipay);
        commitPayRequest.setExpireTime(tradeDetail.getExpireTime());
        commitPayRequest.setTotalFee(tradeDetail.getTotalFee());
        commitPayRequest.setNotifyUrl(notifyUrl);
        LOGGER.info("AlipayPaymentFacade.generatePayment, return commitPayRequest: {}", commitPayRequest);
        return commitPayRequest;
    }

    @Override
    public CommitPayResult commitPay(CommitPayRequest commitPayRequest) {
        LOGGER.info("AlipayPaymentFacade.commitPay commitPayRequest is {}", commitPayRequest);
        CommitPayResult commitPayResult = new CommitPayResult();
        Map<PaymentRequestParam, String> params = new HashMap<>();
        params.put(PaymentRequestParam.MERCHANT_TRANSACTION_ID, String.valueOf(commitPayRequest.getTransactionId()));
        params.put(PaymentRequestParam.PAY_SUBJECT, commitPayRequest.getGoodName());
        params.put(PaymentRequestParam.PAY_DESCRIPTION, commitPayRequest.getOrderDesc());
        params.put(PaymentRequestParam.NOTIFY_URL, commitPayRequest.getNotifyUrl());
        params.put(PaymentRequestParam.RETURN_URL, commitPayRequest.getReturnUrl());
        params.put(PaymentRequestParam.PAY_AMOUNT, getDecimalFormatFee(commitPayRequest.getTotalFee()));
        params.put(PaymentRequestParam.PAY_TIMEOUT, longToExpireTime(commitPayRequest.getExpireTime()));
        if (commitPayRequest.getAllowedCardType().contains(CardType.CREDIT)) {
            params.put(PaymentRequestParam.PAY_ALLOW_CREDIT_CARD, PaymentGateway.TRUE);
        }
        try {
            String parameters = alipayPaymentGateway.createPayRequest(params);
            commitPayResult.setSuccess(true);
            commitPayResult.setErrorCode(ErrorCode.SUCCESS);
            commitPayResult.setUrl(urlAlipay);
            commitPayResult.setParams(parameters);
            commitPayResult.setMethod(CommitPaymentMethod.FORM);
        } catch (ServiceLogicException | PaymentGatewayResponseException e) {
            LOGGER.error("alipayPaymentGateway.createPayRequest error, params: {}", params);
            commitPayResult.setSuccess(false);
            commitPayResult.setErrorCode(ErrorCode.INTERNAL_SERVER_ERROR);
            commitPayResult.setParams("");
        }
        LOGGER.info("AlipayPaymentFacade.commitPay result is {}", commitPayResult.getParams());
        return commitPayResult;
    }

    @Override
    public CommitRefundResult commitRefund(CommitRefundRequest commitRefundRequest) {
        LOGGER.info("AlipayPaymentFacade.commitRefund commitRefundRequest is {}", commitRefundRequest);
        CommitRefundResult commitRefundResult = new CommitRefundResult();
        Map<RefundRequestParam, String> params = new HashMap<>();
        params.put(RefundRequestParam.OUTER_ORDER_ID, String.valueOf(commitRefundRequest.getTradeTransactionId()));
        params.put(RefundRequestParam.TARDE_NO, commitRefundRequest.getOriginTradeId());
        params.put(RefundRequestParam.REFUND_AMOUNT, getDecimalFormatFee(commitRefundRequest.getRefundFee()));
        try {
            String response = alipayPaymentGateway.createRefundRequest(params);
            commitRefundResult = receiveAlipayRefundReturn(response, commitRefundRequest.getTradeTransactionId());
        } catch (ServiceLogicException | PaymentGatewayResponseException e) {
            LOGGER.error("alipayPaymentGateway.createRefundRequest error, params: {}", params);
            commitRefundResult.setSuccess(false);
            commitRefundResult.setErrorCode(ErrorCode.INTERNAL_SERVER_ERROR);
            commitRefundResult.setResponse("payment internal exception");
        }
        LOGGER.info("AlipayPaymentFacade.commitRefund result is ", commitRefundResult.getResponse());
        return commitRefundResult;
    }

    @Override
    public CommitBindDeductResult commitBindDeduct(CommitBindDeductRequest commitBindDeductRequest) {
        throw new UnsupportedOperationException("AlipayPaymentFacade dose not support commitBindDeduct!");
    }

    @Override
    public CommitDeductResult commitDeduct(CommitDeductRequest commitDeductRequest) {
        throw new UnsupportedOperationException("AlipayPaymentFacade dose not support commitBindDeduct!");
    }

    @Override
    public TRPayResponse convertCommitPayResult(CommitPayResult result) {
        throw new UnsupportedOperationException("AlipayPaymentFacade dose not support convertCommitPayResult!");
    }

    @Override
    public TRRefundResponse convertCommitRefundResult(CommitRefundResult commitRefundResult,
            RefundDetail refundDetail) {
        LOGGER.info("AlipayPaymentFacade.convertCommitRefundResult, commitRefundResult is {}, refundDetail is {}",
                commitRefundResult, refundDetail);
        if (commitRefundResult.isSuccess()) {
            return getTRRefundResponse(ErrorCode.SUCCESS, refundDetail);
        } else {
            // 这里单独返回支付宝退款同步返回结果中的错误信息,放入TRRefundResponse中
            TRResponse trResponse = new TRResponse();
            trResponse.setSuccess(false);
            trResponse.setCode(ErrorCode.REQUEST_FAILED.code);
            trResponse.setDesc(ErrorCode.REFUND_ERROR.externalDescription);
            trResponse.setBizContent(commitRefundResult.getResponse());
            return new TRRefundResponse(trResponse, refundDetail);
        }
    }

    @Override
    public void notifyRefund(Map<String, String> params) throws Exception {
        throw new UnsupportedOperationException("AlipayPaymentFacade does not support notifyRefund!");
    }

    @Override
    public boolean verifyPayParam(Map<String, String> params) {
        if (params == null) {
            return false;
        }

        if (params.get("notify_time") == null) {
            return false;
        }

        if (params.get("notify_type") == null) {
            return false;
        }

        if (params.get("notify_id") == null) {
            return false;
        }

        if (params.get("app_id") == null) {
            return false;
        }

        if (params.get("charset") == null) {
            return false;
        }

        if (params.get("version") == null) {
            return false;
        }

        if (params.get("sign_type") == null) {
            return false;
        }

        if (params.get("sign") == null) {
            return false;
        }

        if (params.get("trade_no") == null) {
            return false;
        }

        if (params.get("out_trade_no") == null) {
            return false;
        }

        return true;
    }

    private boolean verifyReturnUrlParam(Map<String, String> params) {
        if (params == null) {
            return false;
        }

        if (params.get("method") == null) {
            return false;
        }

        if (params.get("timestamp") == null) {
            return false;
        }

        if (params.get("app_id") == null) {
            return false;
        }

        if (params.get("charset") == null) {
            return false;
        }

        if (params.get("version") == null) {
            return false;
        }

        if (params.get("sign_type") == null) {
            return false;
        }

        if (params.get("sign") == null) {
            return false;
        }

        if (params.get("trade_no") == null) {
            return false;
        }

        if (params.get("out_trade_no") == null) {
            return false;
        }

        if (params.get("total_amount") == null) {
            return false;
        }

        return alipayPaymentGateway.parseReturnUrl(params);
    }

    @Override
    public TradeDetail getTradeDetailFromReturnParam(Map<String, String> params) throws ServiceLogicException{
        boolean isVerify = verifyReturnUrlParam(params);
        long transactionId = 0;
        if (isVerify) {
            transactionId = alipayPaymentGateway.getTransactionIdFromReturnMap(params);
        } else {
            LOGGER.warn("AlipayPaymentFacade.verifyReturnUrlParam return false, params: {}", params);
            throw ServiceLogicException.INVALID_PARAM;
        }
        return tradeBiz.findByTransactionId(transactionId);
    }

    @Override
    public boolean verifyRefundParam(Map<String, String> params) {
        throw new UnsupportedOperationException("AlipayPaymentFacade dose not support verifyRefundParam!");
    }

    private String getDecimalFormatFee(long totalFee) {
        DecimalFormat df = new DecimalFormat("#.##");
        df.setRoundingMode(RoundingMode.UNNECESSARY);
        return df.format(totalFee / 100.0);
    }

    @Transactional(propagation = Propagation.NOT_SUPPORTED)
    public CommitRefundResult receiveAlipayRefundReturn(String response, long outerTransactionId) {
        CommitRefundResult commitRefundResult = new CommitRefundResult();
        JsonObject jo = new JsonParser().parse(response).getAsJsonObject().get("alipay_trade_refund_response")
                .getAsJsonObject();
        if (jo == null) {
            LOGGER.error("refund response is null");
            commitRefundResult.setSuccess(false);
            commitRefundResult.setErrorCode(ErrorCode.PARAMETER_ERROR);
            commitRefundResult.setResponse("refund response is null");
            PerfCounter.count("AlipayRefundReturnResponseIsNull", 1);
            return commitRefundResult;
        }
        int code = jo.get("code").getAsInt();
        // 这里10000是支付宝的成功响应码,其余为支付宝的错误码,这里将其原样返回,并且暂时不将退款状态改为失败,允许其重试.
        if (code == 10000) {
            long refundFee = jo.get("refund_fee").getAsString() != null
                    ? ConvertUtils.parseDecimalString(jo.get("refund_fee").getAsString()) : -1L;
            long refundTime = jo.get("gmt_refund_pay").getAsString() != null
                    ? ConvertUtils.strToTimestamp2(jo.get("gmt_refund_pay").getAsString()) : -1L;
            long originTradeTransactionId = jo.get("out_trade_no").getAsString() != null
                    ? Long.parseLong(jo.get("out_trade_no").getAsString()) : 0L;
            String tradeId = jo.get("trade_no").getAsString();
            if (refundFee < 0 || refundTime < 0 || originTradeTransactionId <= 0 || tradeId == null || tradeId.length() == 0) {
                commitRefundResult.setSuccess(false);
                commitRefundResult.setErrorCode(ErrorCode.REQUEST_FAILED);
                commitRefundResult.setResponse("alipay return parameter error");
                RefundDetail refundDetail = refundBiz.findRefundByTradeTransactionId(outerTransactionId);
                if (refundDetail != null) {
                    refundDetail.setPaymentStatus(PaymentStatus.FAIL.getValue());
                    refundDetail.setStatus(TradeStatus.FAIL.getValue());
                    refundBiz.updateRefundDetail(refundDetail);
                } else {
                    LOGGER.error("refund detail not found, refund transactionId: {}", outerTransactionId);
                }
                notifyBiz.sendRefundNotify(outerTransactionId);
                PerfCounter.count("AlipayRefundReturnParameterError", 1);
                return commitRefundResult;
            }
            RefundDetail refundDetail = refundBiz.findRefundByTradeTransactionId(originTradeTransactionId);
            if (refundDetail.getStatus() == TradeStatus.SUCCESS.getValue()
                    && refundDetail.getPaymentStatus() == PaymentStatus.SUCCESS.getValue()) {
                commitRefundResult.setSuccess(true);
                commitRefundResult.setErrorCode(ErrorCode.REPEATED_REFUND);
                commitRefundResult.setResponse("Refund is already success.");
                PerfCounter.count("AlipayRefundReturnAlreadySucceed", 1);
                return commitRefundResult;
            }
            if (refundDetail.getAmount() == refundFee) {
                refundDetail.setPaymentStatus(PaymentStatus.SUCCESS.getValue());
                refundDetail.setStatus(TradeStatus.SUCCESS.getValue());
                refundDetail.setUpdateTime(System.currentTimeMillis());
                refundDetail.setReceiveTime(System.currentTimeMillis());
                refundDetail.setPayTime(refundTime);
                refundDetail.setRefundTradeId(tradeId);
                // 这里先更新退款表的状态,不用等通知一定成功,也不用加事务处理
                refundBiz.updateRefundDetail(refundDetail);
                notifyBiz.sendRefundNotify(originTradeTransactionId);
                commitRefundResult.setSuccess(true);
                commitRefundResult.setErrorCode(ErrorCode.SUCCESS);
                commitRefundResult.setResponse(refundDetail.toString());
                PerfCounter.count("AlipayRefundReturnSucceed", 1);
                PerfCounter.countDuration("AlipayRefundDuration", bServiceProxy.getTimestamp() - refundDetail.getCreateTime());
                return commitRefundResult;
            } else {
                refundDetail.setPaymentStatus(PaymentStatus.FAIL.getValue());
                refundDetail.setStatus(TradeStatus.FAIL.getValue());
                refundBiz.updateRefundDetail(refundDetail);
                notifyBiz.sendRefundNotify(originTradeTransactionId);
                commitRefundResult.setSuccess(false);
                commitRefundResult.setErrorCode(ErrorCode.REFUND_ERROR);
                commitRefundResult.setResponse(jo.toString());
                PerfCounter.count("AlipayRefundReturnFeeNotMatch", 1);
                PerfCounter.countDuration("AlipayRefundDuration", bServiceProxy.getTimestamp() - refundDetail.getCreateTime());
                return commitRefundResult;
            }
        } else {
            PerfCounter.count("AlipayRefundReturnFail", 1);
            LOGGER.error("Alipay refund return fail, msg is {}", jo);
            commitRefundResult.setSuccess(false);
            commitRefundResult.setErrorCode(ErrorCode.REFUND_ERROR);
            commitRefundResult.setResponse(jo.toString());
            RefundDetail refundDetail = refundBiz.findRefundByTradeTransactionId(outerTransactionId);
            if (refundDetail != null) {
                refundDetail.setPaymentStatus(PaymentStatus.FAIL.getValue());
                refundDetail.setStatus(TradeStatus.FAIL.getValue());
                refundBiz.updateRefundDetail(refundDetail);
            } else {
                LOGGER.error("refund detail not found, refund transactionId: {}", outerTransactionId);
            }
            notifyBiz.sendRefundNotify(outerTransactionId);
            return commitRefundResult;
        }
    }
}
