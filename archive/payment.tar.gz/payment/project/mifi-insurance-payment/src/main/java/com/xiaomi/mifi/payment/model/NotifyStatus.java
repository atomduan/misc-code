package com.xiaomi.mifi.payment.model;

public enum NotifyStatus {

    PENDING(11), SENDING(12), SUCCESS(13), FAIL(14)
    ;
    private int value;

    NotifyStatus(int value) {
        this.value = value;
    }

    public int getValue() {
        return value;
    }
}
