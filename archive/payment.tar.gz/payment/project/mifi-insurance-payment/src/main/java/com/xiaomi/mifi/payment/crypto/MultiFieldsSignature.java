package com.xiaomi.mifi.payment.crypto;

import java.util.Map;

public interface MultiFieldsSignature {

    String sign(Map<String, String> params);

    boolean verify(Map<String, String> params, String sign);

    byte[] sign(byte[] data);

    boolean verify(byte[] data, byte[] sign);

}
