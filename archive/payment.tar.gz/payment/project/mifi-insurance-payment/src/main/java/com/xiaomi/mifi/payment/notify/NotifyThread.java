package com.xiaomi.mifi.payment.notify;

import java.util.List;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.xiaomi.mifi.insurance.common.util.filter.MDCUtils;
import com.xiaomi.mifi.payment.biz.NotifyBiz;
import com.xiaomi.mifi.payment.model.NotifyStatus;
import com.xiaomi.mifi.payment.thrift.Notify;

public class NotifyThread {

    private static final Logger LOGGER = LoggerFactory.getLogger(NotifyThread.class);

    private static ExecutorService executors = null;

    private static final int DEFAULT_THREAD_COUNT = 5;

    private volatile static boolean started = false;

    private static ConcurrentLinkedQueue<Notify> queue = new ConcurrentLinkedQueue<Notify>();

    @Autowired
    NotifyBiz notifyBiz;

    public NotifyThread(int threadCount) {
        executors = Executors.newFixedThreadPool(threadCount);
    }

    public NotifyThread() {
        this(DEFAULT_THREAD_COUNT);
    }

    public void addTask(Notify request) {
        LOGGER.info("receive task thirftNotifyRequest {}", request);
        queue.add(request);
    }

    public void startThread() {
        new Thread(new Runnable() {
            public void run() {
                LOGGER.info("Notify Thread starting");
                started = true;
                while (started) {
                    try {
                        refreshNotifyRequest();

                        Notify request = null;
                        while ((request = queue.poll()) != null) {
                            executors.submit(new Worker(request));
                        }
                    } catch (Exception e) {
                        LOGGER.info("Notify Thread exception ", e);
                    }

                    try {
                        Thread.sleep(1000);
                    } catch (InterruptedException e) {
                    }
                }
            }
        }).start();
    }

    public void stopThread() {
        LOGGER.info("Notify Thread stoping, queue size {}", queue.size());
        started = false;
    }

    public void refreshNotifyRequest() {
        List<Notify> pendingList = notifyBiz.findPendingNotify(System.currentTimeMillis() - 10000);
        for (Notify notify : pendingList) {
            if (notifyBiz.updateNotifyStatus(notify.getNotifyId(), NotifyStatus.PENDING.getValue(),
                    NotifyStatus.SENDING.getValue()) > 0) {
                addTask(notify);
            }
        }

        List<Notify> sendingFailList = notifyBiz.findSendingNotify(System.currentTimeMillis() - 30000); // 通知过程超过30s
        for (Notify notify : sendingFailList) {
            notify.setNotifyStatus(NotifyStatus.PENDING.getValue());
            notify.setUpdateTime(System.currentTimeMillis());
            notify.setNextNotifyTime(System.currentTimeMillis());
            notifyBiz.updateNotify(notify);
        }
    }

    class Worker implements Runnable {
        private Notify notify;

        public Worker(Notify notify) {
            this.notify = notify;
        }

        @Override
        public void run() {
            try {
                MDCUtils.putSessionId("notify_" + notify.getNotifyId());
                LOGGER.info("notify info {}", notify);
                notifyBiz.notifyOrder(notify);
                LOGGER.info("notify success");
            } catch (Throwable t) {
                LOGGER.error("exception on worker ", t);
                notify.setNotifyStatus(NotifyStatus.PENDING.getValue());
                notify.setUpdateTime(System.currentTimeMillis());
                notifyBiz.updateNotify(notify);
                LOGGER.info("notify failed, update notify status");
            } finally {
                MDCUtils.clearSessionId();
            }
        }
    }
}
