package com.xiaomi.mifi.payment.queue;

/**
 * Created by mars on 17-5-4.
 */
public enum QueueType {
    NOTIFY, RECEIVE_REFUND,
}
