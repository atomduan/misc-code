package com.xiaomi.mifi.payment.thrift;

import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.apache.thrift.TException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.xiaomi.jack.annotation.ThriftService;
import com.xiaomi.mifi.common.thrift.model.TRResponse;
import com.xiaomi.mifi.insurance.payment.thrift.*;
import com.xiaomi.mifi.insurance.payment.thrift.DeductTradeDetail;
import com.xiaomi.mifi.insurance.payment.thrift.RefundDetail;
import com.xiaomi.mifi.insurance.payment.thrift.TradeDetail;
import com.xiaomi.mifi.payment.notify.NotifyThread;
import com.xiaomi.mifi.payment.service.ServiceProxy;
import com.xiaomi.miliao.common.Stopable;
import com.xiaomi.miliao.thrift.MiliaoSharedServiceBase;

@Service
@ThriftService
public class MifiInsurancePaymentServiceImpl extends MiliaoSharedServiceBase
        implements MifiInsurancePaymentService.Iface, Stopable {

    private static final Logger LOGGER = LoggerFactory.getLogger(MifiInsurancePaymentServiceImpl.class);

    @Autowired
    NotifyThread notifyThread;

    @Autowired
    ServiceProxy serviceProxy;

    @PostConstruct
    public void init() {
        LOGGER.info("MifiInsurancePaymentService is started.");
    }

    @Override
    public TRWithdrawResponse requestWithdraw(TPWithdrawRequest request) throws TException {
        return serviceProxy.requestWithdraw(request);
    }

    @Override
    public TRQueryBill queryMerchantBill(TPQueryBill param) throws TException {
        return serviceProxy.queryMerchantBill(param);
    }

    @Override
    public TRQueryCounterInfo queryCounterInfo(TPQueryCounterInfo param) throws TException {
        return serviceProxy.queryCounterInfo(param);
    }

    @Override
    public TRSubmitPayment submitPayment(TPSubmitPayment param) throws TException {
        return serviceProxy.submitPayment(param);
    }

    @Override
    public boolean notifyCashpayPay(Map<String, String> params) {
        return serviceProxy.notifyCashpayPay(params);
    }

    @Override
    public boolean notifyCashpayRefund(Map<String, String> params) {
        return serviceProxy.notifyCashpayRefund(params);
    }

    @Override
    public boolean asyncNotifyAlipayPay(Map<String, String> params) {
        return serviceProxy.notifyAlipayPay(params);
    }

    @Override
    public TRReturnResponse receiveReturnUrl(Map<String, String> tpReturnParam) {
        return serviceProxy.receiveReturnUrl(tpReturnParam);
    }

    @Override
    public TRExpireTradesResponse queryExpiredTrades(int offset, int length) throws TException {
        return serviceProxy.queryExpiredTrades(offset, length);
    }

    @Override
    public TRResponse setTradeExpired(long transactionId) throws TException {
        return serviceProxy.setTradeExpired(transactionId);
    }

    @Override
    public TRQueryOrderStatus queryOrderStatus(long orderId) throws TException {
        return serviceProxy.queryOrderStatus(orderId);
    }

    @Override
    public TRResponse setChannel(int channelId, boolean switchOn) throws TException {
        return serviceProxy.setChannelSwitch(channelId, switchOn);
    }

    @Override
    public TRQueryChannelConfig queryChannelConfig() throws TException {
        return serviceProxy.queryChannelConfig();
    }

    @Override
    public TRTradeDetails queryDailyTrade(long startTime, int offset, int length) throws TException {
        return serviceProxy.queryDailyTrade(startTime, offset, length);
    }

    @Override
    public TRRefundDetails queryDailyRefund(long startTime, int offset, int length) throws TException {
        return serviceProxy.queryDailyRefund(startTime, offset, length);
    }

    @Override
    public boolean reportDailyStatistic(List<PaymentStatistic> paymentStatistic) throws TException {
        return serviceProxy.reportDailyStatistic(paymentStatistic);
    }

    @Override
    public List<PaymentStatistic> queryAllPaymentStatistic(int offset, int length) {
        return serviceProxy.queryAllPaymentStatistic(offset, length);
    }

    @Override
    public List<PaymentStatistic> queryPaymentStatisticByDate(String date) {
        return serviceProxy.queryPaymentStatisticByDate(date);
    }

    public String asyncNotifyWeixinPay(String response) throws TException {
        return serviceProxy.nofityWeixinPay(response);
    }

    @Override
    public boolean notifyCashpayDeduct(String logId, Map<String, String> params) throws TException {
        return serviceProxy.notifyCashpayDeduct(params);
    }

    @Override
    public boolean notifyCashpayDeductSign(String logId, Map<String, String> params) throws TException {
        return false;
    }

    @Override
    public TRResponse notifyBusiness(String logId, String type, long orderId) throws TException {
        return serviceProxy.notifyBusiness(type, orderId);
    }

    @Override
    public List<DeductTradeDetail> queryDeductTradeNoNotify(String logId, long time) throws TException {
        return serviceProxy.getDeductTradeNoNotify(time);
    }

    @Override
    public List<RefundDetail> queryRefundNoNotify(String logId, long time) throws TException {
        return serviceProxy.getRefundNoNotify(time);
    }

    @Override
    public List<TradeDetail> queryTradeNoNotify(String logId, long time) throws TException {
        return serviceProxy.getTradeNoNotify(time);
    }

    @Override
    public void stop() {
        notifyThread.stopThread();
        LOGGER.warn("MifiInsurancePaymentService is stopped");
    }

}
