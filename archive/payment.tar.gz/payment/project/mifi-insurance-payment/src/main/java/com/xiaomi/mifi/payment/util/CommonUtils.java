package com.xiaomi.mifi.payment.util;

/**
 * Created by mars on 17-4-21.
 */
public class CommonUtils {
    public static final long TIME_SPAN_ONE_HOUR = 60 * 60 * 1000L;
    public static final String CHARSET_UTF8 = "UTF-8";
}
