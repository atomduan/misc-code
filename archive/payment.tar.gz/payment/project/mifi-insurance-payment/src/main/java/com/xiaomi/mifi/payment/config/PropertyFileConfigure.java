package com.xiaomi.mifi.payment.config;

import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.FileConfiguration;
import org.apache.commons.configuration.PropertiesConfiguration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;

@Service
public class PropertyFileConfigure implements Configure {

    private static final Logger LOGGER = LoggerFactory
            .getLogger(PropertyFileConfigure.class);

    private FileConfiguration configFile;

    private String file;

    @PostConstruct
    public void init() {
        file = "config.properties";
        load();
    }

    @Override
    public int getInt(String key, int defaultValue) {
        return configFile.getInt(key, defaultValue);
    }

    @Override
    public int getInt(String key) {
        return configFile.getInt(key, 0);
    }

    @Override
    public String getString(String key) {
        String value = configFile.getString(key);
        if (value != null) {
            value = value.trim();
        }
        return value;
    }

    @Override
    public String[] getStringArray(String key) {
        return configFile.getStringArray(key);
    }

    @Override
    public boolean getBoolean(String key, boolean defaultValue) {
        return configFile.getBoolean(key, defaultValue);
    }

    @Override
    public boolean getBoolean(String key) {
        return configFile.getBoolean(key, false);
    }

    private void load() {
        try {
            configFile = new PropertiesConfiguration();
            configFile.setEncoding("UTF-8");
            configFile.load(file);
            LOGGER.info("load file from: {}", file);
        } catch (ConfigurationException e) {
            LOGGER.error("failed to load config file", e);
            throw new IllegalStateException("failed to load config file");
        }
    }
}
