
package com.xiaomi.mifi.payment.dao;

import com.xiaomi.mifi.insurance.payment.thrift.PaymentStatistic;
import net.paoding.rose.jade.annotation.DAO;
import net.paoding.rose.jade.annotation.ReturnGeneratedKeys;
import net.paoding.rose.jade.annotation.SQL;

import java.util.List;

/**
 * Created by mars on 17-5-26.
 */
@DAO
public interface DailyStatisticDAO {
    String TABLE_NAME = "daily_statistic";

    String IFColumns = "date, channel, type, result_type, count";

    String INSERT_VALUES = ":1.date, :1.channel, :1.type, :1.resultType, :1.count";

    String SELECT_COLUMNS = "id, " + IFColumns;

    @SQL("SELECT " + SELECT_COLUMNS + " FROM " + TABLE_NAME + " WHERE `date`=:1")
    List<PaymentStatistic> queryByDate(String date);

    @ReturnGeneratedKeys
    @SQL("INSERT INTO " + TABLE_NAME + "(" + IFColumns + ")VALUES(" + INSERT_VALUES + ")")
    long insert(PaymentStatistic paymentStatistic);

    @SQL("SELECT " + SELECT_COLUMNS + " FROM " + TABLE_NAME + " limit :1, :2")
    List<PaymentStatistic> queryAll(int offset, int length);
}
