package com.xiaomi.mifi.payment.biz;

import com.xiaomi.common.perfcounter.PerfCounter;
import com.xiaomi.mifi.common.utils.queue.DelayQueue;
import com.xiaomi.mifi.common.utils.queue.Task;
import com.xiaomi.mifi.payment.model.ThriftNotifyRequest;
import com.xiaomi.mifi.payment.queue.NotifyTask;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

/**
 * Created by mars on 17-5-3.
 */
@Deprecated
@Service
public class AsyncTaskBiz {
    private static final Logger LOGGER = LoggerFactory.getLogger(AsyncTaskBiz.class);

    // @Resource(name = "delayQueue")
    // private DelayQueue delayQueue;

    void addTask(Task task) throws Exception {
        LOGGER.info("asyncTaskBiz.addTask is invoked, task: {}", task);
        PerfCounter.count("AsyncTaskAddTaskTimes", 1);
        // delayQueue.addTask(task);
    }

    public void addNotifyTask(ThriftNotifyRequest thriftNotifyRequest) {
        LOGGER.info("AsyncTaskBiz.addNotifyTask, thriftNotifyRequest:{}", thriftNotifyRequest);
        NotifyTask notifyTask = new NotifyTask();
        notifyTask.setThriftNotifyRequest(thriftNotifyRequest);
        try {
            addTask(notifyTask);
        } catch (Exception ex) {
            LOGGER.error("add notifyTask fail, notifyTask: {}, exception: ", notifyTask, ex);
        }
    }
}
