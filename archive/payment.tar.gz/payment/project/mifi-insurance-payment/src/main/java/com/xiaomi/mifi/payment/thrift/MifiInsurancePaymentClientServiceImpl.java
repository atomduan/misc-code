package com.xiaomi.mifi.payment.thrift;

import javax.annotation.PostConstruct;

import org.apache.thrift.TException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.xiaomi.jack.annotation.ThriftService;
import com.xiaomi.mifi.payment.service.ClientServiceProxy;
import com.xiaomi.mifi.payment.service.ServiceProxy;
import com.xiaomi.miliao.common.Stopable;
import com.xiaomi.miliao.thrift.MiliaoSharedServiceBase;

/**
 * Created by mars on 17-4-18.
 */
@Service
@ThriftService
public class MifiInsurancePaymentClientServiceImpl extends MiliaoSharedServiceBase
        implements MifiInsurancePaymentClientService.Iface, Stopable {
    private static final Logger LOGGER = LoggerFactory.getLogger(MifiInsurancePaymentClientServiceImpl.class);

    @Autowired
    private ServiceProxy serviceProxy;

    @Autowired
    ClientServiceProxy clientServiceProxy;

    @PostConstruct
    public void init() {
        LOGGER.info("MifiInsurancePaymentClientService is started.");
    }

    @Override
    public TRPayResponse commitPay(TPPay tpPay) throws TException {
        return clientServiceProxy.commitPay(tpPay);
    }

    @Override
    public TRRefundResponse refund(TPRefund tpRefund) throws TException {
        return serviceProxy.refund(tpRefund);
    }

    @Override
    public TRTradeDetail queryPaymentInfo(long orderId) throws TException {
        return serviceProxy.queryPaymentInfo(orderId);
    }

    @Override
    public TRTradeDetailList queryTradeDetailsUsingPage(long beginTime, long endTime, TradeStatus tradeStatus, int offset, int length)
            throws TException {
        return serviceProxy.queryTradeDetails(beginTime, endTime, tradeStatus, offset, length);
    }

    @Override
    public TRTradeDetailList queryTradeDetails(long beginTime, long endTime, TradeStatus tradeStatus)
            throws TException {
        return serviceProxy.queryTradeDetails(beginTime, endTime, tradeStatus, 0, 100);
    }

    @Override
    public TRTradeDetailList querySuccessTradeDetails(long beginTime, long endTime, int channel) throws TException {
        return serviceProxy.querySuccessTradeDetails(beginTime, endTime, channel);
    }

    @Override
    public TRRefundDetailList querySuccessRefundDetails(long beginTime, long endTime, int channel) throws TException {
        return serviceProxy.querySuccessRefundDetails(beginTime, endTime, channel);
    }

    @Override
    public TRDetailListResponse querySuccessTradeRefundDetails(TRDetailListRequest request)
            throws TException {
        LOGGER.info("MifiInsurancePaymentClientServiceImp.querySuccessTradeRefundDetails is invoked, param is {} {} {}",
                request.getBeginTime(), request.getEndTime(), request.getTradeType());
        return serviceProxy.querySuccessTradeRefundDetails(request);
    }

    @Override
    public TRDeduct commitDeduct(String logId, TPDeduct params) throws TException {
        LOGGER.info("commit deduct params {}", params);
        return clientServiceProxy.commitDeduct(params);
    }

    @Override
    public TRDeductSign createDeductSign(String logId, TPDeductSign params) throws TException {
        LOGGER.info("create deduct sign params {}", params);
        TRDeductSign result = clientServiceProxy.createDeductSign(params);
        LOGGER.info("create deduct sign result {}", result);
        return result;
    }

    @Override
    public void stop() {
        LOGGER.info(this.getClass().getSimpleName() + "service is stopped.");
    }
}
