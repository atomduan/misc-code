package com.xiaomi.mifi.payment.util;

import com.xiaomi.mifi.common.thrift.model.TRResponse;
import com.xiaomi.mifi.insurance.common.util.exception.ErrorCode;
import com.xiaomi.mifi.insurance.common.util.exception.ServiceLogicException;
import com.xiaomi.mifi.insurance.payment.thrift.CommitPaymentMethod;
import com.xiaomi.mifi.insurance.payment.thrift.TRReturnResponse;
import com.xiaomi.mifi.insurance.payment.thrift.TRSubmitPayment;
import com.xiaomi.mifi.insurance.payment.thrift.TRSubmitPaymentData;
import com.xiaomi.mifi.payment.exception.PaymentGatewayResponseException;
import com.xiaomi.mifi.payment.thrift.RefundDetail;
import com.xiaomi.mifi.payment.thrift.TRPayResponse;
import com.xiaomi.mifi.payment.thrift.TRRefundResponse;

public class ResponseUtils {

    private static final TRResponse RESPONSE_SUCCESS = getResponse(ErrorCode.SUCCESS);

    public static TRResponse getSuccessResponse() {
        return RESPONSE_SUCCESS;
    }

    public static TRResponse getResponse(ServiceLogicException e) {
        return getResponse(e.errorCode);
    }

    public static TRResponse getResponse(PaymentGatewayResponseException e) {
        TRResponse trResponse = new TRResponse();
        trResponse.setSuccess(false);
        trResponse.setCode(ErrorCode.REQUEST_FAILED.REQUEST_FAILED.code);
        trResponse.setDesc(ErrorCode.REQUEST_FAILED.internalDescription);
        trResponse.setBizContent(e.getResponseCode());

        return trResponse;
    }

    public static TRResponse getResponse(ErrorCode errorCode) {
        TRResponse trResponse = new TRResponse();
        trResponse.setSuccess(errorCode == ErrorCode.SUCCESS);
        trResponse.setCode(errorCode.code);
        trResponse.setDesc(errorCode.internalDescription);
        return trResponse;
    }

    public static TRPayResponse getTRPayResponse(ErrorCode errorCode, String url) {
        return new TRPayResponse(getResponse(errorCode), url);
    }

    public static TRRefundResponse getTRRefundResponse(ErrorCode errorCode, RefundDetail refundDetail) {
        return new TRRefundResponse(getResponse(errorCode), refundDetail);
    }

    public static TRSubmitPayment getTRSubmitPayment(ErrorCode errorCode, CommitPaymentMethod method, String url, String parameters) {
        return new TRSubmitPayment(getResponse(errorCode), new TRSubmitPaymentData(method, url, parameters));
    }

    public static TRReturnResponse getTRReturnResponse(ErrorCode errorCode, String url) {
        return new TRReturnResponse(getResponse(errorCode), url);
    }
}
