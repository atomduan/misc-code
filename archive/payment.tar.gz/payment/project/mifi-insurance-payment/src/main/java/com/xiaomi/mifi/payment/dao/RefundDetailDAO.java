package com.xiaomi.mifi.payment.dao;

import java.util.List;

import com.xiaomi.mifi.payment.thrift.RefundDetail;

import net.paoding.rose.jade.annotation.DAO;
import net.paoding.rose.jade.annotation.ReturnGeneratedKeys;
import net.paoding.rose.jade.annotation.SQL;
import net.paoding.rose.jade.annotation.UseMaster;

/**
 * Created by mars on 17-4-20.
 */
@DAO
public interface RefundDetailDAO {

    String TABLE_NAME = "refund_detail";

    String IFColumns = "channel, trade_type, status, seller_id, order_id, refund_transaction_id, origin_transaction_id, refund_trade_id, origin_trade_id, currency, amount, refund_reason, payment_status, refund_phase, pay_time, error_code, expire_time, create_time, update_time, receive_time";

    String IFFields = ":1.id, :1.channel, :1.tradeType, :1.status, :1.sellerId, :1.orderId, :1.refundTransactionId, :1.originTransactionId, :1.refundTradeId, :1.originTradeId, :1.currency, :1.amount, :1.refundReason, :1.paymentStatus, :1.refundPhase, :1.payTime, :1.errorCode, :1.expireTime, :1.createTime, :1.updateTime, :1.receiveTime";

    String INSERT_VALUES = ":1.channel, :1.tradeType, :1.status, :1.sellerId, :1.orderId, :1.refundTransactionId, :1.originTransactionId, :1.refundTradeId, :1.originTradeId, :1.currency, :1.amount, :1.refundReason, :1.paymentStatus, :1.refundPhase, :1.payTime, :1.errorCode, :1.expireTime, :1.createTime, :1.updateTime, :1.receiveTime";

    String IFUpdate = "id=:1.id, channel=:1.channel, trade_type=:1.tradeType, status=:1.status, seller_id=:1.sellerId, order_id=:1.orderId, refund_transaction_id=:1.refundTransactionId, origin_transaction_id=:1.originTransactionId, refund_trade_id=:1.refundTradeId, origin_trade_id=:1.originTradeId, currency=:1.currency, amount=:1.amount, refund_reason=:1.refundReason, payment_status=:1.paymentStatus, refund_phase=:1.refundPhase, pay_time=:1.payTime, error_code=:1.errorCode, expire_time=:1.expireTime, create_time=:1.createTime, update_time=:1.updateTime, receive_time=:1.receiveTime";

    String SELECT_COLUMNS = "id, " + IFColumns;

    @ReturnGeneratedKeys
    @SQL("INSERT INTO " + TABLE_NAME + "(" + IFColumns + ")VALUES(" + INSERT_VALUES + ")")
    long insert(RefundDetail refundDetail);

    @UseMaster
    @SQL("SELECT " + SELECT_COLUMNS + " FROM " + TABLE_NAME + " WHERE refund_transaction_id=:1")
    RefundDetail findRefundDetailByRefundTransactionId(long refundTransactionId);

    @UseMaster
    @SQL("SELECT " + SELECT_COLUMNS + " FROM " + TABLE_NAME + " WHERE origin_transaction_id=:1")
    RefundDetail findRefundDetailByOriginTransactionId(long originTransactionId);

    @SQL("UPDATE " + TABLE_NAME + " SET " + IFUpdate + " WHERE refund_transaction_id=:1.refundTransactionId")
    int updateRefund(RefundDetail refundDetail);

    @SQL("SELECT " + SELECT_COLUMNS + " FROM " + TABLE_NAME
            + " WHERE pay_time>=:1 AND pay_time<=:2 AND channel=:3 AND payment_status=3")
    List<RefundDetail> findByPayTime(long beginTime, long endTime, int channel);

    @SQL("SELECT COUNT(*) FROM " + TABLE_NAME + " WHERE pay_time>=:1 AND pay_time<=:2 AND status=2")
    int findListByPayTimeCount(long beginTime, long endTime);

    @SQL("SELECT " + SELECT_COLUMNS + " FROM " + TABLE_NAME
            + " WHERE pay_time>=:1 AND pay_time<=:2 AND status=2  ORDER BY `id` LIMIT :3, :4")
    List<RefundDetail> findListByPayTime(long beginTime, long endTime, int pageStart, int pageNum);

    @UseMaster
    @SQL("SELECT " + SELECT_COLUMNS + " FROM " + TABLE_NAME + " WHERE order_id=:1")
    RefundDetail findByOrderId(long orderId);

    @SQL("SELECT " + SELECT_COLUMNS + " FROM " + TABLE_NAME + " WHERE create_time>=:1 and create_time<=:2 #if(:3>=0) {and trade_status=:3} LIMIT :4, :5")
    List<RefundDetail> findByTimeSpanAndStatus(long beginTime, long endTime, int tradeStatus, int offset, int length);
}
