package com.xiaomi.mifi.payment.model;

import com.xiaomi.mifi.insurance.common.util.exception.ErrorCode;
import com.xiaomi.mifi.insurance.payment.thrift.CommitPaymentMethod;
import lombok.Data;

/**
 * Created by mars on 17-4-20.
 */
@Data
public class CommitPayResult {
    boolean isSuccess;
    ErrorCode errorCode;
    String url;
    String params;
    CommitPaymentMethod method;
}
