package com.xiaomi.mifi.payment.util.download;

import java.io.File;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.slf4j.LoggerFactory;
import org.slf4j.Logger;

import com.csvreader.CsvReader;
import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;
import com.xiaomi.mifi.insurance.common.util.exception.ServiceLogicException;
import com.xiaomi.mifi.insurance.payment.thrift.BillType;
import com.xiaomi.mifi.insurance.payment.thrift.PaymentGatewayName;
import com.xiaomi.mifi.insurance.payment.thrift.TRBillDetail;
import com.xiaomi.mifi.payment.util.PayCenterUtils;

public class SftpDownloadFileService extends AbstractDownloadFile {

    private static Logger LOGGER = LoggerFactory.getLogger(SftpDownloadFileService.class);
    private String sftpHost = "";
    private String sftpUserName = "";
    private String sftpPassword = "";
    private String sftpPath = "";

    public SftpDownloadFileService(String sftpHost, String sftpUserName, String sftpPassword, String sftpPath) {
        this.sftpHost = sftpHost;
        this.sftpUserName = sftpUserName;
        this.sftpPassword = sftpPassword;
        this.sftpPath = sftpPath;
    }

    @Override
    public String getFileName(String billDate) {
        return "20885211421729680156_" + super.getFileName(billDate) + ".zip";
    }

    @Override
    public List<TRBillDetail> readFile(String filePath, String billDate, BillType billType)
            throws ServiceLogicException {
        List<TRBillDetail> result = new ArrayList<TRBillDetail>();
        Map<String, TRBillDetail> maps = new HashMap<String, TRBillDetail>();
        List<String[]> contentList = parseFile(filePath);
        if (contentList.size() > 1) {
            for (int i = 1; i < contentList.size(); i++) {
                String[] item = contentList.get(i);
                if (isFiltered(item[10], billType)) {
                    String tradeId = item[1].trim();
                    String orderId = item[2].trim();
                    String amount = billType.equals(BillType.INCOME) ? item[6] : item[7];
                    if (maps.containsKey(tradeId)) {
                        TRBillDetail detail = maps.get(tradeId);
                        detail.setAmount(detail.getAmount() + PayCenterUtils.parseAmountV0(amount));
                        continue;
                    }
                   TRBillDetail detail = new TRBillDetail();
                    detail.setTradeId(tradeId);
                    detail.setOrderId(orderId);
                    detail.setTime(PayCenterUtils.parseEpochTime(item[4].substring(0, 18)).getTime());
                    detail.setAmount(PayCenterUtils.parseAmountV0(amount));
                    detail.setBillDate(billDate);
                    detail.setBillType(billType);
                    detail.setChannelId(2);
                    detail.setGateway(PaymentGatewayName.ALIPAY);
                    result.add(detail);
                    maps.put(tradeId, detail);
                }
            }
        }
        System.out.println(maps);
        return result;
    }

    private boolean isFiltered(String buziType, BillType billType) {
        if (billType.equals(BillType.INCOME) && buziType.endsWith("支付")) {
            return true;
        }
        if (billType.equals(BillType.OUTCOME) && buziType.contains("退款")) {
            return true;
        }
        return false;
    }

    private List<String[]> parseFile(String filePath) {
        List<String[]> result = new ArrayList<String[]>();
        try {
            CsvReader csvReader = new CsvReader(filePath, ',', Charset.forName("GBK"));
            while (csvReader.readRecord()) {
                String[] r = csvReader.getValues();
                if (r[0].startsWith("#")) {
                    continue;
                }
                result.add(r);
            }
        } catch (Exception e) {
            LOGGER.error("Cannot find file {}", filePath, e);
        }
        return result;
    }


    @Override
    public void downloadFile(String urlStr, String filePath, String fileDirPath, String fileName)
            throws ServiceLogicException {
        String localFilePath = fileDirPath + File.separator + fileName;
        File file = new File(localFilePath);
        if (file.exists()) {
            if (System.currentTimeMillis() - file.lastModified() < 10 * 60 * 1000l) {
                return;
            }
        }
        File pathFile = new File(fileDirPath);
        if (!pathFile.exists()) {
            pathFile.mkdirs();
        }

        Session session = null;
        Channel channel = null;
        ChannelSftp chsftp = null;
        try {
            JSch jsch = new JSch();
            session = jsch.getSession(sftpUserName, sftpHost, 22);
            session.setPassword(sftpPassword);
            session.setTimeout(100000);

            Properties config = new Properties();
            config.put("StrictHostKeyChecking", "on");
            session.setConfig(config);
            session.connect();

            channel = session.openChannel("sftp");
            channel.connect();

            chsftp = (ChannelSftp) channel;
            String sftpFilePath = sftpPath + "/"
                    + fileName.substring(fileName.indexOf('_') + 1, fileName.indexOf('.'))
                    + "/" + fileName;
            chsftp.get(sftpFilePath, localFilePath);
        } catch (Exception e) {
            LOGGER.error("Exception download sftp file", e);
        } finally {
            if (chsftp != null) {
                chsftp.quit();
            }
            if (channel != null) {
                channel.disconnect();
            }
            if (session != null) {
                session.disconnect();
            }
        }
    }

    public List<TRBillDetail> zipFileRead(String csvFilePath, String fileDirPath, String billDate, BillType billType)
            throws ServiceLogicException {
        List<TRBillDetail> ret = new ArrayList<TRBillDetail>();
        List<File> listFile = upzipFile(csvFilePath, fileDirPath);
        for (File file : listFile) {
            if (file.getName().contains("DETAILS")) {
                return readFile(fileDirPath + "/" + file.getName(), billDate, billType);
            }
        }
        return ret;
    }

    public void copyProperties(String[] cellStrs, TRBillDetail billDetail, String billDate) {
        String dateStr = cellStrs[4] != null ? cellStrs[4].trim() : "";
        if (dateStr.contains("/") && dateStr.contains(":") && (dateStr.length() == 14 || dateStr.length() == 15)) {
            billDetail.setTime(PayCenterUtils.parseStrTimeToDate(dateStr, "yyyy/MM/dd HH:mm").getTime());
        } else if (dateStr.contains("/") && dateStr.contains(":")
                && (dateStr.length() == 17 || dateStr.length() == 18)) {
            billDetail.setTime(PayCenterUtils.parseStrTimeToDate(dateStr, "yyyy/MM/dd HH:mm:ss").getTime());
        } else if (!dateStr.contains("/") && dateStr.contains(":")
                && (dateStr.length() == 14 || dateStr.length() == 15)) {
            billDetail.setTime(PayCenterUtils.parseStrTimeToDate(dateStr, "yyyy-MM-dd HH:mm").getTime());
        } else if (!dateStr.contains("/") && dateStr.contains(":")
                && (dateStr.length() == 17 || dateStr.length() == 18)) {
            billDetail.setTime(PayCenterUtils.parseStrTimeToDate(dateStr, "yyyy-MM-dd HH:mm:ss").getTime());
        }
        billDetail.setBillDate(billDate);
        billDetail.setChannelId(2);
        billDetail.setGateway(PaymentGatewayName.ALIPAY);
        billDetail.setOrderId(cellStrs[2] != null ? cellStrs[2].trim() : "");
        billDetail.setTradeId(cellStrs[1] != null ? cellStrs[1].trim() : "");
    }

}
