package com.xiaomi.mifi.payment.crypto;

import org.apache.commons.codec.binary.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;

public class GenericBase64Signature extends SHA256WithRSASignature {

    private static final Logger LOGGER = LoggerFactory.getLogger(GenericBase64Signature.class);

    public String sign(Map<String, String> params) {
        try {
            byte[] data = reformParams(params);
            byte[] signed = sign(data);
            return Base64.encodeBase64URLSafeString(signed);
        } catch (Exception ex) {
            LOGGER.error("sign error", ex);
        }
        return null;
    }

    public boolean verify(Map<String, String> params, String sign) {
        try {
            byte[] data = reformParams(params);
            return verify(data, Base64.decodeBase64(sign.getBytes(ENCODING)));
        } catch (Exception ex) {
            LOGGER.error("verify error", ex);
        }
        return false;
    }

}
