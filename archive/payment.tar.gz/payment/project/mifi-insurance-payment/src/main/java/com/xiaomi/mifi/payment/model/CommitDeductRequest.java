package com.xiaomi.mifi.payment.model;

import com.xiaomi.mifi.payment.thrift.BankCardType;
import com.xiaomi.mifi.payment.thrift.CertType;
import com.xiaomi.mifi.payment.thrift.NotifyType;

import lombok.Data;

/**
 * Created by mars on 17-4-20.
 */
@Data
public class CommitDeductRequest {
    String deductId;
    long totalFee;
    String bankUserName;
    String bankCardNo;
    BankCardType cardType;
    CertType certType;
    String certNo;
    String productName;
    String orderDesc;
    NotifyType notifyType;
    String notifyServiceName;
    String notifyMethodName;
    String notifyURL;
    String returnURL;
    long expireTime;
    long transactionId;
    long orderId;
    long xiaomiId;
}
