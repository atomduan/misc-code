package com.xiaomi.mifi.payment.gateway;

import java.io.IOException;
import java.math.BigDecimal;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.google.common.base.Strings;
import com.google.gson.JsonObject;
import com.mifi.insurance.payment.util.ResponseStatus;
import com.xiaomi.common.perfcounter.PerfCounter;
import com.xiaomi.mifi.insurance.common.util.exception.ErrorCode;
import com.xiaomi.mifi.insurance.common.util.exception.ServiceLogicException;
import com.xiaomi.mifi.insurance.common.util.http.HttpRequester;
import com.xiaomi.mifi.insurance.payment.thrift.BillType;
import com.xiaomi.mifi.insurance.payment.thrift.PaymentGatewayName;
import com.xiaomi.mifi.insurance.payment.thrift.PaymentRequestParam;
import com.xiaomi.mifi.insurance.payment.thrift.PaymentResponseParam;
import com.xiaomi.mifi.insurance.payment.thrift.RefundRequestParam;
import com.xiaomi.mifi.insurance.payment.thrift.TRBillDetail;
import com.xiaomi.mifi.insurance.payment.thrift.TradeType;
import com.xiaomi.mifi.payment.config.Configure;
import com.xiaomi.mifi.payment.crypto.WeixinSignature;
import com.xiaomi.mifi.payment.exception.PaymentGatewayResponseException;
import com.xiaomi.mifi.payment.model.CommitBindDeductRequest;
import com.xiaomi.mifi.payment.model.CommitBindDeductResult;
import com.xiaomi.mifi.payment.model.CommitDeductRequest;
import com.xiaomi.mifi.payment.model.PayResult;
import com.xiaomi.mifi.payment.model.PaymentChannel;
import com.xiaomi.mifi.payment.util.ConvertUtils;
import com.xiaomi.mifi.payment.util.PayCenterUtils;
import com.xiaomi.mifi.payment.util.WeixinPayUtils;
import com.xiaomi.miliao.zookeeper.ZKFacade;

@Service
public class WeixinPaymentGateway extends AbstractPaymentGateway {

    private static final Logger LOGGER = LoggerFactory.getLogger(WeixinPaymentGateway.class);

    @Autowired
    PaymentGatewayRegistry registry;

    @Autowired
    Configure config;

    @Qualifier("weixinHttpRequester")
    @Autowired
    HttpRequester httpRequester;


    @Qualifier("weixinMerchantSignature")
    @Autowired
    WeixinSignature merchantSignature;

    private String weixinUnifiedOrderUrl;
    private String weixinRefundUrl;
    private String weixinDownloadBillUrl;
    private String appId;
    private String mchId;
    private String certLocalPath;
    private String certPassword;

    @PostConstruct
    public void init() {
        registry.register(this);

        weixinUnifiedOrderUrl = config.getString("weixin.pay.url") + "/pay/unifiedorder";
        weixinRefundUrl = config.getString("weixin.pay.url") + "/secapi/pay/refund";
        weixinDownloadBillUrl = config.getString("weixin.pay.url") + "/pay/downloadbill";
        appId = config.getString("weixin.appid");
        mchId = config.getString("weixin.mchid");
        certLocalPath = config.getString("weixin.cert.local.path");
        certPassword = config.getString("weixin.cert.password");

        LOGGER.info(
                "WeixinPaymentGateway argument info [unifiedorder : {}, refundurl : {}, downloadbill : {}, appId : {}, mchId : {},"
                        + "certLocalPath : {}, certPassword: {}]",
                weixinUnifiedOrderUrl, weixinRefundUrl, weixinDownloadBillUrl, appId, mchId, certLocalPath,
                certPassword);

        setAdapter(new WeixinDataAdapter());
    }

    @Override
    public PaymentGatewayName getName() {
        return PaymentGatewayName.WEICHAT;
    }

    @Override
    public PayResult parsePayNotify(Map<String, String> params) {

        String sign = params.remove("sign");
        String transactionIdStr = params.get("out_trade_no"); // 我方生成的订单号
        LOGGER.info("verifying pay notify, transaction id: {}, sign: {}", transactionIdStr, sign);

        boolean verify = merchantSignature.verify(params, sign);

        PayResult ret = new PayResult();
        if (!verify) {
            LOGGER.warn("signature of signature mismatches, transaction id: {}", transactionIdStr);
            ret.setStatus(ResponseStatus.STATUS_SIGN_MISMATCH);
            return ret;
        }

        String receivedAppId = params.get("appid");
        if (!appId.equals(receivedAppId)) {
            LOGGER.warn("invalid app id in pay notify, transaction id: {}, app id: {}", transactionIdStr,
                    receivedAppId);
            ret.setStatus(ResponseStatus.STATUS_INVALID_RESULT);
            return ret;
        }
        String tradeId = params.get("transaction_id"); // 微信生成的账单号
        long transactionId = 0;
        try {
            transactionId = Long.parseLong(transactionIdStr);
        } catch (Exception e) {
            LOGGER.error("error when parse transaction id", e);
        }

        long payTime = ConvertUtils.strToTimestampWeixin(params.get("time_end"));
        String tradeStatusRet = params.get("result_code");

        String status = ResponseStatus.STATUS_FAIL;
        if ("FAIL".equals(tradeStatusRet)) {
            status = ResponseStatus.STATUS_TRANSACTION_CLOSED;
            PerfCounter.count("WeixinParseTradeClosedNotify", 1);
        } else if ("SUCCESS".equals(tradeStatusRet)) {
            status = ResponseStatus.STATUS_SUCCESS;
            PerfCounter.count("WeixinParseTradeSuccessNotify", 1);
        }

        // 打印异步通知的原始状态、处理后的状态
        LOGGER.info("trade status in weixin pay notify: {}, transaction id: {}, result status: {}", tradeStatusRet,
                transactionIdStr, status);

        ret.setStatus(status);
        ret.setTransactionId(transactionId);
        ret.setPayTime(payTime);
        ret.setTradeId(tradeId);

        return ret;
    }

    @Override
    public boolean parseReturnUrl(Map<String, String> parameters) {
        HashMap<String, String> params = new HashMap<>(parameters);

        String sign = params.remove("sign");
        params.remove("channel");

        String transactionIdStr = params.get("out_trade_no"); // 我方生成的订单号
        LOGGER.debug("verifying pay return notify, transaction id: {}, sign: {}", transactionIdStr, sign);

        return merchantSignature.verify(params, sign);
    }

    // 是否使用线上环境
    public boolean isUseProduction() {
        return ZKFacade.getZKSettings().getEnvironmentType().isProduction()
                || !weixinUnifiedOrderUrl.contains("sandboxnew");
    }

    public String getSandboxSignKey() throws IOException {
        Map<String, String> params = getCommonParams();
        params.put("sign", merchantSignature.getSign(params));
        String result = httpRequester.postString("https://api.mch.weixin.qq.com/sandboxnew/pay/getsignkey", null,
                params);
        LOGGER.info("getSandboxSignKey [params : {}, result : {}]", params, result);
        Map<String, String> retMap = WeixinPayUtils.xmlDataToMap(result);
        if (retMap.get("return_code").equals("SUCCESS")) {
            return retMap.get("sandbox_signkey");
        }
        return null;
    }

    @Override
    public List<TRBillDetail> queryNewBill(String billDate, BillType billType)
            throws ServiceLogicException, PaymentGatewayResponseException {
        return queryBill(billDate, billType, false);
    }

    @Override
    HttpRequester getHttpRequester() {
        return httpRequester;
    }

    class WeixinDataAdapter implements GatewayDataAdapter {

        @Override
        public String getWithdrawUrl() {
            throw new UnsupportedOperationException("withdraw is not supported");
        }

        @Override
        public String getQueryBillUrl() {
            return weixinDownloadBillUrl;
        }

        @Override
        public String getTransactionId(Map<PaymentRequestParam, String> params) {
            return params.get(PaymentRequestParam.MERCHANT_TRANSACTION_ID);
        }

        @Override
        public Map<String, String> createWithdrawRequest(Map<PaymentRequestParam, String> params)
                throws PaymentGatewayResponseException, ServiceLogicException {
            throw new UnsupportedOperationException("create withdraw method is not supported");
        }

        @Override
        public Map<PaymentResponseParam, String> parseWithdrawResponse(String response)
                throws PaymentGatewayResponseException, ServiceLogicException {
            throw new UnsupportedOperationException("create withdraw method is not supported");
        }

        @Override
        public Map<String, String> createQueryBillRequest(String billDate, BillType billType, boolean isBackfee) {
            if (billDate.indexOf('-') != -1) {
                billDate = billDate.replaceAll("-", "");
            }
            return createQueryNewBillRequest(billDate, billType);
        }

        @Override
        public List<TRBillDetail> parseQueryBillResponse(String response) throws ServiceLogicException {
            List<TRBillDetail> result = new ArrayList<TRBillDetail>();
            List<ArrayList<String>> lines = parseBillResponse(response);
            for(int i = 0; i < lines.size(); i++) {
                ArrayList<String> line = lines.get(i);
                TRBillDetail item = new TRBillDetail();
                item.setBillDate(line.get(0).substring(0, 10));
                item.setAmount(getAmount(line));
                item.setBillType(line.get(9).equals("REFUND") ? BillType.OUTCOME : BillType.INCOME);
                item.setGateway(PaymentGatewayName.WEICHAT);
                item.setChannelId(PaymentChannel.WECHAT.getIndex());
                item.setOrderId(getOrderId(line));
                item.setTradeId(getTradeId(line));
                item.setTradeType(line.get(9).equals("REFUND") ? TradeType.REFUND : TradeType.PAY);
                result.add(item);
            }
            return result;
        }

        private int getAmount(ArrayList<String> line) {
            if (line.get(9).equals("REFUND")) {
                return PayCenterUtils.parseAmountV0(line.get(18));
            }
            return PayCenterUtils.parseAmountV0(line.get(12));
        }

        private String getTradeId(ArrayList<String> line) {
            if (line.get(9).equals("REFUND")) {
                return line.get(16).trim();
            }
            return line.get(5).trim();
        }

        private String getOrderId(ArrayList<String> line) {
            if (line.get(9).equals("REFUND")) {
                return line.get(17).trim();
            }
            return line.get(6).trim();
        }

        @Override
        public String createPayRequest(Map<PaymentRequestParam, String> params)
                throws ServiceLogicException, PaymentGatewayResponseException {
            LOGGER.info("WeixinDataAdapter.createPayRequest params is {}", params);
            String transactionId = params.get(PaymentRequestParam.MERCHANT_TRANSACTION_ID);
            String subject = params.get(PaymentRequestParam.PAY_SUBJECT);
            String description = params.get(PaymentRequestParam.PAY_DESCRIPTION);
            String amount = params.get(PaymentRequestParam.PAY_AMOUNT);
            String notifyUrl = params.get(PaymentRequestParam.NOTIFY_URL);
            String payTimeout = params.get(PaymentRequestParam.PAY_TIMEOUT);
            String returnUrl = params.get(PaymentRequestParam.RETURN_URL) + "?"
                    + getWeixinReturnUrlParams(transactionId);
            boolean allowCreditCard = TRUE.equals(params.get(PaymentRequestParam.PAY_ALLOW_CREDIT_CARD));
            String createIp = params.get(PaymentRequestParam.CREATE_IP);
            String createTime = params.get(PaymentRequestParam.CREATE_TIME);

            return createPayRequestMapH5(payTimeout, amount, transactionId, subject, description, notifyUrl, returnUrl,
                    allowCreditCard, createIp, createTime);

        }

        @Override
        public String sendRequest(Map<String, String> params) throws ServiceLogicException {
            String xmlParams = WeixinPayUtils.generateXmlString(params);
            try {
                return WeixinPayUtils.sendHttpPostString(weixinRefundUrl, mchId, xmlParams);
            } catch (Exception e) {
                LOGGER.error("exception send request ", e);
                throw new ServiceLogicException(ErrorCode.GATEWAY_NOT_FOUND);
            }
        }

        @Override
        public Map<String, String> createRefundRequest(Map<RefundRequestParam, String> params)
                throws ServiceLogicException, PaymentGatewayResponseException {
            LOGGER.info("WeixinDataAdapter.createRefundRequest params is {}", params);
            String tradeTransactionId = params.get(RefundRequestParam.OUTER_ORDER_ID);
            String originTradeId = params.get(RefundRequestParam.TARDE_NO);
            String refundAmount = params.get(RefundRequestParam.REFUND_AMOUNT); // 不支持部分图退款
            String refundId = params.get(RefundRequestParam.OUTER_REQUEST_NO);
            return createRefundRequestMap(tradeTransactionId, originTradeId, refundAmount, refundAmount, refundId);
        }

        @Override
        public long getTransactionIdFromReturnMap(Map<String, String> tpReturnParam) {
            return Long.parseLong(tpReturnParam.get("out_trade_no"));
        }

        @Override
        public Map<String, String> createQueryNewBillRequest(String billDate, BillType billType) {
            Map<String, String> params = getCommonParams();
            params.put("bill_date", billDate);
            String billTypeStr = BillType.INCOME.equals(billType) ? "SUCCESS" : "REFUND";
            params.put("bill_type", billTypeStr);
            params.put("sign", merchantSignature.getSign(params));
            return params;
        }

        @Override
        public List<TRBillDetail> parseQueryNewBillResponse(String response, String billDate, BillType billType)
                throws PaymentGatewayResponseException, ServiceLogicException {

            return null;
        }

        private Map<String, String> createRefundRequestMap(String tradeTransactionId, String originTradeId,
                String tradeAmount, String refundAmount, String refundId) {
            Map<String, String> params = getCommonParams();
            params.put("transaction_id", originTradeId);
            params.put("out_trade_no", tradeTransactionId);
            params.put("out_refund_no", refundId);
            params.put("total_fee", tradeAmount);
            params.put("refund_fee", refundAmount);
            params.put("refund_fee_type", "CNY");
            params.put("op_user_id", mchId);
            params.put("refund_account", "REFUND_SOURCE_RECHARGE_FUNDS");
            params.put("sign", merchantSignature.getSign(params));
            return params;
        }

        private String createPayRequestMapH5(String timeout, String amount, String transactionId, String subject,
                String description, String notifyUrl, String returnUrl, boolean allowCreditCard, String createIp,
                String createTime) {
            Map<String, String> result = createPayRequestMap(timeout, amount, transactionId, subject, description,
                    notifyUrl, returnUrl, allowCreditCard, "MWEB", createIp, createTime);
            if (result.get("return_code").equals("SUCCESS")) {
                String sign = result.remove("sign");
                if (merchantSignature.verify(result, sign)) {
                    return result.get("mweb_url") + "&redirect_url=" + URLEncoder.encode(returnUrl);
                }
            }
            return returnUrl;
        }

        private String createPayRequestMapApp(String timeout, String amount, String transactionId, String subject,
                String description, String notifyUrl, String returnUrl, boolean allowCreditCard, String createTime) {
            Map<String, String> result = createPayRequestMap(timeout, amount, transactionId, subject, description,
                    notifyUrl, returnUrl, allowCreditCard, "APP", "", createTime);
            
            JsonObject resultJson = new JsonObject();
            if (result.get("return_code").equals("SUCCESS")) {
                String sign = result.remove("sign");
                if (merchantSignature.verify(result, sign)) {
                    resultJson.addProperty("isSuccess", true);
                    for (Map.Entry<String, String> entry : result.entrySet()) {
                        resultJson.addProperty(entry.getKey(), entry.getValue());
                    }
                } else {
                    resultJson.addProperty("isSuccess", false);
                    resultJson.addProperty("code", "error_sign_code");
                    resultJson.addProperty("desc", "验签错误");
                }
            } else {
                resultJson.addProperty("isSuccess", false);
                resultJson.addProperty("code", result.get("return_code"));
                resultJson.addProperty("desc", result.get("return_msg"));
            }
            return resultJson.getAsString();
        }

        private Map<String, String> createPayRequestMap(String timeout, String amount, String transactionId,
                String subject, String description, String notifyUrl, String returnUrl, boolean allowCreditCard,
                String tradeType, String createIp, String createTime) {
            Map<String, String> params = getCommonParams();

            params.put("body", description);
            params.put("detail", subject);
            params.put("attch", "");
            params.put("out_trade_no", transactionId);
            params.put("total_fee", amount);
            params.put("spbill_create_ip", createIp);
            params.put("time_start", createTime);
            params.put("time_expire", timeout);
            params.put("goods_tag", "小米保险");
            params.put("notify_url", notifyUrl);
            params.put("trade_type", tradeType);
            params.put("limit_pay", allowCreditCard ? "" : "no_credit");

            String sign = merchantSignature.getSign(params);
            params.put("sign", sign);

            LOGGER.debug("params {}", params);
            Map<String, String> result = new HashMap<String, String>();
            try {
                result = WeixinPayUtils.sendHttpPost(weixinUnifiedOrderUrl, mchId,
                        WeixinPayUtils.generateXmlString(params));
            } catch (Exception e) {
                LOGGER.error("Exception post request weixin order_id : {}", transactionId, e);
            }
            LOGGER.info("result : {}", result);
            return result;
        }

        @Override
        public Map<String, String> createDeductRequset(CommitDeductRequest request) {
            return null;
        }

        @Override
        public CommitBindDeductResult createDeductSign(CommitBindDeductRequest params) {
            return null;
        }

    }

    private Map<String, String> getCommonParams() {
        Map<String, String> paramsMap = new HashMap<String, String>();
        paramsMap.put("appid", appId);
        paramsMap.put("mch_id", mchId);
        paramsMap.put("nonce_str", PayCenterUtils.getRandomStrinByLength(16));
        return paramsMap;
    }

    private List<ArrayList<String>> parseBillResponse(String response) {
        List<ArrayList<String>> result = new ArrayList<ArrayList<String>>();
        if (Strings.isNullOrEmpty(response)) {
            return result;
        }
        String[] lines = response.split("\\n");
        for (int i = 1; i < lines.length - 2; i++) {
            LOGGER.info("line {}", lines[i]);
            ArrayList<String> line = new ArrayList<String>();
            int bi = 0;
            int ei = 0;
            while (true) {
                bi = lines[i].indexOf("`", ei);
                ei = lines[i].indexOf(",", bi);
                if (bi == -1 || ei == -1) {
                    break;
                }
                line.add(lines[i].substring(bi + 1, ei));
            }
            result.add(line);
        }
        // LOGGER.info("{}", result);
        return result;
    }

    private String getWeixinReturnUrlParams(String outOrderId) {
        StringBuffer result = new StringBuffer();
        Map<String, String> maps = new HashMap<String, String>();
        maps.put("out_trade_no", outOrderId);
        maps.put("sign", merchantSignature.getSign(maps));
        for (Map.Entry<String, String> e : maps.entrySet()) {
            result.append(e.getKey()).append("=").append(e.getValue()).append("&");
        }
        return result.toString().substring(0, result.length() - 1);
    }

}
