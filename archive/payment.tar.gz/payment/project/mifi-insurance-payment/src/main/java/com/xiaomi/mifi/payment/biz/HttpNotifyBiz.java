package com.xiaomi.mifi.payment.biz;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Map;
import java.util.TreeMap;

import org.elasticsearch.common.inject.internal.Strings;
import org.slf4j.LoggerFactory;
import org.slf4j.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.xiaomi.mifi.insurance.common.util.exception.ErrorCode;
import com.xiaomi.mifi.insurance.common.util.exception.ServiceLogicException;
import com.xiaomi.mifi.insurance.common.util.http.DefaultHttpRequestClient;
import com.xiaomi.mifi.insurance.common.util.http.HttpRequestImpl;
import com.xiaomi.mifi.insurance.common.util.http.PoolingHttpClientBuilder;
import com.xiaomi.mifi.insurance.common.util.http.RequestMethod;
import com.xiaomi.mifi.payment.crypto.AESEncryptSignature;
import com.xiaomi.mifi.payment.model.ThriftNotifyRequest;
import com.xiaomi.mifi.payment.thrift.Notify;

@Service
public class HttpNotifyBiz {
    private static final Logger LOGGER = LoggerFactory.getLogger(HttpNotifyBiz.class);

    @Autowired
    AESEncryptSignature sign;

    DefaultHttpRequestClient httpClient = new DefaultHttpRequestClient(new PoolingHttpClientBuilder(5000, 5000, 3000));

    public void httpNotify(ThriftNotifyRequest request, Notify notify) throws ServiceLogicException {
        try {
            Map<String, String> params = convertMap(request);
            String signContent = getHttpParams(request);
            LOGGER.info("signContent info {}", signContent);
            params.put("sign", sign.encrypt(signContent));
            HttpRequestImpl httpRequest = new HttpRequestImpl();
            httpRequest.setRequestMethod(RequestMethod.GET);
            httpRequest.setRequestParams(params);
            httpRequest.setUrl(notify.getNotifyUrl());
            LOGGER.info("notify params {}", httpRequest.getRequestParams());
            String ret = httpClient.execute(httpRequest);
            LOGGER.info("notify result {}", ret);
            if (!ret.equals("OK")) {
                throw new ServiceLogicException(ErrorCode.INTERNAL_SERVER_ERROR);
            }
        } catch (Exception e) {
            LOGGER.info("exception e", e);
            throw new ServiceLogicException(ErrorCode.INTERNAL_SERVER_ERROR);
        }
    }

    private String getHttpParams(ThriftNotifyRequest request) throws Exception {
        TreeMap<String, String> ret = convertMap(request);
        StringBuffer buf = new StringBuffer();
        for (Map.Entry<String, String> entry : ret.entrySet()) {
            buf.append(entry.getKey()).append("=").append(entry.getValue()).append("&");
        }
        if (buf.length() > 0) {
            buf.deleteCharAt(buf.length() - 1);
        }
        return buf.toString();
    }

    private TreeMap<String, String> convertMap(ThriftNotifyRequest request) throws Exception {
        TreeMap<String, String> ret = new TreeMap<String, String>();
        Class<?> clz = request.getClass();
        Field[] fs = clz.getDeclaredFields();
        for (Field f : fs) {
            String fn = f.getName();
            if(fn.indexOf("$") != -1) {
                continue;
            }
            String mn = "get" + Strings.capitalize(fn);
            Method m = clz.getMethod(mn);
            ret.put(fn, String.valueOf(m.invoke(request, null)));
        }
        return ret;
    }
}
