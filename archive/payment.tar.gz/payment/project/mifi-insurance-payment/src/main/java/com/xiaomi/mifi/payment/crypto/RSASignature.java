package com.xiaomi.mifi.payment.crypto;

public abstract class RSASignature extends AbstractSignature {

    @Override
    protected String getKeyAlgorithm() {
        return "RSA";
    }

}
