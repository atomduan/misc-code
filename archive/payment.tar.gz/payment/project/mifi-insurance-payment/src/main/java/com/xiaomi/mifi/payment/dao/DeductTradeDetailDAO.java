package com.xiaomi.mifi.payment.dao;

import java.util.List;

import com.xiaomi.mifi.payment.thrift.DeductTradeDetail;
import com.xiaomi.mifi.payment.thrift.TradeDetail;

import net.paoding.rose.jade.annotation.DAO;
import net.paoding.rose.jade.annotation.ReturnGeneratedKeys;
import net.paoding.rose.jade.annotation.SQL;
import net.paoding.rose.jade.annotation.UseMaster;

/**
 * Created by mars on 17-4-20.
 */
@DAO
public interface DeductTradeDetailDAO {
    String TABLE_NAME = "deduct_trade_detail";

    String IFColumns = "deduct_id, order_id, bank_user_name, bank_card_no, bank_card_type, cert_type, cert_no, trade_status, transaction_id, trade_id, total_fee, currency, product_name, order_desc, payment_status, pay_time, notify_id, return_url, error_desc, error_code, expire_time, create_time, update_time, receive_time";

    String IFFields = ":1.id, :1.deductId, :1.orderId, :1.bankUserName, :1.bankCardNo, :1.bankCardType, :1.certType, :1.certNo, :1.tradeStatus, :1.transactionId, :1.tradeId, :1.totalFee, :1.currency, :1.productName, :1.orderDesc, :1.paymentStatus, :1.payTime, :1.notifyId, :1.returnUrl, :1.errorDesc, :1.errorCode, :1.expireTime, :1.createTime, :1.updateTime, :1.receiveTime";

    String INSERT_VALUES = ":1.deductId, :1.orderId, :1.bankUserName, :1.bankCardNo, :1.bankCardType, :1.certType, :1.certNo, :1.tradeStatus, :1.transactionId, :1.tradeId, :1.totalFee, :1.currency, :1.productName, :1.orderDesc, :1.paymentStatus, :1.payTime, :1.notifyId, :1.returnUrl, :1.errorDesc, :1.errorCode, :1.expireTime, :1.createTime, :1.updateTime, :1.receiveTime";

    String IFUpdate = "id=:1.id, deduct_id=:1.deductId, order_id=:1.orderId, bank_user_name=:1.bankUserName, bank_card_no=:1.bankCardNo, bank_card_type=:1.bankCardType, cert_type=:1.certType, cert_no=:1.certNo, trade_status=:1.tradeStatus, transaction_id=:1.transactionId, trade_id=:1.tradeId, total_fee=:1.totalFee, currency=:1.currency, product_name=:1.productName, order_desc=:1.orderDesc, payment_status=:1.paymentStatus, pay_time=:1.payTime, notify_id=:1.notifyId, return_url=:1.returnUrl, error_desc=:1.errorDesc, error_code=:1.errorCode, expire_time=:1.expireTime, create_time=:1.createTime, update_time=:1.updateTime, receive_time=:1.receiveTime";

    String SELECT_COLUMNS = "id, " + IFColumns;

    @ReturnGeneratedKeys
    @SQL("INSERT INTO " + TABLE_NAME + "(" + IFColumns + ")VALUES(" + INSERT_VALUES + ")")
    long insert(DeductTradeDetail deductTradeDetail);

    @SQL("SELECT " + SELECT_COLUMNS + " FROM " + TABLE_NAME + " WHERE deduct_id=:1")
    DeductTradeDetail findByDeductId(String deductId);

    @UseMaster
    @SQL("SELECT " + SELECT_COLUMNS + " FROM " + TABLE_NAME + " WHERE transaction_id=:1")
    DeductTradeDetail findByTransactionId(long transacionId);

    @UseMaster
    @SQL("SELECT " + SELECT_COLUMNS + " FROM " + TABLE_NAME + " WHERE order_id=:1")
    DeductTradeDetail findByOrderId(long orderId);

    @SQL("UPDATE " + TABLE_NAME + " SET " + IFUpdate + " WHERE deduct_id=:1.deductId")
    int updateDeduct(DeductTradeDetail deductTradeDetail);

    @UseMaster
    @SQL("SELECT " + SELECT_COLUMNS + " FROM " + TABLE_NAME + " WHERE `transaction_id`=:1 FOR UPDATE")
    DeductTradeDetail selectForUpdate(long transactionId);
    
    @SQL("UPDATE " + TABLE_NAME + " SET " + IFUpdate + " WHERE transaction_id=:1.transactionId AND trade_status=:2")
    int updateByTradeStatus(DeductTradeDetail swductTradeDetail, int oldStatus);

    @SQL("SELECT " + SELECT_COLUMNS + " FROM " + TABLE_NAME
            + " WHERE pay_time>=:1 AND pay_time<=:2 AND payment_status=3 ORDER BY `id` LIMIT :3, :4")
    List<DeductTradeDetail> findListByPayTime(long beginTime, long endTime, int pageStart, int pageNum);

    @SQL("SELECT COUNT(*) FROM " + TABLE_NAME + " WHERE pay_time>=:1 AND pay_time<=:2 AND payment_status=3")
    int findListByPayTimeCount(long beginTime, long endTime);

    @SQL("SELECT transaction_id FROM " + TABLE_NAME
            + " WHERE create_time>:1 AND expire_time<:2 AND trade_status IN (:5) LIMIT :3, :4")
    List<Long> queryExpiredTrades(long createTime, long currentTime, int offset, int count, List<Integer> tradeStatus);

}
