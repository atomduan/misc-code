package com.xiaomi.mifi.payment.crypto;

public class SHA256WithRSASignature extends RSASignature {

    @Override
    protected String getSignatureAlgorithm() {
        return "SHA256WithRSA";
    }
}
