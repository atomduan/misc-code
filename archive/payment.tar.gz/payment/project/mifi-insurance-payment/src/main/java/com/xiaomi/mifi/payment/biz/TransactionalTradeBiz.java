package com.xiaomi.mifi.payment.biz;

import com.xiaomi.common.perfcounter.PerfCounter;
import com.xiaomi.mifi.insurance.common.util.exception.ServiceLogicException;
import com.xiaomi.mifi.payment.proxy.BServiceProxy;
import com.xiaomi.mifi.payment.thrift.Notify;
import com.xiaomi.mifi.payment.thrift.SupportChannels;
import com.xiaomi.mifi.payment.thrift.TPPay;
import com.xiaomi.mifi.payment.thrift.TradeDetail;
import com.xiaomi.mifi.payment.util.ConvertUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class TransactionalTradeBiz {

    private static final Logger LOGGER = LoggerFactory.getLogger(TransactionalTradeBiz.class);

    @Autowired
    TradeBiz tradeBiz;

    @Autowired
    NotifyBiz notifyBiz;

    @Autowired
    SupportChannelsBiz supportChannelsBiz;

    @Autowired
    BServiceProxy bServiceProxy;

    /**
     * 根据上游提交的支付数据，新增一个trade detail记录
     */
    @Transactional
    public TradeDetail addNewTrade(TPPay tpPay) throws ServiceLogicException {
        TradeDetail tradeDetail = ConvertUtils.convertTPPay2TradeDetail(tpPay);
        Notify notify = ConvertUtils.convertTPPay2Notify(tpPay);

        tradeDetail.setTransactionId(bServiceProxy.getId());// 生成唯一流水号
        notify.setNotifyId(bServiceProxy.getId());// 生成唯一通知号

        tradeDetail.setNotifyId(notify.getNotifyId());// 交易流水记录关联对应通知
        notify.setTransactionId(tradeDetail.getTransactionId());// 通知记录关联对应交易流水
        List<SupportChannels> supportChannels = ConvertUtils.convertChannels(tpPay.getPayChannel(), tpPay.getOrderId(),
                tradeDetail.getTransactionId());

        tradeBiz.insertTradeDetail(tradeDetail);
        notifyBiz.insertNotify(notify);
        supportChannelsBiz.insertSupportChannels(supportChannels);

        LOGGER.info("trade detail added, transaction id: {}, order id: {}", tradeDetail.getTransactionId(), tradeDetail.getOrderId());

        PerfCounter.count("TransactionalTradeBizAddNewTradeSucceed", 1);
        return tradeDetail;
    }


}
