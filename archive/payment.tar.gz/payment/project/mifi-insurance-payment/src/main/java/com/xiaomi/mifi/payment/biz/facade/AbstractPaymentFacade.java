package com.xiaomi.mifi.payment.biz.facade;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.xiaomi.mifi.payment.model.CommitRefundRequest;
import com.xiaomi.mifi.payment.thrift.RefundDetail;
import com.xiaomi.mifi.payment.thrift.TradeType;

/**
 * Created by mars on 17-4-20.
 */
public abstract class AbstractPaymentFacade implements PaymentFacade {
    private static final Logger LOGGER = LoggerFactory.getLogger(AbstractPaymentFacade.class);

    @Override
    public CommitRefundRequest generateRefund(RefundDetail refundDetail) {
        LOGGER.info("AbstractPaymentFacade.generateRefund is invoked, refund detail is {}", refundDetail);
        CommitRefundRequest commitRefundRequest = new CommitRefundRequest();
        commitRefundRequest.setOriginTradeId(refundDetail.getOriginTradeId());
        commitRefundRequest.setRefundFee(refundDetail.getAmount());
        commitRefundRequest.setTradeAmount(refundDetail.getAmount()); // 退款金额等于订单金额
        commitRefundRequest.setTradeTransactionId(refundDetail.getOriginTransactionId());
        commitRefundRequest.setRefundTransactionId(refundDetail.getRefundTransactionId());
        commitRefundRequest.setRefundReason(refundDetail.getRefundReason());
        commitRefundRequest
                .setDeduct(refundDetail.getTradeType() == TradeType.DEDUCT_REFUND.getValue() ? true : false);
        LOGGER.info("AbstractPaymentFacade.generatePayment is invoked, commit refund request is {}",
                commitRefundRequest);
        return commitRefundRequest;
    }
}
