package com.xiaomi.mifi.payment.model;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by mars on 17-4-26.
 */
public enum SellerIdEnum {

    MIFI_INSURANCE(1, "MIFI-INSURANCE"),;

    private static final Map<Integer, SellerIdEnum> sellerIdEnums = new HashMap<>();

    static {
        for (SellerIdEnum sellerIdEnum : SellerIdEnum.values()) {
            sellerIdEnums.put(sellerIdEnum.code, sellerIdEnum);
        }
    }

    public final int code;
    public final String desc;

    private SellerIdEnum(int code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public int getCode() {
        return code;
    }

    public String getDesc() {
        return desc;
    }

    public static SellerIdEnum getSellerIdEnum(int code) {
        return sellerIdEnums.get(code);
    }
}
