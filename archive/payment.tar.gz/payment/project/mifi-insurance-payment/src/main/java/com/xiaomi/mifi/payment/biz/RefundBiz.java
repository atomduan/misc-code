package com.xiaomi.mifi.payment.biz;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.xiaomi.mifi.insurance.common.util.exception.ErrorCode;
import com.xiaomi.mifi.insurance.common.util.response.ResponseUtils;
import com.xiaomi.mifi.payment.dao.RefundDetailDAO;
import com.xiaomi.mifi.payment.proxy.BServiceProxy;
import com.xiaomi.mifi.payment.thrift.BillDetail;
import com.xiaomi.mifi.payment.thrift.RefundDetail;
import com.xiaomi.mifi.payment.thrift.TRDetailListRequest;
import com.xiaomi.mifi.payment.thrift.TRDetailListResponse;
import com.xiaomi.mifi.payment.thrift.TRRefundDetailList;
import com.xiaomi.mifi.payment.util.ValidateUtils;
/**
 * Created by mars on 17-4-21.
 */
@Service
public class RefundBiz {
    private static final Logger LOGGER = LoggerFactory.getLogger(RefundBiz.class);
    private static final long ONE_DAY = 24 * 60 * 60 * 1000L;

    @Autowired
    private RefundDetailDAO refundDetailDAO;

    @Autowired
    private TradeBiz tradeBiz;

    @Autowired
    private NotifyBiz notifyBiz;

    // @Autowired
    // private AsyncTaskBiz asyncTaskBiz;

    @Autowired
    private BServiceProxy bServiceProxy;

    public long insertRefundDetail(RefundDetail refundDetail) {
        LOGGER.info("RefundBiz.insertRefundDetail() invoke, param is {} ", refundDetail.toString());
        long ret = 0;
        if (ValidateUtils.validateRefundDetail(refundDetail)) {
            ret = refundDetailDAO.insert(refundDetail);
        }
        return ret;
    }

    public int updateRefundDetail(RefundDetail refundDetail) {
        LOGGER.info("RefundBiz.updateRefundDetail() invoke, param is {} ", refundDetail.toString());
        int ret = 0;
        if (ValidateUtils.validateRefundDetail(refundDetail)) {
            ret = refundDetailDAO.updateRefund(refundDetail);
        }
        return ret;
    }

    // 此方法是用refund表自己的transactionId查询一条refund记录
    public RefundDetail findRefundByTransactionId(long transactionId) {
        LOGGER.info("RefundBiz.findRefundByTransactionId() invoke, transactionId is {} ", transactionId);
        return refundDetailDAO.findRefundDetailByRefundTransactionId(transactionId);
    }

    public RefundDetail findRefundByOrderId(long orderId) {
        LOGGER.info("RefundBiz.findRefundByOrderId() invoke, orderId is {} ", orderId);
        return refundDetailDAO.findByOrderId(orderId);
    }

    public RefundDetail findRefundByTradeTransactionId(long tradeTransactionId) {
        LOGGER.info("RefundBiz.findRefundByTradeTransactionId, tradeTransactionId is {}", tradeTransactionId);
        return refundDetailDAO.findRefundDetailByOriginTransactionId(tradeTransactionId);
    }

    public TRRefundDetailList querySuccessRefundDetail(long beginTime, long endTime, int channel) {
        LOGGER.info("RefundBiz.querySuccessRefundDetail() invoke, param is {}, {}, {} ", beginTime, endTime, channel);

        TRRefundDetailList result = new TRRefundDetailList();
        result.setResponse(ResponseUtils.getSuccessResponse());

        if (beginTime <= endTime) {
            List<RefundDetail> list = refundDetailDAO.findByPayTime(beginTime, endTime, channel);
            result.setDetails(list);
        }
        LOGGER.info("RefundBiz.querySuccessRefundDetail response {}", result);
        return result;
    }

    public TRDetailListResponse querySuccessRefundDetailList(TRDetailListRequest request) {
        LOGGER.info("RefundBiz.querySuccessRefundDetailList() param is {}, {} ",
                request.getBeginTime(), request.getEndTime(), request.getTradeType());
        TRDetailListResponse response = new TRDetailListResponse();
        List<BillDetail> billData = new ArrayList<BillDetail>();
        try {
            long beginTime = request.getBeginTime();
            long endTime = request.getEndTime();
            int total = refundDetailDAO.findListByPayTimeCount(beginTime, endTime);
            if (total > 0) {
                List<RefundDetail> data = refundDetailDAO.findListByPayTime(beginTime, endTime, request.getStart(),
                        request.getLength());
                if (data != null) {
                    for (RefundDetail refund : data) {
                        BillDetail billDetail = new BillDetail();
                        billDetail.setAmount(refund.getAmount());
                        billDetail.setTradeType(refund.getTradeType());
                        billDetail.setChannel(refund.getChannel());
                        billDetail.setId(refund.getId());
                        billDetail.setOrderId(refund.getOrderId());
                        billDetail.setPayTime(refund.getPayTime());
                        // 2:代表退款成功 这里转化为3是北京需求，北京要求和支付状态保持状态统一
                        billDetail.setStatus(refund.getStatus() == 2 ? 3 : refund.getStatus());
                        billDetail.setTransactionId(refund.getOriginTransactionId());
                        billData.add(billDetail);
                    }
                }
            }
            response.setBillDetails(billData);
            response.setResponse(ResponseUtils.getSuccessResponse());
            response.setTotal(total);
        } catch (Exception e) {
            response.setResponse(ResponseUtils.getResponse(ErrorCode.INTERNAL_SERVER_ERROR));
            LOGGER.error("querySuccessRefundDetailList Exception {}", e.toString(), e);
        }

        LOGGER.info("for duizhang RefundBiz.querySuccessRefundDetailList response {}", response);
        return response;
    }

    public List<RefundDetail> queryDailyRefund(long start, int offset, int length) {
        return refundDetailDAO.findByTimeSpanAndStatus(start, start + ONE_DAY, -1, offset, length);
    }
}
