package com.xiaomi.mifi.payment.model;

import com.xiaomi.mifi.payment.thrift.*;

import lombok.Data;

import java.util.Collection;
import java.util.HashSet;

/**
 * Created by mars on 17-4-20.
 */
@Data
public class CommitPayRequest {
    private Channel channel;
    private TradeType tradeType;
    private TradeStatus tradeStatus;
    private String sellerId;
    private long orderId;
    private long transactionId;
    private String tradeId;
    private long totalFee;
    private Currency currency;
    private String productName;
    private String orderDesc;
    private PaymentStatus paymentStatus;
    private long payTime;
    private long notifyId;
    private String returnUrl;
    private String errorDesc;
    private int errorCode;
    private long expireTime;
    private long createTime;
    private long updateTime;
    private String notifyUrl;
    private long xiaomiId;
    private PayMethod payMethod;
    private String payBank;
    private String createIp;
    /**
     * 允许使用的卡类型。借记卡总是允许的，要使用信用卡，需要显式指定。
     */
    private Collection<CardType> allowedCardType = new HashSet<>();
    private GoodType goodType;
    private String goodUrl;
    private String goodName;
    private long price;
    private int quantity;
    private long carriageFee;
    private String extraInfo;
}
