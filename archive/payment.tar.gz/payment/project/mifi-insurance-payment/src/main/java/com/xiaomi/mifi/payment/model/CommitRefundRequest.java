package com.xiaomi.mifi.payment.model;

import lombok.Data;

/**
 * Created by mars on 17-4-20.
 */
@Data
public class CommitRefundRequest {
    long refundTransactionId;
    long tradeTransactionId;
    long tradeAmount;
    long refundFee;
    String originTradeId;
    String refundReason;
    boolean isDeduct;
}
