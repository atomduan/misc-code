package com.xiaomi.mifi.payment.dao;

import java.util.List;

import com.xiaomi.mifi.payment.thrift.Notify;
import net.paoding.rose.jade.annotation.DAO;
import net.paoding.rose.jade.annotation.ReturnGeneratedKeys;
import net.paoding.rose.jade.annotation.SQL;
import net.paoding.rose.jade.annotation.UseMaster;

/**
 * Created by mars on 17-4-20.
 */
@DAO
public interface NotifyDAO {
    String TABLE_NAME = "notify";

    String IFColumns = "notify_id, trade_type, transaction_id, notify_type, notify_service_name, notify_method_name, notify_url, notify_status, notify_retry_times, notify_success_time, create_time, update_time";

    String IFFields = ":1.id, :1.notifyId, :1.tradeType, :1.transactionId, :1.notifyType, :1.notifyServiceName, :1.notifyMethodName, :1.notifyUrl, :1.notifyStatus, :1.notifyRetryTimes, :1.notifySuccessTime, :1.createTime, :1.updateTime";

    String INSERT_VALUES = ":1.notifyId, :1.tradeType, :1.transactionId, :1.notifyType, :1.notifyServiceName, :1.notifyMethodName, :1.notifyUrl, :1.notifyStatus, :1.notifyRetryTimes, :1.notifySuccessTime, :1.createTime, :1.updateTime";

    String IFUpdate = "id=:1.id, notify_id=:1.notifyId, trade_type=:1.tradeType, transaction_id=:1.transactionId, notify_type=:1.notifyType, notify_service_name=:1.notifyServiceName, notify_method_name=:1.notifyMethodName, notify_url=:1.notifyUrl, notify_status=:1.notifyStatus, notify_retry_times=:1.notifyRetryTimes, notify_success_time=:1.notifySuccessTime, create_time=:1.createTime, update_time=:1.updateTime";

    String SELECT_COLUMNS = "id, " + IFColumns;

    @ReturnGeneratedKeys
    @SQL("INSERT INTO " + TABLE_NAME + "(" + IFColumns + ")VALUES(" + INSERT_VALUES + ")")
    long insert(Notify notify);

    @UseMaster
    @SQL("SELECT " + SELECT_COLUMNS + " FROM " + TABLE_NAME + " WHERE transaction_id=:1")
    Notify findByTransactionId(long transactionId);

    @UseMaster
    @SQL("SELECT " + SELECT_COLUMNS + " FROM " + TABLE_NAME
            + " WHERE `notify_status`=11 AND notify_success_time=0 AND `next_notify_time`<:1")
    List<Notify> findPendingNotify(long notifyTime);

    @UseMaster
    @SQL("SELECT " + SELECT_COLUMNS + " FROM " + TABLE_NAME
            + " WHERE `notify_status`=12 AND notify_success_time=0 AND `update_time`<:1")
    List<Notify> findSendingNotify(long notifyTime);

    @SQL("UPDATE " + TABLE_NAME + " SET `notify_status`=:3 WHERE `notify_id`=:1 AND `notify_status`=:2")
    int updateNotifyStatus(long notifyId, int oldStatus, int newStatus);

    @UseMaster
    @SQL("SELECT " + SELECT_COLUMNS + " FROM " + TABLE_NAME + " WHERE transaction_id=:1 FOR UPDATE")
    Notify findByTransactionIdForUpdate(long transactionId);

    @UseMaster
    @SQL("SELECT " + SELECT_COLUMNS + " FROM " + TABLE_NAME + " WHERE transaction_id=:1 and trade_type=:2")
    Notify findByTransactionIdAndTradeType(long transactionId, int tradeType);

    @UseMaster
    @SQL("SELECT " + SELECT_COLUMNS + " FROM " + TABLE_NAME + " WHERE transaction_id=:1 and trade_type=:2 FOR UPDATE")
    Notify findByTransactionIdAndTradeTypeForUpdate(long transactionId, int tradeType);

    @SQL("UPDATE " + TABLE_NAME + " SET " + IFUpdate + " WHERE notify_id=:1.notifyId")
    int updateNotify(Notify notify);

    @SQL("SELECT " + SELECT_COLUMNS + " FROM " + TABLE_NAME + " WHERE notify_id=:1")
    Notify findByNotifyId(long notifyId);
}
