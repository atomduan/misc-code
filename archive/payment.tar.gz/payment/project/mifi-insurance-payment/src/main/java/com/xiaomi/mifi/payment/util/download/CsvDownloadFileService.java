package com.xiaomi.mifi.payment.util.download;

import java.io.File;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.csvreader.CsvReader;
import com.xiaomi.mifi.insurance.common.util.exception.ServiceLogicException;
import com.xiaomi.mifi.insurance.payment.thrift.BillType;
import com.xiaomi.mifi.insurance.payment.thrift.PaymentGatewayName;
import com.xiaomi.mifi.insurance.payment.thrift.TRBillDetail;
import com.xiaomi.mifi.insurance.payment.thrift.TradeType;
import com.xiaomi.mifi.payment.util.PayCenterUtils;

/**
 * 分析支付宝账单
 * 
 * @author kucongzhi
 *
 */

@Service
public class CsvDownloadFileService extends AbstractDownloadFile {
    private static final Logger LOGGER = LoggerFactory.getLogger(CsvDownloadFileService.class);

    @Override
    public List<TRBillDetail> readFile(String filePath, String billDate, BillType billType)
            throws ServiceLogicException {
        List<TRBillDetail> ret = new ArrayList<TRBillDetail>();
        TRBillDetail billDetail;
        ArrayList<String[]> csvList = new ArrayList<String[]>();
        try {
            CsvReader reader = new CsvReader(filePath, ',', Charset.forName("GBK"));
            reader.readHeaders();
            while (reader.readRecord()) {
                csvList.add(reader.getValues());
            }
            reader.close();
            for (int row = 0; row < csvList.size(); row++) {
                String firstCell = csvList.get(row)[0];
                LOGGER.info("read csv the first cell value is {}", csvList.get(row)[0]);
                if (row > 3 && csvList.get(row) != null && firstCell != null && checkIsNotEnd(firstCell)) {
                    TradeType tradeType;
                    billDetail = new TRBillDetail();
                    if (billType != null && billType.getValue() == BillType.INCOME.getValue()) {
                        String tradeTypeValue = csvList.get(row)[10];

                        if (tradeTypeValue.contains("支付")) {
                            billType = BillType.INCOME;
                            tradeType = TradeType.PAY;
                            billDetail.setBillType(billType);
                            billDetail.setTradeType(tradeType);
                            billDetail.setAmount(PayCenterUtils
                                    .parseAmountV0(csvList.get(row)[6] != null ? csvList.get(row)[6].trim() : "0"));

                            copyProperties(csvList.get(row), billDetail, billDate);
                        } else {
                            LOGGER.warn("ignore unexpected trade type when query bill: {}", tradeTypeValue);
                            continue;
                        }
                    } else if (billType != null && billType.getValue() == BillType.OUTCOME.getValue()) {
                        String tradeTypeValue = csvList.get(row)[10];

                        if (tradeTypeValue.contains("退款")) {
                            tradeType = TradeType.REFUND;
                            billType = BillType.OUTCOME;
                            billDetail.setBillType(billType);
                            billDetail.setTradeType(tradeType);
                            billDetail.setAmount(PayCenterUtils
                                    .parseAmountV0(csvList.get(row)[7] != null ? csvList.get(row)[7].trim() : "0"));

                            copyProperties(csvList.get(row), billDetail, billDate);
                        } else {
                            LOGGER.warn("ignore unexpected trade type when query bill: {}", tradeTypeValue);
                            continue;
                        }
                    }

                    ret.add(billDetail);
                }
            }
        } catch (Exception e) {
            LOGGER.error("parse csv error CsvDownloadFileService.readFile", e);
            throw ServiceLogicException.ACCESS_GATEWAY_ERROR;
        }
        return ret;
    }

    public void copyProperties(String[] cellStrs, TRBillDetail billDetail, String billDate) {
        String dateStr = cellStrs[4] != null ? cellStrs[4].trim() : "";
        if (dateStr.contains("/") && dateStr.contains(":") && (dateStr.length() == 14 || dateStr.length() == 15)) {
            billDetail.setTime(PayCenterUtils.parseStrTimeToDate(dateStr, "yyyy/MM/dd HH:mm").getTime());
        } else if (dateStr.contains("/") && dateStr.contains(":")
                && (dateStr.length() == 17 || dateStr.length() == 18)) {
            billDetail.setTime(PayCenterUtils.parseStrTimeToDate(dateStr, "yyyy/MM/dd HH:mm:ss").getTime());
        } else if (!dateStr.contains("/") && dateStr.contains(":")
                && (dateStr.length() == 14 || dateStr.length() == 15)) {
            billDetail.setTime(PayCenterUtils.parseStrTimeToDate(dateStr, "yyyy-MM-dd HH:mm").getTime());
        } else if (!dateStr.contains("/") && dateStr.contains(":")
                && (dateStr.length() == 17 || dateStr.length() == 18)) {
            billDetail.setTime(PayCenterUtils.parseStrTimeToDate(dateStr, "yyyy-MM-dd HH:mm:ss").getTime());
        }
        billDetail.setBillDate(billDate);
        billDetail.setChannelId(2);
        billDetail.setGateway(PaymentGatewayName.ALIPAY);
        billDetail.setOrderId(cellStrs[2] != null ? cellStrs[2].trim() : "");
        billDetail.setTradeId(cellStrs[1] != null ? cellStrs[1].trim() : "");
    }

    public List<TRBillDetail> zipFileRead(String csvFilePath, String fileDirPath, String billDate, BillType billType)
            throws ServiceLogicException {
        List<TRBillDetail> ret = new ArrayList<TRBillDetail>();
        List<File> listFile = upzipFile(csvFilePath, fileDirPath);
        for (File file : listFile) {
            if (!file.getName().contains("汇总") && file.getName().contains("账务明细")) {
                return readFile(fileDirPath + "/" + file.getName(), billDate, billType);
            }
        }
        return ret;
    }

}
