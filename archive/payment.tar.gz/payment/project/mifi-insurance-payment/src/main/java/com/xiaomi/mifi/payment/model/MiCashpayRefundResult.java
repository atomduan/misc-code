package com.xiaomi.mifi.payment.model;

import com.xiaomi.mifi.paycenter.thrift.service.TMipayRefundPhase;
import com.xiaomi.mifi.paycenter.thrift.service.TMipayRefundStatus;
import lombok.Data;

/**
 * Created by tianbo on 17-4-28.
 */
@Data
public class MiCashpayRefundResult {
    private String refundId;//支付中心退款的唯一标识
    private String refundDesc;
    private String tradeId;
    private long instructionId;//合作方退款单
    private String outOrderId;//合作方退款单对应的订单号
    private long createTime;
    private long applyRefundFee;//申请退款金额
    private long refundFee;
    private TMipayRefundStatus refundStatus;//退款单状态
    private String failDesc;
    private long refundTime;
    private String responseCode;
    private String responseDesc;
    private TMipayRefundPhase refundPhase;
}
