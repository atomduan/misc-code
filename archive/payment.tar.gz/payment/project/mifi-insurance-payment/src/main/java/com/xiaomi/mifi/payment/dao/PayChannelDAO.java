package com.xiaomi.mifi.payment.dao;

import com.xiaomi.mifi.insurance.payment.thrift.PayChannel;
import net.paoding.rose.jade.annotation.DAO;
import net.paoding.rose.jade.annotation.SQL;

@DAO
public interface PayChannelDAO {

    String TABLE_NAME = "pay_channel";
    String INSERT_COLUMNS = "name,display_name,icon_url,channel_id";
    String INSERT_VALUES = ":1.name,:1.displayName,:1.iconUrl,:1.channelId";
    String SELECT_COLUMNS = "id," + INSERT_COLUMNS;

    @SQL("INSERT INTO " + TABLE_NAME + "(" + INSERT_COLUMNS + ")VALUES(" + INSERT_VALUES + ")")
    void insert(PayChannel one);

    @SQL("SELECT " + SELECT_COLUMNS + " FROM " + TABLE_NAME + " WHERE channel_id=:1")
    PayChannel findByChannelId(long channelId);

}
