package com.xiaomi.mifi.payment.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.xiaomi.mifi.insurance.payment.thrift.TPSubmitPayment;
import com.xiaomi.mifi.payment.model.PaymentChannel;
import com.xiaomi.mifi.payment.thrift.Channel;
import com.xiaomi.mifi.payment.thrift.DeductTradeDetail;
import com.xiaomi.mifi.payment.thrift.Notify;
import com.xiaomi.mifi.payment.thrift.NotifyType;
import com.xiaomi.mifi.payment.thrift.RefundDetail;
import com.xiaomi.mifi.payment.thrift.SupportChannels;
import com.xiaomi.mifi.payment.thrift.TPPay;
import com.xiaomi.mifi.payment.thrift.TPRefund;
import com.xiaomi.mifi.payment.thrift.TradeDetail;
import com.xiaomi.mifi.payment.thrift.TradeType;

/**
 * Created by mars on 17-4-24.
 */
public class ValidateUtils {
    private static final Logger LOGGER = LoggerFactory.getLogger(ValidateUtils.class);

    public static boolean validateTradeDetail(TradeDetail tradeDetail) {
        return tradeDetail != null && tradeDetail.getOrderId() > 0 && tradeDetail.getTransactionId() > 0;
    }

    public static boolean validateSupportChannels(SupportChannels supportChannels) {
        return supportChannels != null && supportChannels.getTransactionId() > 0;
    }

    public static boolean validateRefundDetail(RefundDetail refundDetail) {
        return refundDetail != null && refundDetail.getRefundTransactionId() > 0;
    }

    public static boolean validateDeductTradeDetail(DeductTradeDetail deductTradeDetail) {
        return deductTradeDetail != null && deductTradeDetail.getDeductId().length() > 0;
    }

    public static boolean validateNotify(Notify notify) {
        return notify != null && notify.getNotifyId() > 0;
    }

    public static boolean validateTPPay(TPPay tpPay) {
        try {
            if (tpPay == null)
                return false;
            if (tpPay.getTradeType() == null || tpPay.getTradeType() != TradeType.PAY)
                return false;
            if (tpPay.getOrderId() <= 0)
                return false;
            if (tpPay.getTotalFee() <= 0)
                return false;
            if (tpPay.getPayChannel() == null || tpPay.getPayChannel().size() < 1)
                return false;
            for (Channel channel : tpPay.getPayChannel().keySet()) {
                if (PaymentChannel.getPayChannel(channel.getValue()) == null) {
                    return false;
                }
            }
            if (tpPay.getExpireTime() < System.currentTimeMillis()) {
                return false;
            }
            if (tpPay.getCurrency() == null)
                return false;
            if (tpPay.getNotifyType() == null)
                return false;
            if (tpPay.getNotifyType() == NotifyType.HTTP
                    && (tpPay.getNotifyURL() == null || tpPay.getNotifyURL().length() == 0))
                return false;
            if (tpPay.getNotifyType() == NotifyType.THRIFT
                    && (tpPay.getNotifyMethodName() == null || tpPay.getNotifyMethodName().length() == 0
                            || tpPay.getNotifyServiceName() == null || tpPay.getNotifyServiceName().length() == 0))
                return false;
            if (tpPay.getReturnURL() == null || tpPay.getReturnURL().length() == 0)
                return false;
            return true;
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
        }
        return false;
    }

    public static boolean validateTPRefund(TPRefund tpRefund) {
        if (tpRefund == null)
            return false;
        if (tpRefund.getOrderId() <= 0)
            return false;
        if (tpRefund.getAmount() <= 0)
            return false;
        if (tpRefund.getCurrency() == null)
            return false;
        if (tpRefund.getRefundReason() == null || tpRefund.getRefundReason().length() == 0)
            return false;
        if (tpRefund.getNotifyType() == null)
            return false;
        if (tpRefund.getNotifyType() == NotifyType.HTTP
                && (tpRefund.getNotifyURL() == null || tpRefund.getNotifyURL().length() == 0))
            return false;
        if (tpRefund.getNotifyType() == NotifyType.THRIFT
                && (tpRefund.getNotifyMethodName() == null || tpRefund.getNotifyMethodName().length() == 0
                        || tpRefund.getNotifyServiceName() == null || tpRefund.getNotifyServiceName().length() == 0))
            return false;
        return true;
    }

    public static boolean validateTPSubmitPayment(TPSubmitPayment tpSubmitPayment) {
        if (tpSubmitPayment == null)
            return false;
        if (PaymentChannel.getPayChannel((int) tpSubmitPayment.getChannelId()) == null)
            return false;
        if (tpSubmitPayment.getPrepayId() == null || tpSubmitPayment.getPrepayId().length() == 0)
            return false;
        if (tpSubmitPayment.getSign() == null || tpSubmitPayment.getSign().length() == 0)
            return false;
        return true;
    }
}
