package com.xiaomi.mifi.payment.crypto;

import org.apache.commons.codec.binary.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;

public class AlipaySignature extends GenericBase64Signature {

    private static final Logger LOGGER = LoggerFactory.getLogger(AlipaySignature.class);
    private String sftpUserName;
    private String sftpPassword;

    public String sign(Map<String, String> params) {
        try {
            byte[] data = reformParams(params);
            byte[] signed = sign(data);
            return Base64.encodeBase64String(signed);
        } catch (Exception ex) {
            LOGGER.error("sign error", ex);
        }
        return null;
    }

    public String getSftpUserName() {
        return sftpUserName;
    }

    public void setSftpUserName(String sftpUserName) {
        this.sftpUserName = sftpUserName;
    }

    public String getSftpPassword() {
        return sftpPassword;
    }

    public void setSftpPassword(String sftpPassword) {
        this.sftpPassword = sftpPassword;
    }

}
