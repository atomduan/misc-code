package com.xiaomi.mifi.payment.biz;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.xiaomi.mifi.insurance.payment.thrift.DeductTradeDetail;
import com.xiaomi.mifi.insurance.payment.thrift.RefundDetail;
import com.xiaomi.mifi.insurance.payment.thrift.TradeDetail;
import com.xiaomi.mifi.payment.dao.StatDAO;

@Service
public class StatBiz {

    @Autowired
    StatDAO statDAO;

    public List<DeductTradeDetail> getDeductTradeNoNotify(long time) {
        return statDAO.findDeductTradeNoNotify(time);
    }

    public List<TradeDetail> getTradeNoNotify(long time) {
        return statDAO.findTradeNoNotify(time);
    }

    public List<RefundDetail> getRefundNoNotify(long time) {
        return statDAO.findRefundNoNotify(time);
    }
}
