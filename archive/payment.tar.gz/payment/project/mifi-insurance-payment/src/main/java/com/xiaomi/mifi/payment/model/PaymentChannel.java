package com.xiaomi.mifi.payment.model;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by mars on 17-4-20.
 */
public enum PaymentChannel {
    ALIPAY(1),
    WECHAT(2),
    MICASH(4);
    private int index;

    PaymentChannel(int index) {
        this.index = index;
    }

    private static final Map<Integer, PaymentChannel> paymentChannelMap = new HashMap<>();

    static {
        for (PaymentChannel paymentChannel : PaymentChannel.values()) {
            paymentChannelMap.put(paymentChannel.index, paymentChannel);
        }
    }

    public int getIndex() {
        return index;
    }

    public static PaymentChannel getPayChannel(int index) {
        return paymentChannelMap.get(index);
    }
}
