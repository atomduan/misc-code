package com.xiaomi.mifi.payment.model;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * Created by mars on 17-5-9.
 */
@Data
@NoArgsConstructor
public class ThriftNotifyRequest implements Serializable{
    private long orderId;
    private int payStatus;
    private String payDesc;
    private long payTime;
    private int payChannel;
    private int tradeType;
    private long amount;
    private long payFee;
    private long delayMillis;
}
