package com.xiaomi.mifi.payment.exception;

import com.xiaomi.mifi.insurance.payment.thrift.PaymentGatewayName;

public class PaymentGatewayResponseException extends Exception {

    private PaymentGatewayName paymentGatewayName;

    private String responseCode;

    public PaymentGatewayResponseException(PaymentGatewayName name, String responseCode) {
        super("payment response exception, name: " + name + ", response code: " + responseCode);
        this.responseCode = responseCode;
    }

    public PaymentGatewayName getPaymentGatewayName() {
        return paymentGatewayName;
    }

    public String getResponseCode() {
        return responseCode;
    }

}
