package com.xiaomi.mifi.payment.util;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.elasticsearch.common.lang3.StringUtils;
import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.xiaomi.mifi.insurance.thrift.service.TRPayCenterNotify;
import com.xiaomi.mifi.payment.model.CommitDeductRequest;
import com.xiaomi.mifi.payment.model.PaymentChannel;
import com.xiaomi.mifi.payment.model.SellerIdEnum;
import com.xiaomi.mifi.payment.model.ThriftNotifyRequest;
import com.xiaomi.mifi.payment.thrift.CardType;
import com.xiaomi.mifi.payment.thrift.Channel;
import com.xiaomi.mifi.payment.thrift.Currency;
import com.xiaomi.mifi.payment.thrift.DeductTradeDetail;
import com.xiaomi.mifi.payment.thrift.Notify;
import com.xiaomi.mifi.payment.thrift.NotifyType;
import com.xiaomi.mifi.payment.thrift.PayMethod;
import com.xiaomi.mifi.payment.thrift.PaymentStatus;
import com.xiaomi.mifi.payment.thrift.RefundDetail;
import com.xiaomi.mifi.payment.thrift.SupportChannels;
import com.xiaomi.mifi.payment.thrift.TPPay;
import com.xiaomi.mifi.payment.thrift.TPRefund;
import com.xiaomi.mifi.payment.thrift.TradeDetail;
import com.xiaomi.mifi.payment.thrift.TradeStatus;
import com.xiaomi.mifi.payment.thrift.TradeType;

/**
 * Created by mars on 17-4-21.
 */
public class ConvertUtils {
    public static final Logger LOGGER = LoggerFactory.getLogger(ConvertUtils.class);

    public static DeductTradeDetail convertDeductRequest2DeductDetail(CommitDeductRequest request) {
        DeductTradeDetail deductTradeDetail = new DeductTradeDetail();
        deductTradeDetail.setDeductId(request.getDeductId());
        deductTradeDetail.setBankCardType(request.getCardType().getValue());
        deductTradeDetail.setBankUserName(request.getBankUserName());
        deductTradeDetail.setBankCardNo(request.getBankCardNo());
        deductTradeDetail.setCertType(request.getCertType().getValue());
        deductTradeDetail.setCertNo(request.getCertNo());
        deductTradeDetail.setCreateTime(System.currentTimeMillis());
        deductTradeDetail.setExpireTime(System.currentTimeMillis() + CommonUtils.TIME_SPAN_ONE_HOUR);
        deductTradeDetail.setTradeStatus(TradeStatus.WAIT_PAY.getValue());
        deductTradeDetail.setCurrency(Currency.CNY.getValue());
        deductTradeDetail.setTotalFee(request.getTotalFee());
        deductTradeDetail.setProductName(request.getProductName());
        deductTradeDetail.setOrderDesc(request.getOrderDesc() == null ? "" : request.getOrderDesc());
        deductTradeDetail.setReturnUrl(request.getReturnURL());
        deductTradeDetail.setOrderId(request.getOrderId());
        return deductTradeDetail;
    }

    public static Notify convertDeductRequest2Notify(CommitDeductRequest request) {
        Notify notify = new Notify();
        notify.setCreateTime(System.currentTimeMillis());
        notify.setNotifyMethodName(request.getNotifyMethodName());
        notify.setNotifyServiceName(request.getNotifyServiceName());
        notify.setNotifyType((byte) request.getNotifyType().getValue());
        notify.setNotifyUrl(request.getNotifyURL());
        notify.setNotifyStatus(0);
        notify.setNotifySuccessTime(0);
        notify.setUpdateTime(System.currentTimeMillis());
        return notify;
    }

    public static TradeDetail convertTPPay2TradeDetail(TPPay tpPay) {
        TradeDetail tradeDetail = new TradeDetail();
        tradeDetail.setOrderId(tpPay.getOrderId());
        tradeDetail.setTradeType(tpPay.getTradeType().getValue());
        tradeDetail.setTradeStatus(TradeStatus.INIT.getValue());
        tradeDetail.setProductName(tpPay.getProductName());
        tradeDetail.setTotalFee(tpPay.getTotalFee());
        tradeDetail.setReturnUrl(tpPay.getReturnURL());
        tradeDetail.setSellerId(tpPay.getSellerId() == null ? SellerIdEnum.MIFI_INSURANCE.getDesc()
                : SellerIdEnum.getSellerIdEnum(tpPay.getSellerId().getValue()).getDesc());
        tradeDetail.setXiaomiId(String.valueOf(tpPay.getXiaomiId()));
        tradeDetail.setPayMethod(PayMethod.DIRECT_PAY.getValue());
        tradeDetail.setTradeId("0");
        tradeDetail.setErrorCode(0);
        tradeDetail.setErrorDesc("");
        tradeDetail.setPaymentStatus(PaymentStatus.INIT.getValue());
        tradeDetail.setNotifyId(0);
        tradeDetail.setOrderDesc(tpPay.getOrderDesc());
        tradeDetail.setCreateTime(System.currentTimeMillis());
        tradeDetail.setUpdateTime(System.currentTimeMillis());
        tradeDetail.setExpireTime(tpPay.getExpireTime());
        tradeDetail.setCurrency(tpPay.getCurrency() != null ? tpPay.getCurrency().getValue() : Currency.CNY.getValue());
        return tradeDetail;
    }

    public static Notify convertTPPay2Notify(TPPay tpPay) {
        Notify notify = new Notify();
        notify.setCreateTime(System.currentTimeMillis());
        notify.setUpdateTime(System.currentTimeMillis());
        notify.setTradeType(TradeType.PAY.getValue());
        notify.setNotifyType(tpPay == null ? NotifyType.THRIFT.getValue() : tpPay.getNotifyType().getValue());
        notify.setNotifyServiceName(tpPay != null ? tpPay.getNotifyServiceName() : "");
        notify.setNotifyMethodName(tpPay != null ? tpPay.getNotifyMethodName() : "");
        notify.setNotifyUrl(tpPay.getNotifyURL() != null ? tpPay.getNotifyURL() : "");
        notify.setNotifySuccessTime(0);
        notify.setTransactionId(0);
        notify.setNotifyStatus(0);
        notify.setNotifyRetryTimes(0);
        return notify;
    }

    public static RefundDetail convertTPRefund2RefundDetail(TPRefund tpRefund) {
        RefundDetail refundDetail = new RefundDetail();
        refundDetail.setOrderId(tpRefund.getOrderId());
        refundDetail.setAmount(tpRefund.getAmount());
        refundDetail.setCreateTime(System.currentTimeMillis());
        refundDetail.setUpdateTime(System.currentTimeMillis());
        refundDetail.setRefundReason(tpRefund.getRefundReason());
        refundDetail.setStatus(TradeStatus.INIT.getValue());
        refundDetail.setSellerId(SellerIdEnum.MIFI_INSURANCE.getDesc());
        refundDetail.setTradeType(TradeType.REFUND.getValue());
        refundDetail.setOriginTransactionId(0);
        refundDetail.setOriginTradeId("0");
        refundDetail.setRefundPhase(0);
        refundDetail.setPayTime(0L);
        refundDetail.setPaymentStatus(PaymentStatus.INIT.getValue());
        refundDetail.setCurrency(
                tpRefund.getCurrency() == null ? Currency.CNY.getValue() : tpRefund.getCurrency().getValue());
        refundDetail.setChannel(0);
        refundDetail.setErrorCode("");
        refundDetail.setRefundTradeId("0");
        refundDetail.setCurrency(tpRefund.getCurrency().getValue());
        return refundDetail;
    }

    public static Notify convertTPRefund2Notify(TPRefund tpRefund) {
        Notify notify = new Notify();
        notify.setCreateTime(System.currentTimeMillis());
        notify.setUpdateTime(System.currentTimeMillis());
        notify.setTradeType(TradeType.REFUND.getValue());
        notify.setNotifyType(
                tpRefund.getNotifyType() == null ? NotifyType.THRIFT.getValue() : tpRefund.getNotifyType().getValue());
        notify.setNotifyServiceName(tpRefund.getNotifyServiceName());
        notify.setNotifyMethodName(tpRefund.getNotifyMethodName());
        notify.setNotifyUrl(tpRefund.getNotifyURL() == null ? "" :tpRefund.getNotifyURL());
        notify.setTransactionId(0);
        notify.setNotifyRetryTimes(0);
        notify.setNotifySuccessTime(0);
        notify.setNotifyStatus(0);
        return notify;
    }

    public static List<SupportChannels> convertChannels(Map<Channel, List<CardType>> payChannel, long orderId,
                                                        long transactionId) {
        List<SupportChannels> channelsList = new ArrayList<>();
        if (payChannel != null && payChannel.size() > 0) {
            for (Map.Entry<Channel, List<CardType>> entry : payChannel.entrySet()) {
                for (CardType cardType : entry.getValue()) {
                    SupportChannels supportChannels = new SupportChannels();
                    supportChannels.setOrderId(orderId);
                    supportChannels.setTransactionId(transactionId);
                    supportChannels.setChannel(PaymentChannel.getPayChannel(entry.getKey().getValue()).getIndex());
                    supportChannels.setCardType(cardType.getValue());

                    channelsList.add(supportChannels);
                }
            }
        }
        return channelsList;
    }

    public static TRPayCenterNotify convertTrade2TrPayCenterNotify(TradeDetail tradeDetail) {
        TRPayCenterNotify trPayCenterNotify = new TRPayCenterNotify();
        trPayCenterNotify.setAmount(tradeDetail.getTotalFee());
        trPayCenterNotify.setOrderId(tradeDetail.getOrderId());
        trPayCenterNotify.setPayChannel(tradeDetail.getChannel());
        trPayCenterNotify.setTradeType(TradeType.PAY.getValue());
        trPayCenterNotify.setPayTime(tradeDetail.getPayTime());
        trPayCenterNotify.setPayStatus(tradeDetail.getPaymentStatus());
        return trPayCenterNotify;
    }

    public static TRPayCenterNotify convertRefund2TrPayCenterNotify(RefundDetail refundDetail) {
        TRPayCenterNotify trPayCenterNotify = new TRPayCenterNotify();
        trPayCenterNotify.setAmount(refundDetail.getAmount());
        trPayCenterNotify.setOrderId(refundDetail.getOrderId());
        trPayCenterNotify.setPayChannel(refundDetail.getChannel());
        trPayCenterNotify.setTradeType(TradeType.REFUND.getValue());
        trPayCenterNotify.setPayTime(refundDetail.getPayTime());
        trPayCenterNotify.setPayStatus(refundDetail.getPaymentStatus());
        return trPayCenterNotify;
    }

    public static long strToTimestampWeixin(String timeStr) {
        DateTimeFormatter dateStringFormat2 = DateTimeFormat.forPattern("yyyyMMddHHmmss").withLocale(Locale.CHINA);
        DateTime time = dateStringFormat2.parseDateTime(timeStr);
        return time.getMillis();
    }

    public static long strToTimestamp2(String timeStr) {
        DateTimeFormatter dateStringFormat2 = DateTimeFormat.forPattern("yyyy-MM-dd HH:mm:ss").withLocale(Locale.CHINA);
        DateTime time = dateStringFormat2.parseDateTime(timeStr);
        return time.getMillis();
    }

    public static long strToTimestamp3(String timeStr) {
        DateTimeFormatter dateStringFormat3 = DateTimeFormat.forPattern("yyyy-MM-dd HH:mm:ss.SSS").withLocale(Locale.CHINA);
        DateTime time = dateStringFormat3.parseDateTime(timeStr);
        return time.getMillis();
    }

    public static long parseDecimalString(String decimalString) {
        BigDecimal bigDecimal = new BigDecimal(decimalString);
        return bigDecimal.multiply(BigDecimal.valueOf(100)).toBigInteger().longValue();
    }

    public static String longToExpireTime(long expireTime) {
        double timeSpan = expireTime - System.currentTimeMillis();
        timeSpan = timeSpan / (1000.0 * 60);
        DecimalFormat df = new DecimalFormat("#");
        df.setRoundingMode(RoundingMode.CEILING);
        return df.format(timeSpan) + "m";
    }

    public static TRPayCenterNotify convertCommitNotify2PayCenterNotify(ThriftNotifyRequest thriftNotifyRequest) {
        TRPayCenterNotify trPayCenterNotify = new TRPayCenterNotify();
        trPayCenterNotify.setPayStatus(thriftNotifyRequest.getPayStatus());
        trPayCenterNotify.setTradeType(thriftNotifyRequest.getTradeType());
        trPayCenterNotify.setPayTime(thriftNotifyRequest.getPayTime());
        trPayCenterNotify.setPayChannel(thriftNotifyRequest.getPayChannel());
        trPayCenterNotify.setOrderId(Long.valueOf(thriftNotifyRequest.getOrderId()));
        trPayCenterNotify.setAmount(thriftNotifyRequest.getAmount());
        trPayCenterNotify.setPayDesc(thriftNotifyRequest.getPayDesc());
        return trPayCenterNotify;
    }

    public static com.xiaomi.mifi.insurance.payment.thrift.TradeDetail convertTradeDetail(TradeDetail tradeDetail) {
        com.xiaomi.mifi.insurance.payment.thrift.TradeDetail td = new com.xiaomi.mifi.insurance.payment.thrift.TradeDetail();
        td.setId(tradeDetail.getId());
        td.setChannel(tradeDetail.getChannel());
        td.setTradeType(tradeDetail.getTradeType());
        td.setTradeStatus(tradeDetail.getTradeStatus());
        td.setSellerId(tradeDetail.getSellerId());
        td.setOrderId(tradeDetail.getOrderId());
        td.setTransactionId(tradeDetail.getTransactionId());
        td.setTradeId(tradeDetail.getTradeId());
        td.setTotalFee(tradeDetail.getTotalFee());
        td.setCurrency(tradeDetail.getCurrency());
        td.setProductName(tradeDetail.getProductName());
        td.setOrderDesc(tradeDetail.getOrderDesc());
        td.setPaymentStatus(tradeDetail.getPaymentStatus());
        td.setPayTime(tradeDetail.getPayTime());
        td.setNotifyId(tradeDetail.getNotifyId());
        td.setReturnUrl(tradeDetail.getReturnUrl());
        td.setErrorDesc(tradeDetail.getErrorDesc());
        td.setErrorCode(tradeDetail.getErrorCode());
        td.setXiaomiId(tradeDetail.getXiaomiId());
        td.setPayMethod(tradeDetail.getPayMethod());
        td.setExpireTime(tradeDetail.getExpireTime());
        td.setCreateTime(tradeDetail.getCreateTime());
        td.setUpdateTime(tradeDetail.getUpdateTime());
        td.setReceiveTime(tradeDetail.getReceiveTime());
        return td;
    }

    public static com.xiaomi.mifi.insurance.payment.thrift.RefundDetail convertRefundDetail(RefundDetail refundDetail) {
        com.xiaomi.mifi.insurance.payment.thrift.RefundDetail rd = new com.xiaomi.mifi.insurance.payment.thrift.RefundDetail();
        rd.setId(refundDetail.getId());
        rd.setChannel(refundDetail.getChannel());
        rd.setTradeType(refundDetail.getTradeType());
        rd.setStatus(refundDetail.getStatus());
        rd.setSellerId(refundDetail.getSellerId());
        rd.setOrderId(refundDetail.getOrderId());
        rd.setRefundTransactionId(refundDetail.getRefundTransactionId());
        rd.setOriginTransactionId(refundDetail.getOriginTransactionId());
        rd.setRefundTradeId(refundDetail.getRefundTradeId());
        rd.setOriginTradeId(refundDetail.getOriginTradeId());
        rd.setCurrency(refundDetail.getCurrency());
        rd.setAmount(refundDetail.getAmount());
        rd.setRefundReason(refundDetail.getRefundReason());
        rd.setPaymentStatus(refundDetail.getPaymentStatus());
        rd.setRefundPhase(refundDetail.getRefundPhase());
        rd.setPayTime(refundDetail.getPayTime());
        rd.setErrorCode(refundDetail.getErrorCode());
        rd.setExpireTime(refundDetail.getExpireTime());
        rd.setCreateTime(refundDetail.getCreateTime());
        rd.setUpdateTime(refundDetail.getUpdateTime());
        rd.setReceiveTime(refundDetail.getReceiveTime());
        return rd;
    }

    public static String filter(String str) {
        return str != null ? str : "";
    }
}
