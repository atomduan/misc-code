package com.xiaomi.mifi.payment.crypto;

import java.security.KeyFactory;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Security;
import java.security.Signature;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Map;
import java.util.TreeMap;

import org.apache.commons.codec.binary.Base64;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.util.encoders.UrlBase64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 生成、校验签名
 */
public abstract class AbstractSignature implements MultiFieldsSignature {

    private static final Logger LOGGER = LoggerFactory
            .getLogger(AbstractSignature.class);

    public static final String ENCODING = "utf-8";

    /**
     * PKCS8 encoded private key
     */
    protected String privateKeyContent;

    /**
     * X509 format public key
     */
    protected String publicKeyContent;

    protected PrivateKey privateKey;

    protected PublicKey publicKey;

    static {
        if (Security.getProvider(BouncyCastleProvider.PROVIDER_NAME) == null) {
            Security.addProvider(new BouncyCastleProvider());
        }
    }

    public void init() throws Exception {
        if (privateKeyContent != null) {
            privateKey = parsePrivateKeyContent(getKeyAlgorithm(),
                    privateKeyContent);
        }
        if (publicKeyContent != null) {
            publicKey = parsePublicKeyContent(getKeyAlgorithm(), publicKeyContent);
        }
    }

    protected abstract String getKeyAlgorithm();

    protected abstract String getSignatureAlgorithm();

    private static PrivateKey parsePrivateKeyContent(String alg, String key)
            throws Exception {
        byte[] keyBytes = Base64.decodeBase64(key.getBytes(ENCODING));
        PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(keyBytes);
        KeyFactory keyFactory = KeyFactory.getInstance(alg, "BC");
        PrivateKey privateKey = keyFactory.generatePrivate(keySpec);
        return privateKey;
    }

    private static PublicKey parsePublicKeyContent(String alg, String key)
            throws Exception {
        byte[] keyBytes = Base64.decodeBase64(key);
        X509EncodedKeySpec keySpec = new X509EncodedKeySpec(keyBytes);
        KeyFactory keyFactory = KeyFactory.getInstance(alg, "BC");
        PublicKey publicKey = keyFactory.generatePublic(keySpec);
        return publicKey;
    }

    public String sign(Map<String, String> params) {
        try {
            byte[] data = reformParams(params);
            byte[] signed = sign(data);
            return new String(UrlBase64.encode(signed), ENCODING);
        } catch (Exception ex) {
            LOGGER.error("sign error", ex);
        }
        return null;
    }

    public boolean verify(Map<String, String> params, String sign) {
        try {
            byte[] data = reformParams(params);
            return verify(data, UrlBase64.decode(sign.getBytes(ENCODING)));
        } catch (Exception ex) {
            LOGGER.error("verify error", ex);
        }
        return false;
    }

    @Override
    public byte[] sign(byte[] data) {
        try {
            Signature signature = Signature
                    .getInstance(getSignatureAlgorithm());
            signature.initSign(privateKey);
            signature.update(data);
            return signature.sign();
        } catch (Exception ex) {
            LOGGER.error("sign error", ex);
        }

        return null;
    }

    @Override
    public boolean verify(byte[] data, byte[] sign) {
        try {
            Signature signature = Signature
                    .getInstance(getSignatureAlgorithm());
            signature.initVerify(publicKey);
            signature.update(data);

            return signature.verify(sign);
        } catch (Exception ex) {
            LOGGER.error("verify error", ex);
        }
        return false;
    }

    public static byte[] reformParams(Map<String, String> params) throws Exception {
        if (params != null) {

            TreeMap<String, String> sorted = new TreeMap<String, String>();
            sorted.putAll(params);
            StringBuilder sb = new StringBuilder();
            for (Map.Entry<String, String> entry : sorted.entrySet()) {
                if (sb.length() > 0) {
                    sb.append("&");
                }
                sb.append(entry.getKey());
                sb.append('=');
                sb.append(entry.getValue());
            }

            String string = sb.toString();
            LOGGER.debug("string before sign: {}", string);
            return string.getBytes(ENCODING);
        }
        return null;
    }

    public PublicKey getPublicKey() {
        return publicKey;
    }

    public void setPrivateKeyContent(String privateKeyContent) {
        this.privateKeyContent = privateKeyContent;
    }

    public String getPrivateKeyContent() {
        return privateKeyContent;
    }

    public void setPublicKeyContent(String publicKeyContent) {
        this.publicKeyContent = publicKeyContent;
    }

    public String getPublicKeyContent() {
        return publicKeyContent;
    }

}
