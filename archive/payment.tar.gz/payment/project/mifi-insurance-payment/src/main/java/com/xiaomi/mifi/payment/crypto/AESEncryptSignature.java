package com.xiaomi.mifi.payment.crypto;

import java.security.SecureRandom;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.net.util.Base64;
import org.slf4j.LoggerFactory;
import org.slf4j.Logger;

public class AESEncryptSignature {
    private static final Logger LOGGER = LoggerFactory.getLogger(AESEncryptSignature.class);

    private KeyGenerator keyGen;
    private SecretKey secretKey;

    public AESEncryptSignature(String password) {
        try {
            keyGen = KeyGenerator.getInstance("AES");
            keyGen.init(128, new SecureRandom(password.getBytes()));
            secretKey = keyGen.generateKey();
        } catch (Exception e) {
            LOGGER.error("init AES failed");
        }
    }

    public String encrypt(String content) {
        try {
            byte[] encode = secretKey.getEncoded();
            SecretKeySpec key = new SecretKeySpec(encode, "AES");
            Cipher cipher = Cipher.getInstance("AES");
            cipher.init(Cipher.ENCRYPT_MODE, key);
            byte[] result = cipher.doFinal(content.getBytes("utf-8"));
            return Base64.encodeBase64String(result);
        } catch (Exception e) {
            LOGGER.error("Exception ", e);
        }
        return "";
    }

    public String decrypt(String content) {
        try {
            byte[] encode = secretKey.getEncoded();
            SecretKeySpec key = new SecretKeySpec(encode, "AES");
            Cipher cipher = Cipher.getInstance("AES");
            cipher.init(Cipher.DECRYPT_MODE, key);
            byte[] data = Base64.decodeBase64(content);
            byte[] result = cipher.doFinal(data);
            return new String(result);
        } catch (Exception e) {
            LOGGER.error("Exception ", e);
        }
        return "";
    }
}
