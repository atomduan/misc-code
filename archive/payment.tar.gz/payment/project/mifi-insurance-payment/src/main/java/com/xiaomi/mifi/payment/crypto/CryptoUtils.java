package com.xiaomi.mifi.payment.crypto;

import org.apache.commons.codec.binary.Base64;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import java.math.BigInteger;
import java.security.*;
import java.security.spec.*;
import java.util.Map;
import java.util.TreeMap;

public final class CryptoUtils {

    private static final Logger LOGGER = LoggerFactory.getLogger(CryptoUtils.class);

    private static final String RSA_ECB_PKCS1 = "RSA/ECB/PKCS1Padding";

    private static final String ENCODING = "utf-8";

    static {
        if (Security.getProvider(BouncyCastleProvider.PROVIDER_NAME) == null) {
            Security.addProvider(new BouncyCastleProvider());
        }
    }

    private CryptoUtils() {
    }

    public static String rsaEncryptBase64(PublicKey key, String data) {
        byte[] bytes = rsaEncrypt(key, data);
        if (bytes != null) {
            return Base64.encodeBase64String(bytes);
        }

        return null;
    }

    public static byte[] rsaEncrypt(PublicKey key, String data) {
        try {
            return internalRsaEncrypt(key, data.getBytes());
        } catch (Exception e) {
            LOGGER.error("error when do rsa encryption", e);
        }
        return null;
    }

    /**
     * RSA encrypt with public key,
     *
     * @param modulus  modulus of RSA public key, presented in hex format
     * @param exponent exponent of RSA public key, presented in hex format
     * @return sign result, in hex format
     */
    public static byte[] rsaEncrypt(byte[] modulus, byte[] exponent,
                                            byte[] data) {
        BigInteger modulusValue = new BigInteger(1, modulus);
        BigInteger expValue = new BigInteger(1, exponent);

        RSAPublicKeySpec pkSpec = new RSAPublicKeySpec(modulusValue,
                expValue);
        try {
            KeyFactory keyFactory = KeyFactory.getInstance("RSA");
            PublicKey publicKey = keyFactory.generatePublic(pkSpec);

            return internalRsaEncrypt(publicKey, data);
        } catch (Exception e) {
            LOGGER.error("error when do rsa encryption", e);
        }

        return null;
    }

    public static PublicKey generatePublicKey(String base64) {
        byte[] keyBytes = Base64.decodeBase64(base64);
        X509EncodedKeySpec keySpec = new X509EncodedKeySpec(keyBytes);
        try {
            KeyFactory keyFactory = KeyFactory.getInstance("RSA", "BC");
            return keyFactory.generatePublic(keySpec);
        } catch (Exception e) {
            LOGGER.error("error when generate public key", e);
        }
        return null;
    }

    private static byte[] internalRsaEncrypt(PublicKey publicKey, byte[] data) throws InvalidKeyException, BadPaddingException, IllegalBlockSizeException, NoSuchPaddingException, NoSuchAlgorithmException {
        Cipher cipher = Cipher.getInstance(RSA_ECB_PKCS1);
        cipher.init(Cipher.ENCRYPT_MODE, publicKey);

        return cipher.doFinal(data);
    }

}
