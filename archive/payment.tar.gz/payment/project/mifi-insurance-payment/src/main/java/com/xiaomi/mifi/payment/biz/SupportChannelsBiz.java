package com.xiaomi.mifi.payment.biz;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

import com.google.common.base.Strings;
import com.xiaomi.mifi.insurance.common.util.exception.ServiceLogicException;
import com.xiaomi.mifi.insurance.payment.thrift.ChannelConfig;
import com.xiaomi.mifi.insurance.payment.thrift.PayChannel;
import com.xiaomi.mifi.insurance.payment.thrift.PayChannelInfo;
import com.xiaomi.mifi.insurance.payment.thrift.TPQueryCounterInfo;
import com.xiaomi.mifi.insurance.payment.thrift.TradeType;
import com.xiaomi.mifi.payment.dao.ChannelConfigDAO;
import com.xiaomi.mifi.payment.dao.PayChannelDAO;
import com.xiaomi.mifi.payment.proxy.BServiceProxy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.xiaomi.mifi.payment.dao.SupportChannelsDAO;
import com.xiaomi.mifi.payment.thrift.Channel;
import com.xiaomi.mifi.payment.thrift.SupportChannels;
import com.xiaomi.mifi.payment.util.ValidateUtils;

/**
 * Created by mars on 17-4-24.
 */
@Service
public class SupportChannelsBiz {
    private static final Logger LOGGER = LoggerFactory.getLogger(SupportChannels.class);

    private static final int APP_VERSION = 70;
    private static final String ANDROID = "android";
    private static final String BROWSER = "browser";
    private static final String WEIXIN = "weixin";

    @Autowired
    private SupportChannelsDAO supportChannelsDAO;

    @Autowired
    ChannelConfigDAO channelConfigDAO;

    @Autowired
    PayChannelDAO payChannelDAO;

    @Autowired
    BServiceProxy bServiceProxy;

    public List<SupportChannels> querySupportChannels(long orderId) {
        LOGGER.info("SupportChannelsBiz.querySupportChannels() invoke, param is {} ", orderId);
        List<SupportChannels> ret = supportChannelsDAO.findByOrderId(orderId);
        LOGGER.info("supported channels are {}", ret);
        return ret;
    }

    public long insertSupportChannels(List<SupportChannels> supportChannels) {
        LOGGER.info("SupportChannelsBiz.insertSupportChannels() invoke, param is {} ", supportChannels.toString());
        long ret = 0;
        for (SupportChannels sc : supportChannels) {
            if (ValidateUtils.validateSupportChannels(sc)) {
                ret = supportChannelsDAO.insert(sc);
            }
        }
        return ret;
    }

    public int updateTradeDetail(SupportChannels supportChannels) {
        LOGGER.info("SupportChannelsBiz.updateTradeDetail() invoke, param is {} ", supportChannels.toString());
        int ret = 0;
        if (ValidateUtils.validateSupportChannels(supportChannels)) {
            ret = supportChannelsDAO.updateSupportChannels(supportChannels);
        }
        return ret;
    }

    /**
     * 根据交易类型，输出可供使用的支付渠道
     *
     * @param tradeType 交易类型
     * @return 支付渠道列表，每个渠道最多只出现1次
     */
    public List<PayChannelInfo> getChannelConfig(TradeType tradeType, long transactionId) throws ServiceLogicException {
        LOGGER.debug("getting channel config for trade: {}, transaction id: {}", tradeType, transactionId);
        long now = bServiceProxy.getTimestamp();

        List<SupportChannels> supportChannels = supportChannelsDAO.findByTransactionId(transactionId);
        if (supportChannels.isEmpty()) {
            LOGGER.warn("fail to get channel config, support channels is empty, transaction id: {}", transactionId);
            throw ServiceLogicException.INCORRECT_TRANSACTION_STATUS;
        }

        HashSet<Integer> channelIdsToUse = new HashSet<>();
        for (SupportChannels supportChannel : supportChannels) {
            channelIdsToUse.add(supportChannel.getChannel());
        }

        LOGGER.debug("get support channels for transaction {}: {}", transactionId, supportChannels);

        List<ChannelConfig> configs = channelConfigDAO.findValidChannelsByTradeTypeAndTime(tradeType.getValue(), now);
        HashSet<Integer> channelIds = new HashSet<>();

        int maxPriority = 0;
        PayChannelInfo defaultChannel = null;
        ArrayList<PayChannelInfo> channelList = new ArrayList<>();
        for (ChannelConfig config : configs) {
            int channelId = config.getChannelId();
            if (!channelIdsToUse.contains(channelId)) {
                // 产品方发起支付请求时，指明不需要这个支付机构
                continue;
            }
            // 去重
            if (channelIds.contains(channelId)) {
                continue;
            }
            channelIds.add(channelId);

            PayChannel payChannel = payChannelDAO.findByChannelId(channelId);
            if (payChannel == null) {
                LOGGER.warn("pay channel info not found, id: {}", channelId);
                continue;
            }

            PayChannelInfo payChannelInfo = new PayChannelInfo();
            payChannelInfo.setChannelId(channelId);
            payChannelInfo.setName(payChannel.getName());
            payChannelInfo.setDisplayName(payChannel.getDisplayName());
            payChannelInfo.setSubtitle(config.getSubtitle());
            payChannelInfo.setIconUrl(payChannel.getIconUrl());

            if (config.getPriority() > maxPriority) {
                maxPriority = config.getPriority();
                defaultChannel = payChannelInfo;
            }

            LOGGER.debug("add channel, id: {}, name: {}", channelId, payChannel.getName());
            channelList.add(payChannelInfo);
        }

        if (defaultChannel != null) {
            defaultChannel.setDefaultChannel(true);
        }

        return channelList;
    }

    public List<ChannelConfig> queryChannelConfigs() {
        return channelConfigDAO.findChannelConfigs();
    }

    public boolean setChannelSwitch(int channelId, boolean switchOn) {
        int row = channelConfigDAO.updateChannel(channelId, switchOn ? 1 : 0);
        return row > 0;
    }

    public void filterChannel(List<PayChannelInfo> channels, TPQueryCounterInfo info) {
        int appVersion = info.getAppVersion();
        String os = info.getOs();
        String env = info.getRuntimeEnvironment();
        if ((appVersion >= APP_VERSION && isAndroid(os)) || isBrowser(env)) {
            return;
        }
        PayChannelInfo removeItem = null;
        for (PayChannelInfo channel : channels) {
            if (channel.getChannelId() == Channel.WECHAT.getValue()) {
                removeItem = channel;
            }
        }
        if (removeItem != null) {
            channels.remove(removeItem);
        }

        if (isWeixin(env)) {
            for (PayChannelInfo channel : channels) {
                if (channel.getChannelId() == Channel.CASHPAY.getValue()) {
                    channel.setDefaultChannel(true);
                } else {
                    channel.setDefaultChannel(false);
                }
            }
        }
    }

    private boolean isAndroid(String os) {
        return (!Strings.isNullOrEmpty(os)) && os.equals(ANDROID);
    }

    private boolean isBrowser(String env) {
        return (!Strings.isNullOrEmpty(env)) && env.equals(BROWSER);
    }

    private boolean isWeixin(String env) {
        return (!Strings.isNullOrEmpty(env)) && env.equals(WEIXIN);
    }
}
