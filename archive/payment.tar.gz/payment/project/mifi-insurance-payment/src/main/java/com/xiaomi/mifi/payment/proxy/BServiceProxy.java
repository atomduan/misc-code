package com.xiaomi.mifi.payment.proxy;

import com.xiaomi.mifi.insurance.common.util.exception.ServiceLogicException;
import com.xiaomi.mifi.payment.model.ThriftNotifyRequest;

/**
 * 封装依赖外部系统的操作。
 */
public interface BServiceProxy {

    long getId() throws ServiceLogicException;

    long getTimestamp();

    void insurancePayCenterNotify(ThriftNotifyRequest thriftNotifyRequest) throws ServiceLogicException;
}
