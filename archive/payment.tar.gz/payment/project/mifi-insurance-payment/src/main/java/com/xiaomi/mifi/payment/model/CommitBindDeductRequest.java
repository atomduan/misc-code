package com.xiaomi.mifi.payment.model;

import lombok.Data;

/**
 * Created by mars on 17-4-20.
 */
@Data
public class CommitBindDeductRequest {
    private int bizType;
    private String returnUrl;
    private String productName;
    private String bankList;
    private String extraInfo;
}
