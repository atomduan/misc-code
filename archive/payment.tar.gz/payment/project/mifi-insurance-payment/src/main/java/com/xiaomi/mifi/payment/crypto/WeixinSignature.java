package com.xiaomi.mifi.payment.crypto;

import java.util.Map;
import java.util.TreeMap;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.xiaomi.mifi.payment.gateway.WeixinPaymentGateway;
import com.xiaomi.miliao.utils.Md5Util;

public class WeixinSignature extends AbstractSignature {
    private static Logger LOGGER = LoggerFactory.getLogger(WeixinSignature.class);

    @Autowired
    WeixinPaymentGateway gateway;
    boolean isInitialized = false;

    private String key;

    public void setKey(String key) {
        this.key = key;
    }

    public String getSign(Map<String, String> params) {
        return Md5Util.md5(makeSignString(params)).toUpperCase();
    }

    @Override
    public boolean verify(Map<String, String> params, String sign) {
        return sign.equals(getSign(params));
    }

    private String makeSignString(Map<String, String> params) {
        TreeMap<String, String> paramsMap = new TreeMap<String, String>(String.CASE_INSENSITIVE_ORDER);
        paramsMap.putAll(params);
        StringBuffer buf = new StringBuffer();
        for (Map.Entry<String, String> entry : paramsMap.entrySet()) {
            if (StringUtils.isNotEmpty(entry.getValue())) {
                buf.append(entry.getKey()).append("=").append(entry.getValue()).append("&");
            }
        }
        buf.append("key=").append(getKey());
        LOGGER.info("sign string {}", buf.toString());
        return buf.toString();
    }

    public String getKey() {
        if (isInitialized) {
            return key;
        }
        isInitialized = true;
        if (!gateway.isUseProduction()) {
            try {
                key = gateway.getSandboxSignKey();
            } catch (Exception e) {
                LOGGER.error("getSandboxSignKey error", e);
            }
        }
        return key;
    }

    @Override
    protected String getKeyAlgorithm() {
        return null;
    }

    @Override
    protected String getSignatureAlgorithm() {
        return null;
    }
}
