package com.xiaomi.mifi.payment.biz.facade;

import static com.xiaomi.mifi.payment.util.ConvertUtils.longToExpireTime;
import static com.xiaomi.mifi.payment.util.ResponseUtils.getTRRefundResponse;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.w3c.dom.Document;
import org.xml.sax.SAXException;

import com.xiaomi.common.perfcounter.PerfCounter;
import com.xiaomi.data.spec.log.miui.cashpayDpmWebAccounting;
import com.xiaomi.mifi.common.thrift.model.TRResponse;
import com.xiaomi.mifi.insurance.common.util.exception.ErrorCode;
import com.xiaomi.mifi.insurance.common.util.exception.ServiceLogicException;
import com.xiaomi.mifi.insurance.payment.thrift.CommitPaymentMethod;
import com.xiaomi.mifi.insurance.payment.thrift.PaymentRequestParam;
import com.xiaomi.mifi.insurance.payment.thrift.RefundRequestParam;
import com.xiaomi.mifi.payment.biz.DeductBiz;
import com.xiaomi.mifi.payment.biz.NotifyBiz;
import com.xiaomi.mifi.payment.biz.RefundBiz;
import com.xiaomi.mifi.payment.biz.TradeBiz;
import com.xiaomi.mifi.payment.exception.PaymentGatewayResponseException;
import com.xiaomi.mifi.payment.gateway.MiCashpayPaymentGateway;
import com.xiaomi.mifi.payment.gateway.PaymentGateway;
import com.xiaomi.mifi.payment.model.CommitBindDeductRequest;
import com.xiaomi.mifi.payment.model.CommitBindDeductResult;
import com.xiaomi.mifi.payment.model.CommitDeductRequest;
import com.xiaomi.mifi.payment.model.CommitDeductResult;
import com.xiaomi.mifi.payment.model.CommitPayRequest;
import com.xiaomi.mifi.payment.model.CommitPayResult;
import com.xiaomi.mifi.payment.model.CommitRefundRequest;
import com.xiaomi.mifi.payment.model.CommitRefundResult;
import com.xiaomi.mifi.payment.model.PayResult;
import com.xiaomi.mifi.payment.model.PaymentChannel;
import com.xiaomi.mifi.payment.proxy.BServiceProxy;
import com.xiaomi.mifi.payment.thrift.CardType;
import com.xiaomi.mifi.payment.thrift.Channel;
import com.xiaomi.mifi.payment.thrift.PaymentStatus;
import com.xiaomi.mifi.payment.thrift.RefundDetail;
import com.xiaomi.mifi.payment.thrift.RefundPhase;
import com.xiaomi.mifi.payment.thrift.TRPayResponse;
import com.xiaomi.mifi.payment.thrift.TRRefundResponse;
import com.xiaomi.mifi.payment.thrift.TradeDetail;
import com.xiaomi.mifi.payment.thrift.TradeStatus;
import com.xiaomi.mifi.payment.util.ConvertUtils;

/**
 * Created by mars on 17-4-20.
 */
@Service
public class MiCashPaymentFacade extends AbstractPaymentFacade {
    private static final Logger LOGGER = LoggerFactory.getLogger(MiCashpayPaymentGateway.class);

    @Autowired
    PaymentFacadeRegistry registry;

    @Autowired
    private RefundBiz refundBiz;

    @Autowired
    private NotifyBiz notifyBiz;

    @Autowired
    private TradeBiz tradeBiz;

    @Autowired
    private DeductBiz deductBiz;

    @Autowired
    private MiCashpayPaymentGateway miCashpayPaymentGateway;

    @Autowired
    @Qualifier("notifyMipayUrlPattern")
    private String notifyUrl;

    @Autowired
    @Qualifier("urlCashpay")
    private String urlCashPay;

    @Autowired
    @Qualifier("counterReturnUrlMicash")
    private String counterReturnUrlMicash;

    @Autowired
    private BServiceProxy bServiceProxy;

    @PostConstruct
    public void init() {
        registry.register(this);
    }

    @Override
    public PaymentChannel getChannel() {
        return PaymentChannel.MICASH;
    }

    @Override
    public CommitPayRequest generatePayment(TradeDetail tradeDetail) {
        LOGGER.info("MiCashPaymentFacade.generatePayment is invoked, trade detail is {}", tradeDetail);
        CommitPayRequest commitPayRequest = new CommitPayRequest();
        commitPayRequest.setTransactionId(tradeDetail.getTransactionId());
        commitPayRequest.setGoodName(tradeDetail.getProductName());
        commitPayRequest.setOrderDesc(tradeDetail.getOrderDesc());
        commitPayRequest.setReturnUrl(counterReturnUrlMicash);
        commitPayRequest.setExpireTime(tradeDetail.getExpireTime());
        commitPayRequest.setTotalFee(tradeDetail.getTotalFee());
        commitPayRequest.setNotifyUrl(notifyUrl);
        commitPayRequest.setXiaomiId(Long.valueOf(tradeDetail.getXiaomiId()));
        LOGGER.info("MiCashPaymentFacade.generatePayment is invoked, commit pay request is {}", commitPayRequest);
        return commitPayRequest;
    }

    @Override
    public CommitPayResult commitPay(CommitPayRequest commitPayRequest) {
        LOGGER.info("MiCashPaymentFacade.commitPay commitPayRequest is {}", commitPayRequest);
        CommitPayResult commitPayResult = new CommitPayResult();
        Map<PaymentRequestParam, String> params = new HashMap<>();
        params.put(PaymentRequestParam.MERCHANT_TRANSACTION_ID, String.valueOf(commitPayRequest.getTransactionId()));
        params.put(PaymentRequestParam.PAY_SUBJECT, commitPayRequest.getGoodName());
        params.put(PaymentRequestParam.PAY_DESCRIPTION, commitPayRequest.getOrderDesc());
        params.put(PaymentRequestParam.PAY_AMOUNT, String.valueOf(commitPayRequest.getTotalFee()));
        params.put(PaymentRequestParam.NOTIFY_URL, commitPayRequest.getNotifyUrl());
        params.put(PaymentRequestParam.RETURN_URL, commitPayRequest.getReturnUrl());
        params.put(PaymentRequestParam.PAY_TIMEOUT, longToExpireTime(commitPayRequest.getExpireTime()));
        params.put(PaymentRequestParam.XIAOMI_ID, String.valueOf(commitPayRequest.getXiaomiId()));
        if (commitPayRequest.getAllowedCardType().contains(CardType.CREDIT)) {
            params.put(PaymentRequestParam.PAY_ALLOW_CREDIT_CARD, PaymentGateway.TRUE);
        }
        try {
            String parameters = miCashpayPaymentGateway.createPayRequest(params);
            commitPayResult.setSuccess(true);
            commitPayResult.setErrorCode(ErrorCode.SUCCESS);
            commitPayResult.setUrl(urlCashPay);
            commitPayResult.setParams(parameters);
            commitPayResult.setMethod(CommitPaymentMethod.REDIRECT);
        } catch (ServiceLogicException | PaymentGatewayResponseException e) {
            LOGGER.warn("MiCashPaymentFacade.commitPay commitPayRequest failed");
            commitPayResult.setSuccess(false);
            commitPayResult.setErrorCode(ErrorCode.INTERNAL_SERVER_ERROR);
            commitPayResult.setParams("");
        }
        LOGGER.info("MiCashPaymentFacade.commitPay result is {}", commitPayResult);
        return commitPayResult;
    }

    @Override
    public CommitRefundResult commitRefund(CommitRefundRequest commitRefundRequest) {
        LOGGER.info("MiCashPaymentFacade.commitRefund commitRefundRequest is {}", commitRefundRequest);
        CommitRefundResult commitRefundResult = new CommitRefundResult();
        Map<RefundRequestParam, String> params = new HashMap<>();
        String outOrderId = String.valueOf(commitRefundRequest.getTradeTransactionId());
        if (commitRefundRequest.isDeduct()) {
            outOrderId = String.format("%020d", commitRefundRequest.getTradeTransactionId());
        }
        params.put(RefundRequestParam.OUTER_ORDER_ID, outOrderId);
        params.put(RefundRequestParam.OUTER_REQUEST_NO, String.valueOf(commitRefundRequest.getRefundTransactionId()));
        params.put(RefundRequestParam.REFUND_AMOUNT, String.valueOf(commitRefundRequest.getRefundFee()));
        try {
            String response = miCashpayPaymentGateway.createRefundRequest(params);
            commitRefundResult = receiveMiCashPayRefundReturn(response, commitRefundRequest.getTradeTransactionId());
        } catch (ServiceLogicException | PaymentGatewayResponseException e) {
            LOGGER.error(e.getMessage(), e);
            commitRefundResult.setSuccess(false);
            commitRefundResult.setErrorCode(ErrorCode.INTERNAL_SERVER_ERROR);
            commitRefundResult.setResponse("refund internal exception");
        }
        LOGGER.info("MiCashPaymentFacade.commitRefund result is ", commitRefundResult.getResponse());
        return commitRefundResult;
    }

    @Override
    public CommitBindDeductResult commitBindDeduct(CommitBindDeductRequest request) {
        LOGGER.info("commit bind deduct info {}", request);
        CommitBindDeductResult result = miCashpayPaymentGateway.createDeductSign(request);
        return result;
    }

    @Override
    public CommitDeductResult commitDeduct(CommitDeductRequest request) {
        CommitDeductResult result = new CommitDeductResult();
        Map<String, String> deductResponse = miCashpayPaymentGateway.commitDeduct(request);
        String isSuccess = deductResponse.get("isSuccess");
        if (isSuccess != null && isSuccess.equals("T")) {
            PayResult payResult = miCashpayPaymentGateway.parsePayNotify(deductResponse);

            if (payResult.getStatus().equals("TRADE_SUCCESS")) {
                long transactionId = payResult.getTransactionId();
                if (deductBiz.updatePayResult(payResult)) {
                    LOGGER.info("trade is updated, transaction id: {}", transactionId);
                    notifyBiz.sendRefundNotify(transactionId);
                } else {
                    LOGGER.warn("trade is not updated, transaction id: {}", transactionId);
                }
            }
        }
        return result;
    }

    @Override
    public TRPayResponse convertCommitPayResult(CommitPayResult result) {
        return null;
    }

    @Override
    public TRRefundResponse convertCommitRefundResult(CommitRefundResult commitRefundResult, RefundDetail refundDetail) {
        LOGGER.info("MiCashPaymentFacade.convertCommitRefundResult, commitRefundResult is {}, refundDetail is {}",
                commitRefundResult, refundDetail);
        if (commitRefundResult.isSuccess()) {
            return getTRRefundResponse(ErrorCode.SUCCESS, refundDetail);
        } else {
            TRResponse trResponse = new TRResponse();
            trResponse.setSuccess(false);
            trResponse.setCode(ErrorCode.REQUEST_FAILED.code);
            trResponse.setDesc(ErrorCode.REFUND_ERROR.externalDescription);
            trResponse.setBizContent(commitRefundResult.getResponse());
            return new TRRefundResponse(trResponse, refundDetail);
        }
    }

    private CommitRefundResult receiveMiCashPayRefundReturn(String response, long tradeTransactionId) {
        CommitRefundResult commitRefundResult = new CommitRefundResult();
        try {
            DocumentBuilder db = DocumentBuilderFactory.newInstance().newDocumentBuilder();
            Document doc = db.parse(new ByteArrayInputStream(response.getBytes()));

            String isSuccess = doc.getElementsByTagName("isSuccess").item(0).getTextContent();
            String responseCode = doc.getElementsByTagName("responseCode").item(0).getTextContent();

            if ("T".equals(isSuccess) && "SUCCESS".equals(responseCode)) {// 首次提交退款申请，同步返回成功
                String outOrderIdStr = doc.getElementsByTagName("outOrderId").item(0).getTextContent();
                String refundFeeStr = doc.getElementsByTagName("applyRefundFee").item(0).getTextContent();
                String refundTimeStr = doc.getElementsByTagName("createTime").item(0).getTextContent();
                String tradeId = doc.getElementsByTagName("tradeId").item(0).getTextContent();

                long originTradeTransactionId = outOrderIdStr != null ? Long.parseLong(outOrderIdStr) : 0L;
                long refundFee = refundFeeStr != null ? Long.parseLong(refundFeeStr) : 0L;
                long refundTime = refundTimeStr != null ? Long.parseLong(refundFeeStr) : 0L;

                if (originTradeTransactionId <= 0 || refundFee <= 0 || refundTime <= 0
                        || StringUtils.isEmpty(tradeId)) {
                    LOGGER.error("parse MI cashpay refund outOrderId failed, receiver outOrderId is {}", outOrderIdStr);
                    commitRefundResult.setSuccess(false);
                    commitRefundResult.setErrorCode(ErrorCode.REQUEST_FAILED);
                    commitRefundResult.setResponse("MI cashpay return parameter error");
                    RefundDetail refundDetail = refundBiz.findRefundByTradeTransactionId(tradeTransactionId);
                    if (refundDetail != null) {
                        refundDetail.setPaymentStatus(PaymentStatus.FAIL.getValue());
                        refundDetail.setStatus(TradeStatus.FAIL.getValue());
                        refundBiz.updateRefundDetail(refundDetail);
                    } else {
                        LOGGER.error("refund detail not found, refund transactionId: {}", tradeTransactionId);
                    }
                    return commitRefundResult;
                }
                // 退款已成功
                RefundDetail refundDetail = refundBiz.findRefundByTradeTransactionId(originTradeTransactionId);
                if (refundDetail.getStatus() == TradeStatus.SUCCESS.getValue()
                        && refundDetail.getPaymentStatus() == PaymentStatus.SUCCESS.getValue()) {
                    commitRefundResult.setSuccess(true);
                    commitRefundResult.setErrorCode(ErrorCode.REPEATED_REFUND);
                    commitRefundResult.setResponse("Refund is already success");
                    return commitRefundResult;
                }

                // 退款金额匹配，可以退款
                if (refundDetail.getAmount() == refundFee) {
                    commitRefundResult.setSuccess(true);
                    commitRefundResult.setErrorCode(ErrorCode.SUCCESS);
                    commitRefundResult.setResponse(refundDetail.toString());
                    return commitRefundResult;
                } else {
                    // 退款金额不匹配
                    refundDetail.setPaymentStatus(PaymentStatus.FAIL.getValue());
                    refundDetail.setStatus(TradeStatus.FAIL.getValue());
                    refundBiz.updateRefundDetail(refundDetail);
                    commitRefundResult.setSuccess(false);
                    commitRefundResult.setErrorCode(ErrorCode.REFUND_ERROR);
                    commitRefundResult.setResponse(response);
                    return commitRefundResult;
                }
            } else if ("T".equals(isSuccess) && ("REFUND_SUCCESS".equals(responseCode)
                    || "APPLY_REFUND_MORE_THAN_ONCE_ERROR".equals(responseCode))) {// 退款已成功或者是重复申请退款
                commitRefundResult.setSuccess(true);
                commitRefundResult.setErrorCode(ErrorCode.REPEATED_REFUND);
                commitRefundResult.setResponse("Refund is already success");
                return commitRefundResult;
            } else {//退款申请同步返回的是失败状态
                LOGGER.error("Mi cashpay refund return fail, msg is {}", responseCode);
                commitRefundResult.setSuccess(false);
                commitRefundResult.setErrorCode(ErrorCode.REFUND_ERROR);
                commitRefundResult.setResponse(response);
                //修改数据库中的状态，使得可以再次发起退款申请
                RefundDetail refundDetail = refundBiz.findRefundByTradeTransactionId(tradeTransactionId);
                if (refundDetail != null) {
                    refundDetail.setPaymentStatus(PaymentStatus.FAIL.getValue());
                    refundDetail.setStatus(TradeStatus.FAIL.getValue());
                    refundBiz.updateRefundDetail(refundDetail);
                } else {
                    LOGGER.error("refund detail not found, refund transactionId: {}", tradeTransactionId);
                }
                return commitRefundResult;
            }
        } catch (IOException | SAXException | ParserConfigurationException e) {
            LOGGER.warn("refund failed, error message: {}", e.getMessage());
            commitRefundResult.setSuccess(false);
            commitRefundResult.setErrorCode(ErrorCode.INTERNAL_SERVER_ERROR);
            commitRefundResult.setResponse(response);
            return commitRefundResult;
        }
    }

    @Override
    public boolean verifyPayParam(Map<String, String> params) {
        if (null == params || params.isEmpty()) {
            return false;
        }

        if (null == params.get("outOrderId")) {
            return false;
        }
        if (null == params.get("tradeId")) {
            return false;
        }
        if (null == params.get("totalFee") || !NumberUtils.isNumber(params.get("totalFee"))) {
            return false;
        }

        if (null == params.get("tradeStatus")) {
            return false;
        }
        if (null == params.get("payTime") || !NumberUtils.isNumber(params.get("payTime"))) {
            return false;
        }
        return true;
    }

    @Override
    public boolean verifyRefundParam(Map<String, String> params) {
        if (null == params || params.isEmpty()) {
            return false;
        }

        if (null == params.get("refundId")) {
            return false;
        }
        if (null == params.get("partnerRefundId")) {
            return false;
        }
        if (null == params.get("outOrderId")) {
            return false;
        }
        if (null == params.get("refundFee")) {
            return false;
        }
        if (null == params.get("refundDesc")) {
            return false;
        }
        if (null == params.get("refundTime")) {
            return false;
        }
        if (null == params.get("responseCode")) {
            return false;
        }
        if (null == params.get("responseDesc")) {
            return false;
        }
        return true;
    }

    @Override
    public TradeDetail getTradeDetailFromReturnParam(Map<String, String> params) throws ServiceLogicException {
        boolean isVerify = verifyReturnUrlParam(params);// todo
        long transactionId = 0;
        if (isVerify) {
            transactionId = miCashpayPaymentGateway.getTransactionIdFromReturnMap(params);
        } else {
            LOGGER.warn("MiCashPaymentFacade.verifyReturnUrlParam return false, params: {}", params);
            throw ServiceLogicException.INVALID_PARAM;
        }
        return tradeBiz.findByTransactionId(transactionId);
    }

    private boolean verifyReturnUrlParam(Map<String, String> params) {
        if (null == params || params.isEmpty()) {
            return false;
        }

        if (params.get("isSuccess") == null) {
            return false;
        }

        if (params.get("partnerId") == null) {
            return false;
        }

        if (params.get("notifyType") == null) {
            return false;
        }

        if (params.get("outOrderId") == null) {
            return false;
        }

        if (params.get("tradeId") == null) {
            return false;
        }

        if (params.get("totalFee") == null) {
            return false;
        }

        if (params.get("orderDesc") == null) {
            return false;
        }

        if (params.get("payTime") == null) {
            return false;
        }

        if (params.get("tradeStatus") == null) {
            return false;
        }

        if (params.get("sign") == null) {
            return false;
        }

        return miCashpayPaymentGateway.parseReturnUrl(params);
    }

    @Transactional(propagation = Propagation.NOT_SUPPORTED)
    public void notifyRefund(Map<String, String> params) throws Exception {
        LOGGER.info("MiCashPaymentFacade.notifyRefund is invoked, refund request parameters is {}", params);
        String tradeTransactionIdStr = params.get("outOrderId");
        if (null == tradeTransactionIdStr) {
            LOGGER.warn("MiCashPaymentFacade.notifyCashpayRefund is invoked, tradeTransactionId is missing");
            return;
        }

        long tradeTransactionId = 0;
        try {
            tradeTransactionId = Long.parseLong(tradeTransactionIdStr);
        } catch (NumberFormatException e) {
            LOGGER.error("parse tradeTransactiondId failed, tradeTransactionIdStr is {}", tradeTransactionIdStr);
            return;
        }

        RefundDetail refundDetail = refundBiz.findRefundByTradeTransactionId(tradeTransactionId);
        if (null == refundDetail) {
            LOGGER.warn("MiCashPaymentFacade.notifyCashpayRefund is invoked, refund detail is not exists. tradeTransactionId is {}", tradeTransactionId);
            return;
        }
        LOGGER.info("MiCashPaymentFacade.notifyCashpayRefund is invoked, refundDetail is {}", refundDetail);

        if (refundDetail.getStatus() == TradeStatus.SUCCESS.getValue() && refundDetail.getPaymentStatus() == PaymentStatus.SUCCESS.getValue()) {
            LOGGER.info("MiCashPaymentFacade.notifyCashpayRefund is invoked, refund is success, tradeTransactionId is {}", tradeTransactionId);
            return;
        }

        String refundId = params.get("refundId");
        String refundTime = params.get("refundTime");
        String refundStatus = params.get("responseCode");

        refundDetail.setRefundTradeId(refundId);
        refundDetail.setPayTime(ConvertUtils.strToTimestamp2(refundTime));
        refundDetail.setErrorCode(refundStatus);
        refundDetail.setPaymentStatus(PaymentStatus.SUCCESS.getValue());

        if ("REFUND_SUCCESS".equals(refundStatus)) {// refund success
            refundDetail.setStatus(TradeStatus.SUCCESS.getValue());
            PerfCounter.count("MiCashRefundSucceed", 1);
        } else {// refund failed
            refundDetail.setStatus(TradeStatus.FAIL.getValue());
            PerfCounter.count("MiCashRefundFailure", 1);
        }
        PerfCounter.countDuration("MiCashRefundDuration", bServiceProxy.getTimestamp() - refundDetail.getCreateTime());

        String refundPhase = params.get("refundPhase");
        if (refundPhase != null) {// update refund phase
            refundDetail.setRefundPhase("FINAL".equals(refundPhase) ? RefundPhase.FINAL.getValue() : RefundPhase.WAIT_BANK.getValue());
            LOGGER.info("MiCashPaymentFacade.notifyCashpayRefund, update refund phase, refundId is {}, refundPhase is {}",refundId, refundPhase);
        }

        if ("REFUND_SUCCESS".equals(refundStatus)) {// refund success
            refundDetail.setUpdateTime(bServiceProxy.getTimestamp());
            refundBiz.updateRefundDetail(refundDetail);
            notifyBiz.sendRefundNotify(refundDetail.getOriginTransactionId());
            LOGGER.info("MiCashPaymentFacade.notifyCashpayRefund, refund is success, refundId is{}, refund status is {}",refundId,refundStatus);
        } else {// only update refund details
            refundDetail.setUpdateTime(bServiceProxy.getTimestamp());
            refundBiz.updateRefundDetail(refundDetail);
            LOGGER.info("MiCashPaymentFacade.notifyCashpayRefund, update refund details, refundId is {}, refund status is {}",refundId,refundStatus);
        }
    }
}
