package com.xiaomi.mifi.payment.exception;

import com.xiaomi.mifi.insurance.common.util.exception.ErrorCode;

/**
 * Created by mars on 17-4-28.
 */
public class PaymentInternalException extends Exception{
    public ErrorCode getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(ErrorCode errorCode) {
        this.errorCode = errorCode;
    }

    public PaymentInternalException(ErrorCode errorCode) {
        super("PaymentInternalException, error code: " + errorCode.externalDescription);
        this.errorCode = errorCode;
    }

    private ErrorCode errorCode;
}
