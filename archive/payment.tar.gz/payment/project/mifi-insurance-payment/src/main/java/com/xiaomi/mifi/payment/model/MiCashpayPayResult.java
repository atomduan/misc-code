package com.xiaomi.mifi.payment.model;

import com.xiaomi.mifi.paycenter.thrift.service.TTradeStatus;
import lombok.Data;

/**
 * Created by tianbo on 17-4-28.
 */
@Data
public class MiCashpayPayResult {
    private long instructionId;
    private String tradeId;
    private long orderFee;
    private String orderDesc;
    private String payBank;
    private TTradeStatus tradeStatus;
    private long requestTime;
    private long createTime;
    private long payTime;
    private long reductionFee;
    private String reductionDesc;
    private String statusDesc;
    private boolean hasCharge;
    private int payType;
}
