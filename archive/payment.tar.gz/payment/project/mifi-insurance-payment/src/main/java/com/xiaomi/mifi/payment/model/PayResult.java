package com.xiaomi.mifi.payment.model;

import lombok.Data;

@Data
public class PayResult {

    String status;

    long transactionId;

    String tradeId;

    long payTime;

}
