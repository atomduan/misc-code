package com.xiaomi.mifi.payment.biz;

import java.util.List;

import com.xiaomi.common.perfcounter.PerfCounter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.xiaomi.mifi.common.thrift.model.TRResponse;
import com.xiaomi.mifi.insurance.common.util.exception.ErrorCode;
import com.xiaomi.mifi.insurance.common.util.exception.ServiceLogicException;
import com.xiaomi.mifi.insurance.common.util.response.ResponseUtils;
import com.xiaomi.mifi.notify.thrift.service.NotifyStatus;
import com.xiaomi.mifi.payment.dao.NotifyDAO;
import com.xiaomi.mifi.payment.model.PaymentChannel;
import com.xiaomi.mifi.payment.model.ThriftNotifyRequest;
import com.xiaomi.mifi.payment.proxy.BServiceProxy;
import com.xiaomi.mifi.payment.thrift.*;
import com.xiaomi.mifi.payment.util.ValidateUtils;

/**
 * Created by mars on 17-4-21.
 */
@Service
public class NotifyBiz {

    private static final Logger LOGGER = LoggerFactory.getLogger(NotifyBiz.class);
    private static final int[] RETRY_TIME_SPAN = { 3, 5, 8, 13, 30, 60, 300, 1000, 3000, 10000, 50000 };

    @Autowired
    private NotifyDAO notifyDAO;

    @Autowired
    private TradeBiz tradeBiz;

    @Autowired
    private RefundBiz refundBiz;

    @Autowired
    private DeductBiz deductBiz;

    @Autowired
    private BServiceProxy bServiceProxy;

    @Autowired
    private HttpNotifyBiz httpNotifyBiz;

    public long insertNotify(Notify notify) {
        LOGGER.info("NotifyBiz.insertNotify() invoke, param is {} ", notify.toString());
        long now = bServiceProxy.getTimestamp();
        notify.setCreateTime(now);
        notify.setUpdateTime(now);
        notify.setNextNotifyTime(0);
        return notifyDAO.insert(notify);
    }

    public int updateNotify(Notify notify) {
        LOGGER.info("NotifyBiz.updateNotify() invoke, param is {} ", notify.toString());
        int ret = 0;
        if (ValidateUtils.validateNotify(notify)) {
            ret = notifyDAO.updateNotify(notify);
        }
        return ret;
    }

    public List<Notify> findPendingNotify(long notifyTime) {
        return notifyDAO.findPendingNotify(notifyTime);
    }

    public List<Notify> findSendingNotify(long notifyTime) {
        return notifyDAO.findSendingNotify(notifyTime);
    }

    public int updateNotifyStatus(long notifyId, int oldStatus, int newStatus) {
        return notifyDAO.updateNotifyStatus(notifyId, oldStatus, newStatus);
    }

    public Notify findNotifyByTransactionId(long transactionId) {
        LOGGER.info("NotifyBiz.findNotifyByTransactionId() invoke, param is {} ", transactionId);
        Notify notify = notifyDAO.findByTransactionId(transactionId);
        return notify;
    }

    public Notify findNotifyByNotifyId(long notifyId) {
        LOGGER.info("NotifyBiz.findNotifyByNotifyId() invoke, param is {} ", notifyId);
        return notifyDAO.findByNotifyId(notifyId);
    }

    public Notify findNotifyByOrderId(long orderId, int tradeType) {
        LOGGER.info("NotifyBiz.findNotifyByOrderId() invoke, orderId is {}, tradeType is {} ", orderId, tradeType);
        Notify notify = null;
        if (tradeType == TradeType.PAY.getValue()) {
            TradeDetail tradeDetail = tradeBiz.queryPaymentInfo(orderId);
            LOGGER.info("NotifyBiz.findNotifyByOrderId(), queryPaymentInfo return {} ", tradeDetail);
            if (tradeDetail != null) {
                notify = notifyDAO.findByTransactionIdAndTradeType(tradeDetail.getTransactionId(), tradeType);
            }
        } else if (tradeType == TradeType.REFUND.getValue() || tradeType == TradeType.DEDUCT_REFUND.getValue()) {
            RefundDetail refundDetail = refundBiz.findRefundByOrderId(orderId);
            LOGGER.info("NotifyBiz.findNotifyByOrderId(), findRefundByOrderId return {} ", refundDetail);
            if (refundDetail != null) {
                notify = notifyDAO.findByTransactionIdAndTradeType(refundDetail.getRefundTransactionId(),
                        tradeType);
            }
        } else if (tradeType == TradeType.DEDUCT.getValue()) {
            DeductTradeDetail deductTradeDetail = deductBiz.findByOrderId(orderId);
            if (deductTradeDetail != null) {
                notify = notifyDAO.findByTransactionId(deductTradeDetail.getTransactionId());
            }
        }
        return notify;
    }

    public void sendRefundNotify(long transactionId) {
        LOGGER.info("NotifyBiz.sendRefundNotify transactionId is {}", transactionId);
        RefundDetail refundDetail = refundBiz.findRefundByTradeTransactionId(transactionId);
        sendNotify(refundDetail.getRefundTransactionId());
    }

    public void sendNotify(long transactionId) {
        LOGGER.info("NotifyBiz.sendTradeNotify transactionId is {}", transactionId);
        Notify notify = findNotifyByTransactionId(transactionId);
        notify.setNotifyStatus(com.xiaomi.mifi.payment.model.NotifyStatus.PENDING.getValue());
        notify.setUpdateTime(System.currentTimeMillis());
        notify.setNextNotifyTime(System.currentTimeMillis());
        notify.setNotifySuccessTime(0L);
        updateNotify(notify);
    }

    private ThriftNotifyRequest getRefundNotify(long tradeTransactionId) {
        LOGGER.info("NotifyBiz.sendRefundNotify originTradeTransactionId is {}", tradeTransactionId);
        RefundDetail refundDetail = refundBiz.findRefundByTransactionId(tradeTransactionId);
        boolean isSuccess = refundDetail.getStatus() == TradeStatus.SUCCESS.getValue();
        ThriftNotifyRequest thriftNotifyRequest = new ThriftNotifyRequest();
        thriftNotifyRequest.setAmount(refundDetail.getAmount());
        thriftNotifyRequest.setOrderId(refundDetail.getOrderId());
        thriftNotifyRequest.setPayChannel(refundDetail.getChannel());
        thriftNotifyRequest.setPayTime(isSuccess ? refundDetail.getPayTime() : 0L);
        thriftNotifyRequest.setTradeType(refundDetail.getTradeType());
        thriftNotifyRequest.setPayStatus(isSuccess ? PaymentStatus.SUCCESS.getValue() : PaymentStatus.FAIL.getValue());
        thriftNotifyRequest.setDelayMillis(0);
        return thriftNotifyRequest;
    }

    public ThriftNotifyRequest getTradeNotify(long transactionId) {
        LOGGER.info("NotifyBiz.sendTradeNotify transactionId is {}", transactionId);
        TradeDetail tradeDetail = tradeBiz.findByTransactionId(transactionId);
        ThriftNotifyRequest thriftNotifyRequest = new ThriftNotifyRequest();
        thriftNotifyRequest.setAmount(tradeDetail.getTotalFee());
        thriftNotifyRequest.setOrderId(tradeDetail.getOrderId());
        thriftNotifyRequest.setPayChannel(tradeDetail.getChannel());
        thriftNotifyRequest.setPayTime(tradeDetail.getPayTime());
        thriftNotifyRequest.setTradeType(tradeDetail.getTradeType());
        thriftNotifyRequest.setPayStatus(tradeDetail.getPaymentStatus() == PaymentStatus.EXPIRED_CLOSE.getValue()
                ? PaymentStatus.FAIL.getValue() : tradeDetail.getPaymentStatus());
        thriftNotifyRequest.setDelayMillis(0);
        return thriftNotifyRequest;
    }

    public ThriftNotifyRequest getDeductTradeNotify(long transactionId) {
        LOGGER.info("NotifyBiz.sendTradeNotify transactionId is {}", transactionId);
        DeductTradeDetail tradeDetail = deductBiz.findByTransactionId(transactionId);
        ThriftNotifyRequest thriftNotifyRequest = new ThriftNotifyRequest();
        thriftNotifyRequest.setAmount(tradeDetail.getTotalFee());
        thriftNotifyRequest.setOrderId(tradeDetail.getOrderId());
        thriftNotifyRequest.setPayChannel(PaymentChannel.MICASH.getIndex());
        thriftNotifyRequest.setPayTime(tradeDetail.getPayTime());
        thriftNotifyRequest.setTradeType(TradeType.DEDUCT.getValue());
        thriftNotifyRequest.setPayStatus(tradeDetail.getPaymentStatus() == PaymentStatus.EXPIRED_CLOSE.getValue()
                ? PaymentStatus.FAIL.getValue() : tradeDetail.getPaymentStatus());
        thriftNotifyRequest.setDelayMillis(0);
        return thriftNotifyRequest;
    }

    /**
     * 手工通知支付订单
     * 
     * @param orderId
     * @return
     */
    public TRResponse notifyTrade(long orderId) {
        TradeDetail tradeDetail = tradeBiz.findByOrderId(orderId);
        LOGGER.info("notify business orderId {}, tradeDetail {}", orderId, tradeDetail);
        if (tradeDetail == null
                || tradeDetail.getPaymentStatus() != PaymentStatus.SUCCESS.getValue()) {
            return ResponseUtils.getResponse(ErrorCode.ORDER_NOT_PAID);
        }
        long transactionId = tradeDetail.getTransactionId();
        Notify notify = findNotifyByTransactionId(transactionId);
        LOGGER.info("notify info {}", notify);
        if (notify.getNotifySuccessTime() > 0) {
            LOGGER.info("already notify ");
        }
        try {
            sendNotify(transactionId);
        } catch (Exception e) {
            LOGGER.info("exception on notify business ", e);
            return ResponseUtils.getResponse(ErrorCode.INTERNAL_SERVER_ERROR);
        }
        return ResponseUtils.getSuccessResponse();
    }

    /**
     * 手工通知代扣订单
     * 
     * @param orderId
     * @return
     */
    public TRResponse noditfyDeduct(long orderId) {
        DeductTradeDetail tradeDetail = deductBiz.findByOrderId(orderId);
        LOGGER.info("notify business orderId {}, deducttradeDetail {}", orderId, tradeDetail);
        if (tradeDetail == null
                || tradeDetail.getPaymentStatus() != com.xiaomi.mifi.payment.thrift.PaymentStatus.SUCCESS.getValue()) {
            return ResponseUtils.getResponse(ErrorCode.ORDER_NOT_PAID);
        }
        long transactionId = tradeDetail.getTransactionId();
        Notify notify = findNotifyByTransactionId(transactionId);
        LOGGER.info("notify info {}", notify);
        if (notify.getNotifySuccessTime() > 0) {
            LOGGER.info("already notify ");
        }
        try {
            sendNotify(transactionId);
        } catch (Exception e) {
            LOGGER.info("exception on notify business ", e);
            return ResponseUtils.getResponse(ErrorCode.INTERNAL_SERVER_ERROR);
        }
        return ResponseUtils.getSuccessResponse();
    }

    /**
     * 手动通知退款
     * 
     * @param orderId
     * @return
     */
    public TRResponse notifyRefund(long orderId) {
        RefundDetail refundDetail = refundBiz.findRefundByOrderId(orderId);
        LOGGER.info("notify refund orderId {}, refund detail {}", orderId, refundDetail);
        if (refundDetail == null
                || refundDetail.getPaymentStatus() != PaymentStatus.SUCCESS.getValue()
                || refundDetail.getStatus() != TradeStatus.SUCCESS.getValue()) {
            return ResponseUtils.getResponse(ErrorCode.ORDER_NOT_PAID);
        }
        long transactionId = refundDetail.getRefundTransactionId();
        Notify notify = findNotifyByTransactionId(transactionId);
        LOGGER.info("notify info {}", notify);
        if (notify.getNotifySuccessTime() > 0) {
            LOGGER.info("already notify, retry to notify");
        }
        try {
            sendNotify(transactionId);
        } catch (Exception e) {
            LOGGER.info("exception on notify business ", e);
            return ResponseUtils.getResponse(ErrorCode.INTERNAL_SERVER_ERROR);
        }
        return ResponseUtils.getSuccessResponse();
    }

    /**
     * 通知业务方
     * 
     * @param notify
     */
    public void notifyOrder(Notify notify) {
        if (notify.getNotifyStatus() == NotifyStatus.SUCCESS.getValue()) {
            LOGGER.error("notify already success {}", notify);
            return;
        }

        long now = bServiceProxy.getTimestamp();
        try {
            ThriftNotifyRequest request = getThriftNotifyRequest(notify);
            if (request == null) {
                LOGGER.error("request is null notify {}", notify);
                return;
            }
            LOGGER.info("notify insurance request {}, notify {}", request, notify);
            if (notify.getNotifyType() == NotifyType.HTTP.getValue()) {
                httpNotifyBiz.httpNotify(request, notify);
            } else {
                bServiceProxy.insurancePayCenterNotify(request);
            }
            PerfCounter.count("InsuranceNotifySuccess", 1);

            notify.setNotifyStatus(com.xiaomi.mifi.payment.model.NotifyStatus.SUCCESS.getValue());
            notify.setUpdateTime(now);
            notify.setNotifySuccessTime(now);
            updateNotify(notify);
        } catch (ServiceLogicException e) {
            LOGGER.error("notify service exception ", e);

            int tryTimes = notify.getNotifyRetryTimes();
            if (tryTimes < RETRY_TIME_SPAN.length) {
                tryTimes ++;
                notify.setNotifyRetryTimes(tryTimes);
                notify.setUpdateTime(now);
                long timeDelay = RETRY_TIME_SPAN[tryTimes - 1];
                long nextNotifyTime = (notify.getNextNotifyTime() == 0 ? now : notify.getNextNotifyTime()) + timeDelay;
                notify.setNextNotifyTime(nextNotifyTime);
                notify.setNotifyStatus(com.xiaomi.mifi.payment.model.NotifyStatus.PENDING.getValue());
                updateNotify(notify);
                PerfCounter.count("InsuranceNotifyRetryTimes", 1);
            } else {
                notify.setNotifyStatus(com.xiaomi.mifi.payment.model.NotifyStatus.FAIL.getValue());
                notify.setUpdateTime(now);
                updateNotify(notify);
                PerfCounter.count("InsuranceNotifyGiveUp", 1);
            }
        }
    }

    private ThriftNotifyRequest getThriftNotifyRequest(Notify notify) {
        if (notify.getTradeType() == TradeType.PAY.getValue()) {
            return getTradeNotify(notify.getTransactionId());
        } else if(notify.getTradeType() == TradeType.DEDUCT.getValue()) {
            return getDeductTradeNotify(notify.getTransactionId());
        } else if (notify.getTradeType() == TradeType.REFUND.getValue()
                || notify.getTradeType() == TradeType.DEDUCT_REFUND.getValue()) {
            return getRefundNotify(notify.getTransactionId());
        }
        return null;
    }
}
