package com.xiaomi.mifi.payment.crypto;

public class SHA1WithRSASignature extends RSASignature {

    @Override
    protected String getSignatureAlgorithm() {
        return "SHA1WithRSA";
    }
}
