package com.xiaomi.mifi.payment.service;

import static com.xiaomi.mifi.payment.util.ResponseUtils.getResponse;
import static com.xiaomi.mifi.payment.util.ResponseUtils.getSuccessResponse;
import static com.xiaomi.mifi.payment.util.ResponseUtils.getTRRefundResponse;
import static com.xiaomi.mifi.payment.util.ResponseUtils.getTRSubmitPayment;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.google.common.base.Strings;
import com.mifi.insurance.payment.util.ResponseStatus;
import com.xiaomi.common.perfcounter.PerfCounter;
import com.xiaomi.mifi.common.thrift.model.TRResponse;
import com.xiaomi.mifi.insurance.common.util.arg.ArgumentChecker;
import com.xiaomi.mifi.insurance.common.util.exception.ErrorCode;
import com.xiaomi.mifi.insurance.common.util.exception.ServiceLogicException;
import com.xiaomi.mifi.insurance.common.util.response.ResponseUtils;
import com.xiaomi.mifi.insurance.payment.thrift.BillType;
import com.xiaomi.mifi.insurance.payment.thrift.ChannelConfig;
import com.xiaomi.mifi.insurance.payment.thrift.PayChannelInfo;
import com.xiaomi.mifi.insurance.payment.thrift.PaymentGatewayName;
import com.xiaomi.mifi.insurance.payment.thrift.PaymentRequestParam;
import com.xiaomi.mifi.insurance.payment.thrift.PaymentResponseParam;
import com.xiaomi.mifi.insurance.payment.thrift.TPQueryBill;
import com.xiaomi.mifi.insurance.payment.thrift.TPQueryCounterInfo;
import com.xiaomi.mifi.insurance.payment.thrift.TPSubmitPayment;
import com.xiaomi.mifi.insurance.payment.thrift.TPWithdrawRequest;
import com.xiaomi.mifi.insurance.payment.thrift.TRBillDetail;
import com.xiaomi.mifi.insurance.payment.thrift.TRExpireTradesResponse;
import com.xiaomi.mifi.insurance.payment.thrift.TRQueryBill;
import com.xiaomi.mifi.insurance.payment.thrift.TRQueryCounterInfo;
import com.xiaomi.mifi.insurance.payment.thrift.TRQueryChannelConfig;
import com.xiaomi.mifi.insurance.payment.thrift.TRQueryOrderStatus;
import com.xiaomi.mifi.insurance.payment.thrift.TRQueryCounterInfoData;
import com.xiaomi.mifi.insurance.payment.thrift.TRRefundDetails;
import com.xiaomi.mifi.insurance.payment.thrift.TRReturnResponse;
import com.xiaomi.mifi.insurance.payment.thrift.TRSubmitPayment;
import com.xiaomi.mifi.insurance.payment.thrift.TRTradeDetails;
import com.xiaomi.mifi.insurance.payment.thrift.TRWithdrawResponse;
import com.xiaomi.mifi.notify.thrift.service.NotifyStatus;
import com.xiaomi.mifi.insurance.payment.thrift.PaymentStatistic;
import com.xiaomi.mifi.paycenter.thrift.service.TNotifyStatus;
import com.xiaomi.mifi.payment.biz.DeductBiz;
import com.xiaomi.mifi.payment.biz.NotifyBiz;
import com.xiaomi.mifi.payment.biz.RefundBiz;
import com.xiaomi.mifi.payment.biz.StatBiz;
import com.xiaomi.mifi.payment.biz.StatisticBiz;
import com.xiaomi.mifi.payment.biz.SupportChannelsBiz;
import com.xiaomi.mifi.payment.biz.TradeBiz;
import com.xiaomi.mifi.payment.biz.facade.PaymentFacade;
import com.xiaomi.mifi.payment.biz.facade.PaymentFacadeRegistry;
import com.xiaomi.mifi.payment.dao.StatDAO;
import com.xiaomi.mifi.payment.exception.PaymentGatewayResponseException;
import com.xiaomi.mifi.payment.gateway.PaymentGateway;
import com.xiaomi.mifi.payment.gateway.PaymentGatewayRegistry;
import com.xiaomi.mifi.payment.model.CommitPayRequest;
import com.xiaomi.mifi.payment.model.CommitPayResult;
import com.xiaomi.mifi.payment.model.CommitRefundRequest;
import com.xiaomi.mifi.payment.model.CommitRefundResult;
import com.xiaomi.mifi.payment.model.PayResult;
import com.xiaomi.mifi.payment.model.PaymentChannel;
import com.xiaomi.mifi.payment.proxy.BServiceProxy;
import com.xiaomi.mifi.payment.thrift.CardType;
import com.xiaomi.mifi.payment.thrift.Channel;
import com.xiaomi.mifi.payment.thrift.DeductTradeDetail;
import com.xiaomi.mifi.payment.thrift.Notify;
import com.xiaomi.mifi.payment.thrift.PaymentStatus;
import com.xiaomi.mifi.payment.thrift.RefundDetail;
import com.xiaomi.mifi.payment.thrift.SupportChannels;
import com.xiaomi.mifi.payment.thrift.TPRefund;
import com.xiaomi.mifi.payment.thrift.TRDetailListRequest;
import com.xiaomi.mifi.payment.thrift.TRDetailListResponse;
import com.xiaomi.mifi.payment.thrift.TRRefundDetailList;
import com.xiaomi.mifi.payment.thrift.TRRefundResponse;
import com.xiaomi.mifi.payment.thrift.TRTradeDetail;
import com.xiaomi.mifi.payment.thrift.TRTradeDetailList;
import com.xiaomi.mifi.payment.thrift.TradeDetail;
import com.xiaomi.mifi.payment.thrift.TradeStatus;
import com.xiaomi.mifi.payment.thrift.TradeType;
import com.xiaomi.mifi.payment.util.ConvertUtils;
import com.xiaomi.mifi.payment.util.PayCenterUtils;
import com.xiaomi.mifi.payment.util.ValidateUtils;
import com.xiaomi.mifi.payment.util.WeixinPayUtils;

@Service
public class ServiceProxy {

    private static final Logger LOGGER = LoggerFactory.getLogger(ServiceProxy.class);

    @Autowired
    PaymentGatewayRegistry registry;

    @Autowired
    private PaymentFacadeRegistry paymentFacadeRegistry;

    @Autowired
    private TradeBiz tradeBiz;

    @Autowired
    private NotifyBiz notifyBiz;

    @Autowired
    private RefundBiz refundBiz;

    @Autowired
    private DeductBiz deductBiz;

    @Autowired
    private SupportChannelsBiz supportChannelsBiz;

    @Autowired
    private BServiceProxy bServiceProxy;

    @Autowired
    private StatisticBiz statisticBiz;

    @Autowired
    private StatBiz statBiz;

    public TRWithdrawResponse requestWithdraw(TPWithdrawRequest request) {
        PaymentGatewayName gateway = request.getGateway();

        PaymentGateway paymentGateway = registry.getPaymentGateway(gateway);

        TRWithdrawResponse ret = new TRWithdrawResponse();
        if (paymentGateway == null) {
            LOGGER.info("fail to request withdraw, payment gateway not found, name: {}", gateway);
            ret.setResponse(getResponse(ErrorCode.GATEWAY_NOT_FOUND));
            return ret;
        }

        Map<PaymentRequestParam, String> params = request.getParams();
        if (params == null) {
            LOGGER.info("fail to request withdraw, params is null");
            ret.setResponse(getResponse(ErrorCode.MISS_PARAM));
            return ret;
        }

        Map<PaymentResponseParam, String> responseValues = null;
        try {
            responseValues = paymentGateway.applyWithdraw(params);
        } catch (ServiceLogicException e) {
            ret.setResponse(getResponse(e));
            return ret;
        } catch (PaymentGatewayResponseException e) {
            // 支付通道返回了错误，提现失败了
            ret.setResponse(getResponse(e));
            return ret;
        }

        ret.setParams(responseValues);
        ret.setResponse(getSuccessResponse());

        return ret;
    }

    public TRQueryBill queryMerchantBill(TPQueryBill param) {
        PaymentGatewayName gateway = param.getGateway();

        PaymentGateway paymentGateway = registry.getPaymentGateway(gateway);
        boolean isBackfee = param.getChannelId() == 1;
        TRQueryBill ret = new TRQueryBill();
        if (paymentGateway == null) {
            LOGGER.info("fail to query merchant bill, payment gateway not found, name: {}", gateway);
            ret.setResponse(getResponse(ErrorCode.GATEWAY_NOT_FOUND));
            return ret;
        }

        Date billDate = new Date(param.getBillPeriod().getDate());
        String billDateStr = PayCenterUtils.formatBillDate(billDate);
        BillType billType = param.getBillType();
        try {
            List<TRBillDetail> billList = new ArrayList<TRBillDetail>(0);
            LOGGER.info("to query merchant bill, gateway.getValue(): {}", gateway.getValue());
            if (isBackfee) {
                billList = paymentGateway.queryBill(billDateStr, billType);
            } else {
                billList = paymentGateway.queryNewBill(billDateStr, billType);
            }
            ret.setBills(billList);
        } catch (ServiceLogicException e) {
            ret.setResponse(getResponse(e));
            return ret;
        } catch (PaymentGatewayResponseException e) {
            ret.setResponse(getResponse(e));
            return ret;
        }
        ret.setResponse(getSuccessResponse());
        LOGGER.info("queryMerchantBill response: {}", ret);
        return ret;
    }

    public TRQueryCounterInfo queryCounterInfo(TPQueryCounterInfo param) {
        LOGGER.info("ServiceProxy.querying counter info, params: {}", param);
        // check sign
        long prepayId = param.getPrepayId();
        String sign = param.getSign();

        TRQueryCounterInfo ret = new TRQueryCounterInfo();

        try {
            ArgumentChecker.checkGtZero(prepayId);
            ArgumentChecker.checkNotEmpty(sign);
        } catch (ServiceLogicException e) {
            LOGGER.error("fail to get counter info, check param failed", e);
            ret.setResponse(getResponse(e));
            return ret;
        }
        try {
            TRQueryCounterInfoData counterInfo = tradeBiz.getCounterInfo(prepayId, sign);
            List<PayChannelInfo> channelConfig = supportChannelsBiz
                    .getChannelConfig(com.xiaomi.mifi.insurance.payment.thrift.TradeType.PAY, prepayId);
            counterInfo.setPayChannel(channelConfig);
            supportChannelsBiz.filterChannel(channelConfig, param);
            ret.setData(counterInfo);
        } catch (ServiceLogicException e) {
            LOGGER.error("fail to get trade data for counter", e);
            ret.setResponse(getResponse(e));
            return ret;
        }

        LOGGER.info("get counter info successfully, transaction id: {}", prepayId);
        ret.setResponse(getSuccessResponse());

        return ret;
    }

    public TRSubmitPayment submitPayment(TPSubmitPayment tpSubmitPayment) {
        LOGGER.info("ServiceProxy.submitPayment is invoked, tpSubmitPayment is {}", tpSubmitPayment);
        boolean validateSubmitPayment = ValidateUtils.validateTPSubmitPayment(tpSubmitPayment);

        TRSubmitPayment ret = new TRSubmitPayment();
        if (!validateSubmitPayment) {
            ret.setResponse(getResponse(ErrorCode.INVALID_PARAM));
            return ret;
        }

        long transactionId;
        try {
            transactionId = Long.parseLong(tpSubmitPayment.getPrepayId());
        } catch (Exception e) {
            LOGGER.error("fail to submit payment, error when parse prepay id", e);
            ret.setResponse(getResponse(ErrorCode.INVALID_PARAM));
            return ret;
        }

        boolean verified = tradeBiz.verifyTrade(transactionId, tpSubmitPayment.getSign());
        LOGGER.debug("trade sign verified when submit payment: {}, transaction id: {}", verified, transactionId);

        if (!verified) {
            LOGGER.warn("trade sign not verified, transaction id: {}", transactionId);
            ret.setResponse(getResponse(ErrorCode.INVALID_PARAM));
            return ret;
        }

        TradeDetail tradeDetail = tradeBiz.findByTransactionId(transactionId);
        // 没有找到订单,直接返回失败
        if (tradeDetail == null) {
            LOGGER.warn("ServiceProxy.submitPayment tradeDetail is null, tpSubmitPayment is {}", tpSubmitPayment);
            ret.setResponse(getResponse(ErrorCode.ORDER_NOT_FOUND));
            return ret;
        }

        // trade状态不为INIT或WAIT_PAY的状态，返回错误
        try {
            TradeBiz.checkTradeStatus(tradeDetail, TradeStatus.INIT, TradeStatus.WAIT_PAY);
        } catch (ServiceLogicException e) {
            LOGGER.error("fail to submit payment, incorrect trade status, current status: {}", tradeDetail.getTradeStatus());
            ret.setResponse(getResponse(e));
            return ret;
        }

        // 判断是否过期了
        if (tradeBiz.isExpiredAndUpdate(transactionId)) {
            notifyBiz.sendNotify(transactionId);
        }

        Notify notify = notifyBiz.findNotifyByOrderId(tradeDetail.getOrderId(),
                TradeType.PAY.getValue());
        if (checkTradeFinish(tradeDetail, notify)) {
            LOGGER.info("trade is already success but not notify, send notify. tradeDetail: {}, notify:{}", tradeDetail, notify);
            notifyBiz.sendNotify(tradeDetail.getTransactionId());
        }

        try {
            return submitPayment(tpSubmitPayment, tradeDetail);
        } catch (ServiceLogicException e) {
            LOGGER.error("error when submit payment", e);
            ret.setResponse(getResponse(e));
            return ret;
        }
    }

    public TRRefundResponse refund(TPRefund tpRefund) {
        LOGGER.info("ServiceProxy.refund, tpRefund: {}", tpRefund);
        if (tpRefund == null) {
            LOGGER.error("tpRefund is empty");
            return getTRRefundResponse(ErrorCode.PARAMETER_ERROR, null);
        }
        boolean isValidate = ValidateUtils.validateTPRefund(tpRefund);
        if (!isValidate) {
            LOGGER.error("tpRefund is not validate, tpRefund is {}", tpRefund);
            return getTRRefundResponse(ErrorCode.PARAMETER_ERROR, null);
        }
        boolean isUpdate = false;
        RefundDetail refundOriginDetail = queryRefundInfo(tpRefund.getOrderId());
        Notify refundOriginNotify = queryNotify(tpRefund.orderId, TradeType.REFUND.getValue());
        if (refundOriginDetail != null) {
            // 已存在退款记录且不是失败的记录,就不允许再退款
            if (refundOriginDetail.getStatus() != TradeStatus.FAIL.getValue()) {
                LOGGER.error("Already exists a refund but is not fail, should not repeat refund. tpRefund is {}",
                        tpRefund);
                return getTRRefundResponse(ErrorCode.REPEATED_REFUND, null);
            } else {
                if (refundOriginNotify != null) {
                    isUpdate = true;
                }
            }
        } else {
            // 已存在退款通知记录但是不存在退款记录,此时是异常订单状态
            if (refundOriginNotify != null) {
                LOGGER.error("Refund notify exists but the related refund does not exist! tpRefund is {}", tpRefund);
                return getTRRefundResponse(ErrorCode.INCORRECT_TRANSACTION_STATUS, null);
            }
        }

        // 查询原始订单
        TradeDetail originTradeDetail = tradeBiz.queryPaymentInfo(tpRefund.getOrderId());
        // 不存在原始订单
        if (originTradeDetail == null) {
            LOGGER.error("original tradeDetail does not exist! tpRefund is {}", tpRefund);
            // 代扣退款
            DeductTradeDetail deductTradeDetail = deductBiz.findByOrderId(tpRefund.getOrderId());
            if (deductTradeDetail == null) {
                return getTRRefundResponse(ErrorCode.ORDER_NOT_FOUND, null);
            } else {
                originTradeDetail = new TradeDetail();
                originTradeDetail.setTradeStatus(deductTradeDetail.getTradeStatus());
                originTradeDetail.setPaymentStatus(deductTradeDetail.getPaymentStatus());
                originTradeDetail.setTotalFee(deductTradeDetail.getTotalFee());
                originTradeDetail.setCurrency(deductTradeDetail.getCurrency());
                originTradeDetail.setTransactionId(deductTradeDetail.getTransactionId());
                originTradeDetail.setTradeId(deductTradeDetail.getTradeId());
                originTradeDetail.setChannel(PaymentChannel.MICASH.getIndex());
                originTradeDetail.setTradeType(TradeType.DEDUCT_REFUND.getValue());
            }
        }
        // 原始订单存在,但是状态不是已成功完成的,不能提交
        if (originTradeDetail.getTradeStatus() != TradeStatus.SUCCESS.getValue()
                || originTradeDetail.getPaymentStatus() != PaymentStatus.SUCCESS.getValue()) {
            LOGGER.error("original tradeDetail not success, should not refund! tpRefund is {}", tpRefund);
            return getTRRefundResponse(ErrorCode.INCORRECT_TRANSACTION_STATUS, null);
        }
        // 原始订单金额和退款金额不一样的,认为是参数错误
        if (originTradeDetail.getTotalFee() != tpRefund.getAmount()) {
            LOGGER.error("original tradeDetail amount not equal with refund amount. trade amount is {}, tpRefund is {}",
                    originTradeDetail.getTotalFee(), tpRefund);
            return getTRRefundResponse(ErrorCode.PARAMETER_ERROR, null);
        }
        if (originTradeDetail.getCurrency() != tpRefund.getCurrency().getValue()) {
            LOGGER.error(
                    "original tradeDetail currency not equal with refund currency. trade currency is {}, tpRefund is {}",
                    originTradeDetail.getCurrency(), tpRefund);
            return getTRRefundResponse(ErrorCode.PARAMETER_ERROR, null);
        }

        RefundDetail refundDetail = ConvertUtils.convertTPRefund2RefundDetail(tpRefund);
        Notify notify = ConvertUtils.convertTPRefund2Notify(tpRefund);
        try {
            refundDetail.setRefundTransactionId(bServiceProxy.getId());
            notify.setNotifyId(bServiceProxy.getId());
        } catch (ServiceLogicException e) {
            LOGGER.error("idCenter getId error, tpPay orderId is {}", refundDetail.getOrderId());
            return getTRRefundResponse(ErrorCode.INTERNAL_SERVER_ERROR, refundDetail);
        }
        notify.setTransactionId(refundDetail.getRefundTransactionId());
        refundDetail.setOriginTransactionId(originTradeDetail.getTransactionId());
        refundDetail.setOriginTradeId(originTradeDetail.getTradeId());
        refundDetail.setChannel(originTradeDetail.getChannel());
        if (originTradeDetail.getTradeType() == TradeType.DEDUCT_REFUND.getValue()) {
            refundDetail.setTradeType(originTradeDetail.getTradeType());
            notify.setTradeType(originTradeDetail.getTradeType());
        }

        LOGGER.info("Ready to submit refund, refundDetail is {}", refundDetail);
        if (!isUpdate) {
            return submitNewRefund(refundDetail, notify);
        } else {
            refundOriginDetail.setStatus(TradeStatus.INIT.getValue());
            refundOriginDetail.setUpdateTime(System.currentTimeMillis());
            refundOriginNotify.setUpdateTime(System.currentTimeMillis());
            refundOriginNotify.setNotifyStatus(TNotifyStatus.NOT_START.getValue());
            return updateAndSubmitRefund(refundOriginDetail, refundOriginNotify);
        }
    }

    public TRTradeDetail queryPaymentInfo(long orderId) {
        LOGGER.info("ServiceProxy.queryPaymentInfo, orderId: {}", orderId);
        TRTradeDetail trTradeDetail = new TRTradeDetail();
        if (orderId > 0) {
            TradeDetail tradeDetail = tradeBiz.queryPaymentInfo(orderId);
            if (tradeDetail != null) {
                trTradeDetail.setResponse(getResponse(ErrorCode.SUCCESS));
                trTradeDetail.setTradeDetail(tradeDetail);
            } else {
                trTradeDetail.setResponse(getResponse(ErrorCode.ORDER_NOT_FOUND));
                trTradeDetail.setTradeDetail(null);
            }
        } else {
            trTradeDetail.setResponse(getResponse(ErrorCode.PARAMETER_ERROR));
            trTradeDetail.setTradeDetail(null);
        }
        return trTradeDetail;
    }

    public TRTradeDetailList queryTradeDetails(long beginTime, long endTime, TradeStatus tradeStatus, int offset, int length) {
        LOGGER.info("ServiceProxy.queryTradeDetails, begin: {}, end: {}, tradeStatus: {}", beginTime, endTime,
                tradeStatus);
        TRTradeDetailList trTradeDetailList = new TRTradeDetailList();
        List<TradeDetail> list = tradeBiz.queryTradeDetails(beginTime, endTime, tradeStatus, offset, length);
        trTradeDetailList.setResponse(getResponse(ErrorCode.SUCCESS));
        trTradeDetailList.setDetails(list);
        return trTradeDetailList;
    }

    public TRReturnResponse receiveReturnUrl(Map<String, String> tpReturnParam) {
        LOGGER.info("ServiceProxy.receiveReturnUrl tpReturnParam: {}", tpReturnParam);
        String channel = tpReturnParam.get("channel");
        TRReturnResponse trReturnResponse = new TRReturnResponse();
        if (channel == null) {
            trReturnResponse.setResponse(getResponse(ErrorCode.PARAMETER_ERROR));
            return trReturnResponse;
        }
        PaymentFacade paymentFacade = paymentFacadeRegistry.getPaymentFacade(PaymentChannel.getPayChannel(Integer.valueOf(channel)));
        if (paymentFacade == null) {
            LOGGER.warn("paymentFacadeRegistry.getPaymentFacade return null, tpReturnParam: {}", tpReturnParam);
            trReturnResponse.setResponse(getResponse(ErrorCode.REQUEST_FAILED));
            return trReturnResponse;
        }
        try {
            TradeDetail tradeDetail = paymentFacade.getTradeDetailFromReturnParam(tpReturnParam);
            trReturnResponse.setResponse(getResponse(ErrorCode.SUCCESS));
            String returnParams = tradeBiz.createTradeReturnUrlParameter(tradeDetail.getOrderId());
            trReturnResponse.setReturnRedirectUrl(tradeDetail.getReturnUrl() + "?" + returnParams);
            LOGGER.info("receiveReturnUrl: {} ", trReturnResponse.getReturnRedirectUrl());
            PerfCounter.count("ServiceProxyReceiveReturnUrlSuccess", 1);
            return trReturnResponse;
        } catch (ServiceLogicException e) {
            trReturnResponse.setResponse(getResponse(ErrorCode.INVALID_PARAM));
            PerfCounter.count("ServiceProxyReceiveReturnUrlFailure", 1);
            return trReturnResponse;
        }
    }

    private RefundDetail queryRefundInfo(long orderId) {
        LOGGER.info("ServiceProxy.queryRefundInfo, orderId: {}", orderId);
        return refundBiz.findRefundByOrderId(orderId);
    }

    private Notify queryNotify(long orderId, int tradeType) {
        LOGGER.info("ServiceProxy.queryNotify, orderId: {}, tradeType", orderId, tradeType);
        return notifyBiz.findNotifyByOrderId(orderId, tradeType);
    }

    private TRSubmitPayment submitPayment(TPSubmitPayment tpSubmitPayment, TradeDetail tradeDetail) throws ServiceLogicException {
        long transactionId = tradeDetail.getTransactionId();
        long orderId = tradeDetail.getOrderId();
        LOGGER.info("ServiceProxy.submitting payment, TPSubmitPayment {}, transaction id: {}, order id: {}",
                tpSubmitPayment, transactionId, orderId);

        List<SupportChannels> querySupportChannels = supportChannelsBiz.querySupportChannels(orderId);
        LOGGER.debug("allowed pay channel count: {}, transaction id: {}", querySupportChannels.size(), transactionId);
        // 查找允许使用的支付渠道
        int channelId = 0;

        HashSet<CardType> allowedCardTypes = new HashSet<>();
        for (SupportChannels querySupportChannel : querySupportChannels) {
            if (tpSubmitPayment.getChannelId() == querySupportChannel.getChannel()) {
                int cardTypeValue = querySupportChannel.getCardType();
                CardType cardType = CardType.findByValue(cardTypeValue);
                // 添加卡类型
                if (cardType != null) {
                    allowedCardTypes.add(cardType);
                }
                channelId = querySupportChannel.getChannel();
            }
        }

        if (channelId == 0) {
            LOGGER.warn("fail to submit payment, channel id not found, transaction id: {}, user selected channel: {}", transactionId, tpSubmitPayment.getChannelId());
            throw ServiceLogicException.INVALID_PARAM;
        }

        LOGGER.info("get pay channel and card types for trade, transaction id: {}, channel id: {}, allowed card types: {}", transactionId, channelId, allowedCardTypes);

        // 先更新trade状态
        tradeDetail.setCreateIp(tpSubmitPayment.getCreateIp());
        boolean success = tradeBiz.submitTrade(tradeDetail, channelId);
        if (!success) {
            LOGGER.warn("fail to submit trade, trade status incorrect, transaction id: {}", transactionId);
            throw ServiceLogicException.INCORRECT_TRANSACTION_STATUS;
        }
        LOGGER.info("update trade status to submitted, transaction id: {}", transactionId);

        // 再生成支付串
        PaymentFacade paymentFacade = paymentFacadeRegistry
                .getPaymentFacade(PaymentChannel.getPayChannel(channelId));
        if (paymentFacade == null) {
            LOGGER.warn("paymentFacade is null, tradeDetail: {}, tpSubmitPayment: {}", tradeDetail,
                    tpSubmitPayment);
            throw ServiceLogicException.INVALID_PARAM;
        }
        CommitPayRequest commitPayRequest = paymentFacade.generatePayment(tradeDetail);
        commitPayRequest.setAllowedCardType(allowedCardTypes);
        CommitPayResult commitPayResult = paymentFacade.commitPay(commitPayRequest);
        if (commitPayResult.isSuccess()) {
            LOGGER.info("paymentFacade.commitPay is success, commitPayResult {}", commitPayResult);
            return getTRSubmitPayment(ErrorCode.SUCCESS, commitPayResult.getMethod(), commitPayResult.getUrl(),
                    commitPayResult.getParams());
        }
        LOGGER.warn("fail to generate pay request, transaction id: {}", transactionId);
        throw ServiceLogicException.INVALID_PARAM;
    }

    @Transactional
    public TRRefundResponse updateAndSubmitRefund(RefundDetail refundDetail, Notify notify) {
        LOGGER.info("ServiceProxy.updateAndSubmitRefund, refundDetail: {}, notify: {}", refundDetail, notify);
        int updateRefundDetailRow = refundBiz.updateRefundDetail(refundDetail);
        int updateNotifyRow = notifyBiz.updateNotify(notify);
        if (updateNotifyRow > 0 && updateRefundDetailRow > 0) {
            LOGGER.info("refund insert and update table SUCCESS. transactionId : {}, notifyId : {}",
                    refundDetail.getRefundTransactionId(), notify.getNotifyId());
            return submitRefund(refundDetail, notify);
        } else {
            LOGGER.error("refund update table ERROR. transactionId : {}, notifyId : {}",
                    refundDetail.getRefundTransactionId(), notify.getNotifyId());
            return getTRRefundResponse(ErrorCode.DB_UPDATE_FAIL, refundDetail);
        }
    }

    private TRRefundResponse submitRefund(RefundDetail refundDetail, Notify notify) {
        LOGGER.info("ServiceProxy.submitRefund, refundDetail: {}, notify: {}", refundDetail, notify);
        // 对于已完成但还没通知的订单,进行一次通知,然后返回重复提交的订单错误.
        if (checkRefundFinish(refundDetail, notify)) {
            LOGGER.info("tradeDetail finished, send notify and return directly");
            notifyBiz.sendRefundNotify(refundDetail.getOriginTransactionId());
            return getTRRefundResponse(ErrorCode.REPEATED_ORDER, refundDetail);
        }

        refundDetail.setStatus(TradeStatus.INIT.getValue());
        refundDetail.setPaymentStatus(PaymentStatus.COMMIT.getValue());
        refundDetail.setUpdateTime(System.currentTimeMillis());
        int updateRow = refundBiz.updateRefundDetail(refundDetail);
        if (updateRow > 0) {
            LOGGER.info("submitRefund update table SUCCESS. transactionId : {}", refundDetail.getOriginTransactionId());
            PaymentFacade paymentFacade = paymentFacadeRegistry
                    .getPaymentFacade(PaymentChannel.getPayChannel(refundDetail.getChannel()));
            if (paymentFacade == null) {
                LOGGER.error("paymentFacade not found, refund channel is {}", refundDetail.getChannel());
                return getTRRefundResponse(ErrorCode.PARAMETER_ERROR, refundDetail);
            }
            CommitRefundRequest commitRefundRequest = paymentFacade.generateRefund(refundDetail);
            CommitRefundResult commitRefundResult = paymentFacade.commitRefund(commitRefundRequest);
            refundDetail = refundBiz.findRefundByTransactionId(refundDetail.getRefundTransactionId());
            return paymentFacade.convertCommitRefundResult(commitRefundResult, refundDetail);
        } else {
            LOGGER.error("submitRefund update table ERROR. transactionId : {}", refundDetail.getOriginTransactionId());
            return getTRRefundResponse(ErrorCode.DB_UPDATE_FAIL, refundDetail);
        }
    }

    @Transactional
    public TRRefundResponse submitNewRefund(RefundDetail refundDetail, Notify notify) {
        LOGGER.info("ServiceProxy.submitNewRefund, refundDetail: {}, notify: {}", refundDetail, notify);
        long refundInsertRow = refundBiz.insertRefundDetail(refundDetail);
        long notifyInsertRow = notifyBiz.insertNotify(notify);
        if (refundInsertRow > 0 && notifyInsertRow > 0) {
            refundDetail.setId(refundInsertRow);
            notify.setId(notifyInsertRow);
            return submitRefund(refundDetail, notify);
        } else {
            LOGGER.error("refund insert table ERROR. transactionId : {}, notifyId : {}",
                    refundDetail.getRefundTransactionId(), notify.getNotifyId());
            return getTRRefundResponse(ErrorCode.DB_INSERT_FAIL, refundDetail);
        }
    }

    public TRTradeDetailList querySuccessTradeDetails(long beginTime, long endTime, int channel) {
        LOGGER.info("ServiceProxy.querySuccessTradeDetails, begin: {}, end: {}, channel: {}", beginTime, endTime,
                channel);
        TRTradeDetailList result = new TRTradeDetailList();
        List<TradeDetail> list = tradeBiz.querySuccessTradeDetail(beginTime, endTime, channel);
        result.setResponse(getSuccessResponse());
        result.setDetails(list);
        return result;
    }

    public TRRefundDetailList querySuccessRefundDetails(long beginTime, long endTime, int channel) {
        LOGGER.info("ServiceProxy.querySuccessRefundDetails, begin: {}, end: {}, channel: {}", beginTime, endTime,
                channel);
        return refundBiz.querySuccessRefundDetail(beginTime, endTime, channel);
    }

    private boolean checkTradeFinish(TradeDetail tradeDetail, Notify notify) {
        return tradeDetail.getTradeStatus() == TradeStatus.SUCCESS.getValue()
                && tradeDetail.getPaymentStatus() == PaymentStatus.SUCCESS.getValue()
                && notify.getNotifyStatus() != TNotifyStatus.SUCCESS.getValue();
    }

    private boolean checkRefundFinish(RefundDetail refundDetail, Notify notify) {
        return refundDetail.getStatus() == TradeStatus.SUCCESS.getValue()
                && refundDetail.getPaymentStatus() == PaymentStatus.SUCCESS.getValue()
                && notify.getNotifyStatus() != TNotifyStatus.SUCCESS.getValue();
    }

    public TRDetailListResponse querySuccessTradeRefundDetails(TRDetailListRequest request) {
        LOGGER.info("ServiceProxy.querySuccessTradeRefundDetails, param: beginTime={},endTime={},tradeType={}",
                request.getBeginTime(), request.getEndTime(), request.getTradeType());
        TRDetailListResponse response = new TRDetailListResponse();
        if (request.getBeginTime() == 0 || request.getEndTime() == 0) {
            LOGGER.error("param error ServiceProxy.querySuccessTradeRefundDetails");
            response.setResponse(ResponseUtils.getResponse(ErrorCode.PARAMETER_ERROR));
            return response;
        }
        if (TradeType.PAY.getValue() == request.getTradeType()) {// 支付
            response = tradeBiz.querySuccessTradeDetailList(request);
        } else if (TradeType.REFUND.getValue() == request.getTradeType()) {// 退款
            response = refundBiz.querySuccessRefundDetailList(request);
        } else if (TradeType.DEDUCT.getValue() == request.getTradeType()) {// 代扣
            response = deductBiz.querySuccessDeductTradeDetailList(request);
        }

        return response;
    }

    public boolean notifyCashpayPay(Map<String, String> params) {
        PaymentFacade paymentFacade = paymentFacadeRegistry.getPaymentFacade(PaymentChannel.MICASH);
        if (null == paymentFacade) {
            LOGGER.warn("ServiceProxy.notifyCashpayPay, cannot get MICash payment facade instance.");
            return false;
        }
        if (!paymentFacade.verifyPayParam(params)) {
            LOGGER.warn("ServiceProxy.notifyCashpayPay, verify params failed, request params is:{}", params);
            return false;
        }

        PaymentGateway paymentGateway = registry.getPaymentGateway(PaymentGatewayName.CASHPAY);
        processPayNotify(paymentGateway, params, Channel.CASHPAY);
        return true;
    }

    public boolean notifyCashpayDeduct(Map<String, String> params) {
        LOGGER.info("notify deduct params {}", params);
        PaymentFacade paymentFacade = paymentFacadeRegistry.getPaymentFacade(PaymentChannel.MICASH);
        if (null == paymentFacade) {
            LOGGER.warn("ServiceProxy.notifyCashpayPay, cannot get MICash payment facade instance.");
            return false;
        }
        if (!paymentFacade.verifyPayParam(params)) {
            LOGGER.warn("ServiceProxy.notifyCashpayPay, verify params failed, request params is:{}", params);
            return false;
        }

        PaymentGateway paymentGateway = registry.getPaymentGateway(PaymentGatewayName.CASHPAY);
        processDeductNotify(paymentGateway, params);
        return true;
    }

    public boolean notifyCashpayRefund(Map<String, String> params) {
        PaymentFacade paymentFacade = paymentFacadeRegistry.getPaymentFacade(PaymentChannel.MICASH);
        if (null == paymentFacade) {
            LOGGER.warn("ServiceProxy.notifyCashpayRefund, cannot get MICash payment facade instance.");
            return false;
        }
        if (!paymentFacade.verifyRefundParam(params)) {
            LOGGER.warn("ServiceProxy.notifyCashpayRefund, verify params failed, request params is:{}", params);
            return false;
        }

        try {
            paymentFacade.notifyRefund(params);
        } catch (Exception e) {
            return false;
        }
        return true;
    }

    public boolean notifyAlipayPay(Map<String, String> params) {
        PaymentFacade paymentFacade = paymentFacadeRegistry.getPaymentFacade(PaymentChannel.ALIPAY);
        if (null == paymentFacade) {
            LOGGER.warn("ServiceProxy.notifyAlipayPay, cannot get alipay payment facade instance.");
            return false;
        }
        if (!paymentFacade.verifyPayParam(params)) {
            LOGGER.warn("ServiceProxy.notifyAlipayPay, verify params failed, request params is:{}", params);
            return false;
        }

        PaymentGateway paymentGateway = registry.getPaymentGateway(PaymentGatewayName.ALIPAY);
        processPayNotify(paymentGateway, params, Channel.ALIPAY);
        return true;
    }

    private void processPayNotify(PaymentGateway paymentGateway, Map<String, String> notificationParams,
            Channel channel) {
        LOGGER.info("process pay notify, payment gateway is {}, params is {}", paymentGateway, notificationParams);
        PayResult payResult = paymentGateway.parsePayNotify(notificationParams);

        // 异步通知的签名错误，说明请求不是来自支付中心，忽略
        if (ResponseStatus.STATUS_SIGN_MISMATCH.equals(payResult.getStatus())) {
            LOGGER.warn("incorrect signature of pay notify, do not update trade");
            return;
        }
        if (ResponseStatus.STATUS_INVALID_RESULT.equals(payResult.getStatus())) {
            // 支付机构发过来的通知无效，不作更新
            LOGGER.warn("pay notify is invalid, ignore it, pay center: {}", paymentGateway.getName());
            return;
        }
        long transactionId = payResult.getTransactionId();
        if (tradeBiz.updatePayResult(payResult, channel)) {
            LOGGER.info("trade is updated, transaction id: {}", transactionId);
            notifyBiz.sendNotify(transactionId);
        } else {
            LOGGER.warn("trade is not updated, transaction id: {}", transactionId);
        }
    }

    private void processDeductNotify(PaymentGateway paymentGateway, Map<String, String> notificationParams) {
        LOGGER.info("process pay notify, payment gateway is {}, params is {}", paymentGateway, notificationParams);
        PayResult payResult = paymentGateway.parsePayNotify(notificationParams);

        // 异步通知的签名错误，说明请求不是来自支付中心，忽略
        if (ResponseStatus.STATUS_SIGN_MISMATCH.equals(payResult.getStatus())) {
            LOGGER.warn("incorrect signature of pay notify, do not update trade");
            return;
        }
        if (ResponseStatus.STATUS_INVALID_RESULT.equals(payResult.getStatus())) {
            // 支付机构发过来的通知无效，不作更新
            LOGGER.warn("pay notify is invalid, ignore it, pay center: {}", paymentGateway.getName());
            return;
        }
        long transactionId = payResult.getTransactionId();
        if (deductBiz.updatePayResult(payResult)) {
            LOGGER.info("trade is updated, transaction id: {}", transactionId);
            notifyBiz.sendNotify(transactionId);
        } else {
            LOGGER.warn("trade is not updated, transaction id: {}", transactionId);
        }
    }

    // 目前超时订单不多，先不用考虑分页的情况
    public TRExpireTradesResponse queryExpiredTrades(int offset, int length) {
        LOGGER.info("ServiceProxy.queryExpiredTrades offset is {}, length is {}", offset, length);
        TRExpireTradesResponse trExpireTradesResponse = new TRExpireTradesResponse();
        List<Long> expiredTrades = tradeBiz.queryExpiredTrades(0, length);
        List<Long> expiredDeduct = deductBiz.queryExpiredTrades(0, length);
        List<Long> allExpires = new ArrayList<Long>();
        allExpires.addAll(expiredTrades);
        allExpires.addAll(expiredDeduct);
        trExpireTradesResponse.setExpiredTransactionIds(allExpires);
        trExpireTradesResponse.setResponse(getResponse(ErrorCode.SUCCESS));
        for (Long transactionId : expiredTrades) {
            LOGGER.warn("ServiceProxy.queryExpiredTrades find expired transactionId id: {}", transactionId);
        }
        return trExpireTradesResponse;
    }

    public TRResponse setTradeExpired(long transactionId) {
        if (tradeBiz.findByTransactionId(transactionId) != null) {
            return tradeBiz.setTradeExpired(transactionId);
        } else if (deductBiz.findByTransactionId(transactionId) != null) {
            return deductBiz.setTradeExpired(transactionId);
        }
        return ResponseUtils.getSuccessResponse();
    }

    public TRQueryOrderStatus queryOrderStatus(long orderId) {
        LOGGER.info("serviceProxy.queryOrderStatus orderId: {}", orderId);
        TRQueryOrderStatus trQueryOrderStatus = new TRQueryOrderStatus();
        TradeDetail tradeDetail = tradeBiz.queryPaymentInfo(orderId);
        RefundDetail refundDetail = refundBiz.findRefundByOrderId(orderId);
        if (tradeDetail != null) {
            com.xiaomi.mifi.insurance.payment.thrift.TradeDetail td = ConvertUtils.convertTradeDetail(tradeDetail);
            LOGGER.info("queryOrderStatus tradeDetail: {}", td);
            trQueryOrderStatus.setTradeDetail(td);
        }
        if (refundDetail != null) {
            com.xiaomi.mifi.insurance.payment.thrift.RefundDetail rd = ConvertUtils.convertRefundDetail(refundDetail);
            LOGGER.info("queryOrderStatus refundDetail: {}", rd);
            trQueryOrderStatus.setRefundDetail(rd);
        }
        trQueryOrderStatus.setResponse(getResponse(ErrorCode.SUCCESS));
        return trQueryOrderStatus;
    }

    public TRResponse setChannelSwitch(int channelId, boolean switchOn) {
        LOGGER.info("serviceProxy.setChannelSwitch channelId: {}, switchOn: {}", channelId, switchOn);
        boolean isSuccess = supportChannelsBiz.setChannelSwitch(channelId, switchOn);
        return isSuccess ? getResponse(ErrorCode.SUCCESS) : getResponse(ErrorCode.REQUEST_FAILED);
    }

    public TRTradeDetails queryDailyTrade(long startTime, int offset, int length) {
        LOGGER.info("serviceProxy.queryDailyTrade startTime: {}, offset: {}, length: {}", startTime, offset, length);
        TRTradeDetails trTradeDetails = new TRTradeDetails();
        List<com.xiaomi.mifi.insurance.payment.thrift.TradeDetail> list = new ArrayList<>();
        List<TradeDetail> tradeDetailList = tradeBiz.queryDailyTrade(startTime, offset, length);
        for (TradeDetail tradeDetail : tradeDetailList) {
            com.xiaomi.mifi.insurance.payment.thrift.TradeDetail td = ConvertUtils.convertTradeDetail(tradeDetail);
            list.add(td);
        }
        LOGGER.info("serviceProxy.queryDailyTrade found {} tradeDetails.", tradeDetailList.size());
        trTradeDetails.setResponse(getResponse(ErrorCode.SUCCESS));
        trTradeDetails.setTradeDetails(list);
        return trTradeDetails;
    }

    public TRRefundDetails queryDailyRefund(long startTime, int offset, int length) {
        LOGGER.info("serviceProxy.queryDailyRefund startTime: {}, offset: {}, length: {}", startTime, offset, length);
        TRRefundDetails trRefundDetails = new TRRefundDetails();
        List<com.xiaomi.mifi.insurance.payment.thrift.RefundDetail> list = new ArrayList<>();
        List<RefundDetail> refundDetailList = refundBiz.queryDailyRefund(startTime, offset, length);
        for (RefundDetail refundDetail : refundDetailList) {
            com.xiaomi.mifi.insurance.payment.thrift.RefundDetail rd = ConvertUtils.convertRefundDetail(refundDetail);
            list.add(rd);
        }
        LOGGER.info("serviceProxy.queryDailyRefund found {} refundDetails.", refundDetailList.size());
        trRefundDetails.setResponse(getResponse(ErrorCode.SUCCESS));
        trRefundDetails.setRefundDetails(list);
        return trRefundDetails;
    }

    public TRQueryChannelConfig queryChannelConfig() {
        LOGGER.info("serviceProxy.queryChannelConfig");
        TRQueryChannelConfig trQueryChannelConfig = new TRQueryChannelConfig();
        trQueryChannelConfig.setResponse(getResponse(ErrorCode.SUCCESS));
        List<ChannelConfig> channelConfigs = supportChannelsBiz.queryChannelConfigs();
        trQueryChannelConfig.setChannels(channelConfigs);
        return trQueryChannelConfig;
    }

    public boolean reportDailyStatistic(List<PaymentStatistic> paymentStatistics) {
        LOGGER.info("serviceProxy.reportDailyStatistic");
        for (PaymentStatistic paymentStatistic : paymentStatistics) {
            LOGGER.info("serviceProxy.reportDailyStatistic paymentStatistic: {}", paymentStatistic);
            statisticBiz.reportDailyStatistic(paymentStatistic);
        }
        return true;
    }

    public List<PaymentStatistic> queryAllPaymentStatistic(int offset, int length) {
        LOGGER.info("serviceProxy.queryAllPaymentStatistic offset: {}, length: {}", offset, length);
        return statisticBiz.queryAllPaymentStatistic(offset, length);
    }

    public List<PaymentStatistic> queryPaymentStatisticByDate(String date) {
        LOGGER.info("serviceProxy.queryPaymentStatisticByDate date: {}", date);
        return statisticBiz.queryPaymentStatisticByDate(date);
    }
    
    public String nofityWeixinPay(String response) {
        LOGGER.info("ServiceProxy.nofityWeixinPay response {}", response);
        String result = WeixinPayUtils.getSuccessResponse();
        PaymentFacade paymentFacade = paymentFacadeRegistry.getPaymentFacade(PaymentChannel.WECHAT);
        if (null == paymentFacade) {
            LOGGER.warn("ServiceProxy.notifyWeixinPay, cannot get Weixin payment facade instance.");
            PerfCounter.count("weixinPaymentFacadeNotFound", 10);
            return WeixinPayUtils.getFailResponse(com.mifi.insurance.payment.util.ErrorCode.INTERNAL_SERVER_ERROR);
        }
        Map<String, String> params = WeixinPayUtils.xmlDataToMap(response);
        if (!paymentFacade.verifyPayParam(params)) {
            LOGGER.warn("ServiceProxy.notifyWeixinPay, verify params failed, request params is:{}", params);
            return WeixinPayUtils.getFailResponse(com.mifi.insurance.payment.util.ErrorCode.INVALID_PARAM);
        }

        PaymentGateway paymentGateway = registry.getPaymentGateway(PaymentGatewayName.WEICHAT);
        processPayNotify(paymentGateway, params, Channel.WECHAT);
        LOGGER.info("result {}", result);
        return result;
    }

    /**
     * 人工手动通知业务方
     */
    public TRResponse notifyBusiness(String type, long orderId) {
        if (Strings.isNullOrEmpty(type) || type.equals("PAY")) {
            return notifyBiz.notifyTrade(orderId);
        } else if (type.equals("DEDUCT")) {
            return notifyBiz.noditfyDeduct(orderId);
        } else if (type.equals("REFUND")) {
            return notifyBiz.notifyRefund(orderId);
        }
        return ResponseUtils.getSuccessResponse();
    }

    public List<com.xiaomi.mifi.insurance.payment.thrift.DeductTradeDetail> getDeductTradeNoNotify(long time) {
        LOGGER.info("get deduct trade no notify time {}", time);
        List<com.xiaomi.mifi.insurance.payment.thrift.DeductTradeDetail> ret = statBiz.getDeductTradeNoNotify(time);
        LOGGER.info("get deduct trade no notify result {}", ret);
        return ret;
    }

    public List<com.xiaomi.mifi.insurance.payment.thrift.TradeDetail> getTradeNoNotify(long time) {
        LOGGER.info("get trade no notify time {}", time);
        List<com.xiaomi.mifi.insurance.payment.thrift.TradeDetail> ret = statBiz.getTradeNoNotify(time);
        LOGGER.info("get trade no notify result {}", ret);
        return ret;
    }

    public List<com.xiaomi.mifi.insurance.payment.thrift.RefundDetail> getRefundNoNotify(long time) {
        LOGGER.info("get refund no notify time {}", time);
        List<com.xiaomi.mifi.insurance.payment.thrift.RefundDetail> ret = statBiz.getRefundNoNotify(time);
        LOGGER.info("get refund no notify result {}", ret);
        return ret;
    }

    // TODO : delete
    /**
     * @OS : android,ios,others
     *
     * @runtimeEnvironment: weixin,app,browser
     * @appVersionCode: code,0
     * 
     * @param channels
     * @param info
     */
    private void filterChannels(List<PayChannelInfo> channels, TPQueryCounterInfo info) {
        if ((info.getAppVersion() >= 70 && (!Strings.isNullOrEmpty(info.getOs())) && info.getOs().equals("android"))
                || (!Strings.isNullOrEmpty(info.getRuntimeEnvironment())
                        && info.getRuntimeEnvironment().equals("browser"))) {
            return;
        }
        int ii = -1;
        for (int i = 0; i < channels.size(); i++) {
            if (channels.get(i).getChannelId() == Channel.WECHAT.getValue()) {
                ii = i;
            }
        }
        if (ii > -1) {
            channels.remove(ii);
        }
    }
}
