package com.xiaomi.mifi.payment.queue;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.xiaomi.common.perfcounter.PerfCounter;
import com.xiaomi.mifi.common.utils.queue.Task;
import com.xiaomi.mifi.common.utils.queue.TaskConsumer;
import com.xiaomi.mifi.insurance.common.util.exception.ServiceLogicException;
import com.xiaomi.mifi.insurance.thrift.service.TRPayCenterNotify;
import com.xiaomi.mifi.paycenter.thrift.service.TNotifyStatus;
import com.xiaomi.mifi.payment.biz.AsyncTaskBiz;
import com.xiaomi.mifi.payment.biz.NotifyBiz;
import com.xiaomi.mifi.payment.model.ThriftNotifyRequest;
import com.xiaomi.mifi.payment.proxy.BServiceProxy;
import com.xiaomi.mifi.payment.thrift.Notify;
import com.xiaomi.mifi.payment.util.ConvertUtils;

/**
 * Created by mars on 17-5-3.
 */
@Deprecated
public class PaymentTaskConsumer extends TaskConsumer {
    private static final Logger LOGGER = LoggerFactory.getLogger(PaymentTaskConsumer.class);
    private static final int[] RETRY_TIME_SPAN = {5, 15, 30, 60, 120, 240, 480, 960, 1920, 3600};
    private static final int MAX_RETRY_TIMES = RETRY_TIME_SPAN.length;

    @Autowired
    private BServiceProxy bServiceProxy;

    @Autowired
    private NotifyBiz notifyBiz;

    @Autowired
    private AsyncTaskBiz asyncTaskBiz;

    @Override
    public boolean execute(Task task) {
        LOGGER.info("task is {}", task);
        if (task instanceof NotifyTask) {
            NotifyTask notifyTask = (NotifyTask) task;
            return executeNotify(notifyTask);
        }
        return false;
    }

    private boolean executeNotify(NotifyTask notifyTask) {
        ThriftNotifyRequest thriftNotifyRequest = notifyTask.getThriftNotifyRequest();
        TRPayCenterNotify trPayCenterNotify = ConvertUtils.convertCommitNotify2PayCenterNotify(thriftNotifyRequest);
        Notify notify = notifyBiz.findNotifyByOrderId(thriftNotifyRequest.getOrderId(),
                trPayCenterNotify.getTradeType());
        if (notify == null) {
            LOGGER.error("notify is null. give up notify, and return. notifyTask: {}", notifyTask);
            return true;
        }
        long now = bServiceProxy.getTimestamp();
        try {
            bServiceProxy.insurancePayCenterNotify(thriftNotifyRequest);
            notify.setNotifyStatus(TNotifyStatus.SUCCESS.getValue());
            notify.setNotifySuccessTime(now);
            notify.setUpdateTime(now);
            notifyBiz.updateNotify(notify);
            LOGGER.info("bServiceProxy.insurancePayCenterNotify success. notify: {}", notify);
            PerfCounter.count("InsuranceNotifySuccess", 1);
        } catch (ServiceLogicException e) {
            int retryTimes = notify.getNotifyRetryTimes();
            if (retryTimes < MAX_RETRY_TIMES) {
                retryTimes += 1;
                LOGGER.info(
                        "bServiceProxy.insurancePayCenterNotify exception. transactionId: {}, tradeType: {} retry {} time.",
                        notify.getTransactionId(), notify.getNotifyType(), retryTimes);
                notify.setNotifyRetryTimes(retryTimes);
                notify.setNotifyStatus(TNotifyStatus.RETRY.getValue());
                notify.setUpdateTime(now);
                notifyBiz.updateNotify(notify);
                thriftNotifyRequest.setDelayMillis(RETRY_TIME_SPAN[retryTimes - 1] * 1000L);
                asyncTaskBiz.addNotifyTask(thriftNotifyRequest);
                PerfCounter.count("InsuranceNotifyRetryTimes", 1);
            } else {
                LOGGER.info(
                        "bServiceProxy.insurancePayCenterNotify exception. retry time reach max times, give up. transactionId: {}, "
                                + "tradeType: {}",
                        notify.getTransactionId(), notify.getNotifyType());
                notify.setNotifyStatus(TNotifyStatus.GIVE_UP.getValue());
                notify.setUpdateTime(now);
                notifyBiz.updateNotify(notify);
                PerfCounter.count("InsuranceNotifyGiveUp", 1);
            }
        }
        return true;
    }
}
