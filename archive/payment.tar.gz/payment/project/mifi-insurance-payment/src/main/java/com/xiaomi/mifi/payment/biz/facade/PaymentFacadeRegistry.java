package com.xiaomi.mifi.payment.biz.facade;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.xiaomi.mifi.payment.model.PaymentChannel;

/**
 * Created by mars on 17-4-20.
 */
@Service
public class PaymentFacadeRegistry {
    private Map<PaymentChannel, PaymentFacade> paymentFacadeMap = new HashMap<>();

    void register(PaymentFacade paymentFacade) {
        paymentFacadeMap.put(paymentFacade.getChannel(), paymentFacade);
    }

    public PaymentFacade getPaymentFacade(PaymentChannel paymentChannel) {
        return paymentFacadeMap.get(paymentChannel);
    }
}
