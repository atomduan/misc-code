package com.xiaomi.mifi.payment.dao;

import com.xiaomi.mifi.payment.thrift.SupportChannels;
import net.paoding.rose.jade.annotation.DAO;
import net.paoding.rose.jade.annotation.ReturnGeneratedKeys;
import net.paoding.rose.jade.annotation.SQL;

import java.util.List;

/**
 * Created by mars on 17-4-20.
 */
@DAO
public interface SupportChannelsDAO {
    String TABLE_NAME = "support_channels";

    String IFColumns = "order_id, transaction_id, channel, card_type";

    String IFFields = ":1.id, :1.orderId, :1.transactionId, :1.channel, :1.cardType";

    String INSERT_VALUES = ":1.orderId, :1.transactionId, :1.channel, :1.cardType";

    String IFUpdate = "id=:1.id, order_id=:1.orderId, transaction_id=:1.transactionId, channel=:1.channel, card_type=:1.cardType";

    String SELECT_COLUMNS = "id, " + IFColumns;

    @ReturnGeneratedKeys
    @SQL("INSERT INTO " + TABLE_NAME + "(" + IFColumns + ")VALUES(" + INSERT_VALUES + ")")
    long insert(SupportChannels supportChannels);

    @SQL("SELECT " + SELECT_COLUMNS + " FROM " + TABLE_NAME + " WHERE order_id=:1")
    List<SupportChannels> findByOrderId(long orderId);

    @SQL("SELECT " + SELECT_COLUMNS + " FROM " + TABLE_NAME + " WHERE transaction_id=:1")
    List<SupportChannels> findByTransactionId(long transactionId);

    @SQL("UPDATE " + TABLE_NAME + " SET " + IFUpdate + " WHERE order_id=:1.orderId")
    int updateSupportChannels(SupportChannels supportChannels);
}
