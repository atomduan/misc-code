package com.xiaomi.mifi.payment.dao;

import com.xiaomi.mifi.insurance.payment.thrift.ChannelConfig;
import net.paoding.rose.jade.annotation.DAO;
import net.paoding.rose.jade.annotation.SQL;

import java.util.List;

@DAO
public interface ChannelConfigDAO {

    String TABLE_NAME = "channel_config";
    String INSERT_COLUMNS = "channel_id,start_time,end_time,trade_type,priority,subtitle,switch_on";
    String INSERT_VALUES = ":1.channelId,:1.startTime,:1.endTime,:1.tradeType,:1.priority,:1.subtitle,:1.switchOn";
    String SELECT_COLUMNS = "id," + INSERT_COLUMNS;

    @SQL("INSERT INTO " + TABLE_NAME + "(" + INSERT_COLUMNS + ")VALUES(" + INSERT_VALUES + ")")
    void insert(ChannelConfig one);

    @SQL("SELECT " + SELECT_COLUMNS + " FROM " + TABLE_NAME + " WHERE trade_type=:1 AND start_time<=:2 AND end_time>:2 AND switch_on=1 ORDER BY priority DESC, start_time DESC LIMIT 100")
    List<ChannelConfig> findValidChannelsByTradeTypeAndTime(int tradeType, long now);

    @SQL("SELECT " + SELECT_COLUMNS + " FROM " + TABLE_NAME)
    List<ChannelConfig> findChannelConfigs();

    @SQL("UPDATE " + TABLE_NAME + " SET switch_on=:2 WHERE channel_id=:1")
    int updateChannel(int channelId, int switchOn);
}
