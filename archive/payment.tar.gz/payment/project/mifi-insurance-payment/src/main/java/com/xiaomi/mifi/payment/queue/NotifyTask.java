package com.xiaomi.mifi.payment.queue;

import com.xiaomi.mifi.common.utils.queue.Task;
import com.xiaomi.mifi.payment.model.ThriftNotifyRequest;

/**
 * Created by mars on 17-4-26.
 */
public class NotifyTask extends Task {

    private ThriftNotifyRequest thriftNotifyRequest;

    public NotifyTask() {
        this.taskName = "notifyTask";
    }

    public ThriftNotifyRequest getThriftNotifyRequest() {
        return thriftNotifyRequest;
    }

    public void setThriftNotifyRequest(ThriftNotifyRequest thriftNotifyRequest) {
        this.thriftNotifyRequest = thriftNotifyRequest;
        super.delayMillis = thriftNotifyRequest.getDelayMillis();
    }

    @Override
    public int getType() {
        return QueueType.NOTIFY.ordinal();
    }
}
