package com.xiaomi.mifi.payment.util;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.xiaomi.miliao.zookeeper.ZKFacade;

import scala.util.Random;

public class PayCenterUtils {

    private static final Logger LOGGER = LoggerFactory.getLogger(PayCenterUtils.class);

    private static final String ORDER_TIME_FORMAT = "yyyy-MM-dd HH:mm:ss";

    public static final String BILL_TIME_FORMAT = "yyyy-MM-dd";

    public static final String BILL_FILE_PATH_FORMAT = "yyyy/MM/dd";

    public static final String BILL_FILE_NAME_FORMAT = "yyyyMMdd";

    public static final String BILL_TIME_MONTH_FORMAT = "yyyy-MM";

    public static final String BILL_FILE_PATH_MONTH_FORMAT = "yyyy/MM/";

    public static final String BILL_FILE_NAME_MONTH_FORMAT = "yyyyMM";

    private static final String AMOUNT_FORMAT = "#0.00";

    private static final String DEDUCT_NOTIFY_URL_PROEUCT = "https://ins.api.jr.mi.com/api/notify/cashpay/deduct";
    private static final String DEDUCT_NOTIFY_URL_STAGING = "http://ins.staging.mifi.pt.xiaomi.com/api/notify/cashpay/deduct";

    public static DateFormat createOrderDateFormat() {
        return new SimpleDateFormat(ORDER_TIME_FORMAT);
    }

    public static String formatBillDate(Date date) {
        SimpleDateFormat df = new SimpleDateFormat(BILL_TIME_FORMAT);
        return df.format(date);
    }


    public static String formatTimestamp(long ts) {
        Date date = new Date(ts);
        SimpleDateFormat df = new SimpleDateFormat(ORDER_TIME_FORMAT);
        return df.format(date);
    }

    public static Date parseEpochTime(String time) {
        try {
            return new SimpleDateFormat(ORDER_TIME_FORMAT).parse(time);
        } catch (ParseException e) {
            LOGGER.error("error when parse epoch time: {}", time, e);
        }

        return new Date(0);
    }

    public static int parseAmount(String amount) {
        try {
            return (int) (new DecimalFormat(AMOUNT_FORMAT).parse(amount).doubleValue() * 100);
        } catch (ParseException e) {
            LOGGER.error("error when parse amount: {}", amount, e);
        }
        return 0;
    }

    public static int parseAmountV0(String amount) {
        try {
            return new BigDecimal(amount).multiply(new BigDecimal(100)).intValue();
        } catch (Exception e) {
        }
        return 0;
    }

    public static String formatStrDate(Date date, String formatStr) {
        SimpleDateFormat df = new SimpleDateFormat(formatStr);
        return df.format(date);
    }

    public static Date parseStrTimeToDate(String time, String format) {
        try {
            return new SimpleDateFormat(format).parse(time);
        } catch (ParseException e) {
            LOGGER.error("error when parse epoch time: {}", time, e);
        }

        return new Date(0);
    }

    public static String getRandomStrinByLength(int length) {
        String base = "abcdefghijklmnopqrstuvwxyz0123456789";
        Random random = new Random();
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < length; i++) {
            int num = random.nextInt(base.length());
            sb.append(num);
        }
        return sb.toString();
    }

    public static String getDeductNotifyUrl() {
        if (ZKFacade.getZKSettings().getEnvironmentType().isProduction()) {
            return DEDUCT_NOTIFY_URL_PROEUCT;
        } else {
            return DEDUCT_NOTIFY_URL_STAGING;
        }
    }
}
