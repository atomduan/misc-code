package com.xiaomi.mifi.payment.biz.facade;

import java.util.Map;

import com.xiaomi.mifi.insurance.common.util.exception.ServiceLogicException;
import com.xiaomi.mifi.payment.model.CommitBindDeductRequest;
import com.xiaomi.mifi.payment.model.CommitBindDeductResult;
import com.xiaomi.mifi.payment.model.CommitDeductRequest;
import com.xiaomi.mifi.payment.model.CommitDeductResult;
import com.xiaomi.mifi.payment.model.CommitPayRequest;
import com.xiaomi.mifi.payment.model.CommitPayResult;
import com.xiaomi.mifi.payment.model.CommitRefundRequest;
import com.xiaomi.mifi.payment.model.CommitRefundResult;
import com.xiaomi.mifi.payment.model.PaymentChannel;
import com.xiaomi.mifi.payment.thrift.RefundDetail;
import com.xiaomi.mifi.payment.thrift.TRPayResponse;
import com.xiaomi.mifi.payment.thrift.TRRefundResponse;
import com.xiaomi.mifi.payment.thrift.TradeDetail;

/**
 * Created by mars on 17-4-20.
 */
public interface PaymentFacade {
    PaymentChannel getChannel();

    CommitPayRequest generatePayment(TradeDetail tradeDetail);

    CommitRefundRequest generateRefund(RefundDetail refundDetail);

    CommitPayResult commitPay(CommitPayRequest commitPayRequest);

    CommitRefundResult commitRefund(CommitRefundRequest commitRefundRequest);

    CommitBindDeductResult commitBindDeduct(CommitBindDeductRequest commitBindDeductRequest);

    CommitDeductResult commitDeduct(CommitDeductRequest commitDeductRequest);

    TRPayResponse convertCommitPayResult(CommitPayResult result);

    TRRefundResponse convertCommitRefundResult(CommitRefundResult result, RefundDetail refundDetail);

    void notifyRefund(Map<String, String> params) throws Exception;

    boolean verifyPayParam(Map<String, String> params);

    boolean verifyRefundParam(Map<String, String> params);

    TradeDetail getTradeDetailFromReturnParam(Map<String, String> params) throws ServiceLogicException;
}
