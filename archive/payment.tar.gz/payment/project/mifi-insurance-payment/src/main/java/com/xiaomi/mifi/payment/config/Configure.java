package com.xiaomi.mifi.payment.config;

public interface Configure {

    String getString(String key);

    int getInt(String key, int defaultValue);

    int getInt(String key);

    String[] getStringArray(String key);

    boolean getBoolean(String key, boolean defaultValue);

    boolean getBoolean(String key);

}
