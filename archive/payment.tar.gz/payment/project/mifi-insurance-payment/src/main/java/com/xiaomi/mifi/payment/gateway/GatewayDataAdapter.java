package com.xiaomi.mifi.payment.gateway;

import java.util.List;
import java.util.Map;

import com.xiaomi.mifi.insurance.common.util.exception.ServiceLogicException;
import com.xiaomi.mifi.insurance.payment.thrift.BillType;
import com.xiaomi.mifi.insurance.payment.thrift.PaymentRequestParam;
import com.xiaomi.mifi.insurance.payment.thrift.PaymentResponseParam;
import com.xiaomi.mifi.insurance.payment.thrift.RefundRequestParam;
import com.xiaomi.mifi.insurance.payment.thrift.TRBillDetail;
import com.xiaomi.mifi.payment.exception.PaymentGatewayResponseException;
import com.xiaomi.mifi.payment.model.CommitBindDeductRequest;
import com.xiaomi.mifi.payment.model.CommitBindDeductResult;
import com.xiaomi.mifi.payment.model.CommitDeductRequest;

public interface GatewayDataAdapter {

    String getWithdrawUrl();

    String getQueryBillUrl();

    String getTransactionId(Map<PaymentRequestParam, String> params);

    Map<String, String> createWithdrawRequest(Map<PaymentRequestParam, String> params)
            throws ServiceLogicException, PaymentGatewayResponseException;

    Map<PaymentResponseParam, String> parseWithdrawResponse(String response)
            throws PaymentGatewayResponseException, ServiceLogicException;

    Map<String, String> createQueryBillRequest(String billDate, BillType billType, boolean isBackFee);

    List<TRBillDetail> parseQueryBillResponse(String response)
            throws PaymentGatewayResponseException, ServiceLogicException;

    String createPayRequest(Map<PaymentRequestParam, String> params)
            throws ServiceLogicException, PaymentGatewayResponseException;

    String sendRequest(Map<String, String> request) throws ServiceLogicException;

    Map<String, String> createRefundRequest(Map<RefundRequestParam, String> params)
            throws ServiceLogicException, PaymentGatewayResponseException;

    long getTransactionIdFromReturnMap(Map<String, String> tpReturnParam);

    Map<String, String> createQueryNewBillRequest(String billDate, BillType billType);

    List<TRBillDetail> parseQueryNewBillResponse(String response, String onestr, BillType twostr) throws PaymentGatewayResponseException, ServiceLogicException;

    Map<String, String> createDeductRequset(CommitDeductRequest params);

    CommitBindDeductResult createDeductSign(CommitBindDeductRequest params);
}
