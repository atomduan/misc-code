package com.xiaomi.mifi.payment.model;

import com.xiaomi.mifi.common.thrift.model.TRResponse;

import lombok.Data;

/**
 * Created by mars on 17-4-20.
 */
@Data
public class CommitBindDeductResult {
    TRResponse response;
    String signedUrl;
}
