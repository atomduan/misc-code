package com.xiaomi.mifi.payment.model;

import com.xiaomi.mifi.insurance.common.util.exception.ErrorCode;
import lombok.Data;

/**
 * Created by mars on 17-4-20.
 */
@Data
public class CommitRefundResult {
    boolean isSuccess;
    ErrorCode errorCode;
    String response;
}
