package com.xiaomi.mifi.payment.biz;

import com.xiaomi.mifi.insurance.payment.thrift.PaymentStatistic;
import com.xiaomi.mifi.payment.dao.DailyStatisticDAO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Created by mars on 17-5-26.
 */
@Service
public class StatisticBiz {
    private static final Logger LOGGER = LoggerFactory.getLogger(StatisticBiz.class);

    @Autowired
    private DailyStatisticDAO dailyStatisticDAO;

    public long reportDailyStatistic(PaymentStatistic statistic) {
        LOGGER.info("StatisticBiz.reportDailyStatistic statistic: {}", statistic);
        return dailyStatisticDAO.insert(statistic);
    }

    public List<PaymentStatistic> queryAllPaymentStatistic(int offset, int length) {
        LOGGER.info("StatisticBiz.queryAllPaymentStatistic offset: {}, length: {}", offset, length);
        return dailyStatisticDAO.queryAll(offset, length);
    }

    public List<PaymentStatistic> queryPaymentStatisticByDate(String date) {
        LOGGER.info("StatisticBiz.queryPaymentStatisticByDate date: {}", date);
        return dailyStatisticDAO.queryByDate(date);
    }
}
