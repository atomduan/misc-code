package com.xiaomi.mifi.payment.gateway;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.xiaomi.mifi.insurance.payment.thrift.PaymentGatewayName;

@Service
public class PaymentGatewayRegistry {

    private Map<PaymentGatewayName, PaymentGateway> gateways = new HashMap<>();

    void register(PaymentGateway gw) {
        gateways.put(gw.getName(), gw);
    }

    public PaymentGateway getPaymentGateway(PaymentGatewayName name) {
        return gateways.get(name);
    }

}
