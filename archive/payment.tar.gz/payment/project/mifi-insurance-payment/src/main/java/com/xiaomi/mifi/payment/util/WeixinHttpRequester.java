package com.xiaomi.mifi.payment.util;

import java.io.IOException;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.xiaomi.mifi.insurance.common.util.http.HttpRequester;

public class WeixinHttpRequester extends HttpRequester {

    private final static Logger LOGGER = LoggerFactory.getLogger(WeixinHttpRequester.class);

    public String postString(String url, Map<String, String> headers,
            Map<String, String> params) throws IOException {

        String xmlParams = WeixinPayUtils.generateXmlString(params);
        try {
            return WeixinPayUtils.sendHttpPostString(url, null, xmlParams);
        } catch (Exception e) {
            LOGGER.error("exception ", e);
            throw new IOException("http post to weixin failed", e);
        }
    }
}
