package com.xiaomi.mifi.payment.biz;

import static com.xiaomi.mifi.payment.util.ResponseUtils.getResponse;
import static com.xiaomi.mifi.payment.util.ResponseUtils.getSuccessResponse;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.apache.http.NameValuePair;
import org.apache.http.client.utils.URLEncodedUtils;
import org.apache.http.message.BasicNameValuePair;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mifi.insurance.payment.util.ResponseStatus;
import com.xiaomi.common.perfcounter.PerfCounter;
import com.xiaomi.mifi.common.thrift.model.TRResponse;
import com.xiaomi.mifi.insurance.common.util.exception.ErrorCode;
import com.xiaomi.mifi.insurance.common.util.exception.ServiceLogicException;
import com.xiaomi.mifi.insurance.common.util.response.ResponseUtils;
import com.xiaomi.mifi.insurance.payment.thrift.TRQueryCounterInfoData;
import com.xiaomi.mifi.payment.crypto.MultiFieldsSignature;
import com.xiaomi.mifi.payment.dao.TradeDetailDAO;
import com.xiaomi.mifi.payment.model.PayResult;
import com.xiaomi.mifi.payment.proxy.BServiceProxy;
import com.xiaomi.mifi.payment.thrift.BillDetail;
import com.xiaomi.mifi.payment.thrift.Channel;
import com.xiaomi.mifi.payment.thrift.PaymentStatus;
import com.xiaomi.mifi.payment.thrift.TRDetailListRequest;
import com.xiaomi.mifi.payment.thrift.TRDetailListResponse;
import com.xiaomi.mifi.payment.thrift.TRTradeDetail;
import com.xiaomi.mifi.payment.thrift.TRTradeDetailList;
import com.xiaomi.mifi.payment.thrift.TradeDetail;
import com.xiaomi.mifi.payment.thrift.TradeStatus;
import com.xiaomi.mifi.payment.util.ValidateUtils;

/**
 * Created by mars on 17-4-20.
 */
@Service
public class TradeBiz {

    private static final Logger LOGGER = LoggerFactory.getLogger(TradeBiz.class);

    private static final String SIGN_FIELD_TRANSACTION_ID = "transaction_id";
    private static final String CHARSET = "UTF-8";
    private static final String SIGN_TYPE = "RSA2";
    private static final List<Integer> statusList = new ArrayList<>();
    private static final long ONE_DAY = 24 * 60 * 60 * 1000L;

    static {
        statusList.add(TradeStatus.INIT.getValue());
        statusList.add(TradeStatus.WAIT_PAY.getValue());
    }

    @Autowired
    private TradeDetailDAO tradeDetailDAO;

    @Qualifier("genericSignature")
    @Autowired
    private MultiFieldsSignature genericSignature;

    @Autowired
    @Qualifier("counterUrlPattern")
    private String counterUrlPattern;

    @Autowired
    private BServiceProxy bServiceProxy;
    
    @Autowired
    private NotifyBiz notifyBiz;

    @PostConstruct
    public void init() {
        LOGGER.info("counter url pattern: {}", counterUrlPattern);
    }

    public TradeDetail queryPaymentInfo(long orderId) {
        LOGGER.info("TradeBiz.queryPaymentInfo() invoke, param is {} ", orderId);
        TradeDetail tradeDetail;
        tradeDetail = tradeDetailDAO.findByOrderId(orderId);
        if (tradeDetail != null) {
            LOGGER.info("tradeDetailDAO.findByOrderId return {} ", tradeDetail.toString());
        } else {
            LOGGER.info("tradeDetailDAO.findByOrderId return null.");
        }
        return tradeDetail;
    }

    public List<TradeDetail> queryTradeDetails(long beginTime, long endTime, TradeStatus tradeStatus, int offset, int length) {
        LOGGER.info("TradeBiz.queryTradeDetails() invoke, param is begin {}, end {}, tradeStatus {}, offset {}, length {}", beginTime,
                endTime, tradeStatus, offset, length);
        List<TradeDetail> list = new ArrayList<>();
        if (beginTime <= endTime) {
            list = tradeDetailDAO.findByTimeSpanAndTradeStatus(beginTime, endTime,
                    tradeStatus != null ? tradeStatus.getValue() : -1, offset, length);
            if (list != null) {
                LOGGER.info("tradeDetailDAO.queryTradeDetails return {} rows ", list.size());
            } else {
                LOGGER.info("tradeDetailDAO.queryTradeDetails return null.");
            }
        }
        return list;
    }

    public List<TradeDetail> querySuccessTradeDetail(long beginTime, long endTime, int channel) {
        LOGGER.info("TradeBiz.querySuccessTradeDetail() invoke, param is {}, {}, {} ",
                beginTime, endTime, channel);
        List<TradeDetail> list = new ArrayList<>();
        if (beginTime <= endTime) {
            list = tradeDetailDAO.findByPayTime(beginTime, endTime, channel);
        }
        return list;
    }

    public long insertTradeDetail(TradeDetail tradeDetail) {
        LOGGER.info("TradeBiz.insertTradeDetail() invoke, param is {} ", tradeDetail.toString());
        long now = bServiceProxy.getTimestamp();
        tradeDetail.setCreateTime(now);
        tradeDetail.setUpdateTime(now);
        long ret = 0;
        if (ValidateUtils.validateTradeDetail(tradeDetail)) {
            ret = tradeDetailDAO.insert(tradeDetail);
        }
        return ret;
    }

    public int updateTradeDetail(TradeDetail tradeDetail) {
        LOGGER.info("TradeBiz.updateTradeDetail() invoke, param is {} ", tradeDetail.toString());
        int ret = 0;
        if (ValidateUtils.validateTradeDetail(tradeDetail)) {
            ret = tradeDetailDAO.updateTradeDetail(tradeDetail);
        }
        return ret;
    }

    public String signTrade(long transactionId) {
        HashMap<String, String> params = new HashMap<>();
        params.put(SIGN_FIELD_TRANSACTION_ID, String.valueOf(transactionId));

        String sign = genericSignature.sign(params);
        LOGGER.debug("generate sign for transaction: {}, sign: {}", transactionId, sign);

        return sign;
    }

    public boolean verifyTrade(long transactionId, String sign) {
        HashMap<String, String> params = new HashMap<>();
        params.put(SIGN_FIELD_TRANSACTION_ID, String.valueOf(transactionId));

        boolean success = genericSignature.verify(params, sign);
        LOGGER.debug("verify sign for transaction: {}, success: {}", transactionId, success);

        return success;
    }

    public String getCounterUrl(long transactionId) {
        String sign = signTrade(transactionId);
        String url = null;
        try {
            url = String.format(counterUrlPattern, transactionId, URLEncoder.encode(sign, "UTF-8"));
            LOGGER.info("generate counter url for transaction {}: {}", transactionId, url);
        } catch (UnsupportedEncodingException e) {
            LOGGER.error("URLEncoder.encode fail, sign: {}", sign);
        }
        return url;
    }

    public TradeDetail findByTransactionId(long transactionId) {
        LOGGER.info("TradeBiz.findByTransactionId() invoke, param is {} ", transactionId);
        return tradeDetailDAO.findByTransactionId(transactionId);
    }

    public TRQueryCounterInfoData getCounterInfo(long transactionId, String sign) throws ServiceLogicException {
        LOGGER.info("getting counter info, transaction id: {}", transactionId);
        // 验证签名
        boolean verified = verifyTrade(transactionId, sign);
        LOGGER.debug("sign of transaction id verified: {}, transaction id: {}", verified, transactionId);
        if (!verified) {
            LOGGER.warn("get counter info failed, sign of transaction id cannot verify, transaction id: {}",
                    transactionId);
            throw ServiceLogicException.SIGNATURE_MISMATCH;
        }

        TradeDetail tradeDetail = findByTransactionId(transactionId);
        if (tradeDetail == null) {
            LOGGER.warn("get counter info failed, trade not found, transaction id: {}", transactionId);
            throw ServiceLogicException.TARGET_NOT_FOUND;
        }

        long timeout = tradeDetail.getExpireTime() - bServiceProxy.getTimestamp();
        if (timeout <= 0) {
            LOGGER.warn("get counter info failed, trade is expired, transaction id: {}", transactionId);
            throw ServiceLogicException.EXPIRED_TRANSACTION;
        }

        // 检查订单是否仍然处于未支付状态。如果订单已经支付过，不管支付成功或失败，不再向用户展示订单信息。
        checkTradeStatus(tradeDetail, TradeStatus.INIT, TradeStatus.WAIT_PAY);

        TRQueryCounterInfoData ret = new TRQueryCounterInfoData();
        ret.setCounterTitle("小米保险收银台"); // 固定值
        ret.setAmount(tradeDetail.getTotalFee());
        ret.setTimeout(timeout);
        ret.setProductSubject(tradeDetail.getProductName());
        ret.setProductDesc(tradeDetail.getOrderDesc());
        ret.setOrderId(tradeDetail.getOrderId());

        LOGGER.debug("get counter info success, transaction id: {}", transactionId);
        return ret;
    }

    @Transactional
    public boolean updatePayResult(PayResult payResult, Channel channel) {
        LOGGER.debug("updating pay result, params: {}", payResult);
        // 我方交易流水号
        long transactionId = payResult.getTransactionId();
        String status = payResult.getStatus();
        boolean success = ResponseStatus.STATUS_SUCCESS.equals(status);
        
        // 锁住记录
        TradeDetail tradeDetail = tradeDetailDAO.selectForUpdate(transactionId);
        if (tradeDetail == null) {
            LOGGER.warn("trade detail is not found, update pay result failed, transaction id: {}", transactionId);
            PerfCounter.count("UpdatePayResultNotFoundTrade", 1);
            return false;
        }

        int tradeStatus = tradeDetail.getTradeStatus();

        if (tradeStatus == TradeStatus.SUCCESS.getValue()) {
            if (channel.getValue() != tradeDetail.getChannel() && success) {
                LOGGER.error("order pay twice by different channel transaction id {}", tradeDetail.getTransactionId());
                PerfCounter.count("OrderPayTwice", 10000);
                return true;
            }
        }

        if (tradeStatus != TradeStatus.WAIT_PAY.getValue() && !success) {
            // 重复通知
            LOGGER.warn("trade status is not WAIT_PAY, update failed, transaction id: {}", transactionId);
            PerfCounter.count("UpdatePayResultRepeatedTradeNotify", 1);
            return true;
        }

        long now = bServiceProxy.getTimestamp();
        
        TradeStatus newTradeStatus = success ? TradeStatus.SUCCESS : TradeStatus.FAIL;
        if (ResponseStatus.STATUS_TRANSACTION_CLOSED.equals(status)) {
            // 交易关闭
            newTradeStatus = TradeStatus.CLOSE;
        }
        LOGGER.info("get pay result: {}, transaction id: {}, trade status: {}", success, transactionId, newTradeStatus);
        tradeDetail.setTradeStatus(newTradeStatus.getValue());
        tradeDetail.setPaymentStatus((success ? PaymentStatus.SUCCESS : PaymentStatus.EXPIRED_CLOSE).getValue());
        tradeDetail.setUpdateTime(now);
        tradeDetail.setReceiveTime(now);
        tradeDetail.setPayTime(payResult.getPayTime());
        if (tradeDetail.getChannel() != channel.getValue()) {
            tradeDetail.setChannel(channel.getValue());
        }
        // 设置来自支付机构的trade id
        tradeDetail.setTradeId(payResult.getTradeId());

        PerfCounter.countDuration("TradeDuration", tradeDetail.getPayTime() - tradeDetail.getCreateTime());
        int rows = tradeDetailDAO.updateByTradeStatus(tradeDetail, tradeStatus);
        if (rows > 0) {
            PerfCounter.count("UpdatePayResultSucceed", 1);
            return true;
        } else {
            PerfCounter.count("UpdatePayResultFailure", 1);
            return false;
        }
    }

    @Transactional
    public boolean isExpiredAndUpdate(long transactionalId) {
        LOGGER.debug("check trade expireTime, transactionalId: {}", transactionalId);
        TradeDetail tradeDetail = tradeDetailDAO.selectForUpdate(transactionalId);

        int oldStatus = tradeDetail.getTradeStatus();
        if (oldStatus == TradeStatus.INIT.getValue() || oldStatus == TradeStatus.WAIT_PAY.getValue()) {
            long expireTime = tradeDetail.getExpireTime();
            long now = bServiceProxy.getTimestamp();
            if (expireTime < now) {
                LOGGER.warn("expired trade, transactionId: {}, now: {}, expireTime: {}", transactionalId,
                        now, tradeDetail.getExpireTime());
                tradeDetail.setTradeStatus(TradeStatus.CLOSE.getValue());
                tradeDetail.setPaymentStatus(PaymentStatus.EXPIRED_CLOSE.getValue());
                tradeDetailDAO.updateByTradeStatus(tradeDetail, oldStatus);
                PerfCounter.count("TradeBizSetTradeExpired", 1);
                return true;
            }
            LOGGER.info("trade is in processing, now: {}, expireTime: {}", now, tradeDetail.getExpireTime());
        }
        return false;
    }

    public TRDetailListResponse querySuccessTradeDetailList(TRDetailListRequest request) {
        LOGGER.info("TradeBiz.querySuccessTradeDetailList() invoke, param is {}, {}, {} ",
                request.getBeginTime(), request.getEndTime(), request.getTradeType());
        TRDetailListResponse response = new TRDetailListResponse();
        List<BillDetail> billData = new ArrayList<BillDetail>();
        try {
            long beginTime = request.getBeginTime();
            long endTime = request.getEndTime();
            int total = tradeDetailDAO.findListByPayTimeCount(beginTime, endTime);
            if (total > 0) {
                List<TradeDetail> data = tradeDetailDAO.findListByPayTime(beginTime, endTime, request.getStart(),
                        request.getLength());
                if (data != null) {
                    for (TradeDetail tra : data) {
                        BillDetail billDetail = new BillDetail();
                        billDetail.setAmount(tra.getTotalFee());
                        billDetail.setTradeType(tra.getTradeType());
                        billDetail.setChannel(tra.getChannel());
                        billDetail.setId(tra.getId());
                        billDetail.setOrderId(tra.getOrderId());
                        billDetail.setPayTime(tra.getPayTime());
                        billDetail.setStatus(tra.getPaymentStatus());
                        billDetail.setTransactionId(tra.getTransactionId());
                        billData.add(billDetail);
                    }
                }
            }
            response.setBillDetails(billData);
            response.setResponse(ResponseUtils.getSuccessResponse());
            response.setTotal(total);
        } catch (Exception e) {
            response.setResponse(ResponseUtils.getResponse(ErrorCode.INTERNAL_SERVER_ERROR));
            LOGGER.error("querySuccessTradeDetailList Exception {}", e.toString(), e);
        }

        LOGGER.info("for duizhang TradeBiz.querySuccessTradeDetailList response {}", response);
        return response;
    }

    public TradeDetail findByOrderId(long orderId) {
        return tradeDetailDAO.findByOrderId(orderId);
    }

    public boolean submitTrade(TradeDetail tradeDetail, int payChannel) {
        // todo 考虑同一订单，前后2次submit，订单状态均为未支付，且两次submit操作选择的支付通道不是同一个的情况。
        // 这种情况可能会引起用户对同一个订单支付两次。

        int oldStatus = tradeDetail.getTradeStatus();

        tradeDetail.setTradeStatus(TradeStatus.WAIT_PAY.getValue());
        tradeDetail.setPaymentStatus(PaymentStatus.COMMIT.getValue());
        tradeDetail.setUpdateTime(bServiceProxy.getTimestamp());
        tradeDetail.setChannel(payChannel);

        int rows = tradeDetailDAO.updateByTradeStatus(tradeDetail, oldStatus);
        return rows > 0;
    }

    public static void checkTradeStatus(TradeDetail tradeDetail, TradeStatus... expectedStatus) throws ServiceLogicException {
        int tradeStatusValue = tradeDetail.getTradeStatus();
        if (expectedStatus != null) {
            for (TradeStatus st : expectedStatus) {
                if (tradeStatusValue == st.getValue()) {
                    return;
                }
            }
        }

        TradeStatus tradeStatus = TradeStatus.findByValue(tradeStatusValue);
        LOGGER.debug("trade status is unexpected, expected: {}, actual: {}", expectedStatus, tradeStatus);
        if (tradeStatus == TradeStatus.INIT || tradeStatus == TradeStatus.WAIT_PAY) {
            throw ServiceLogicException.ORDER_NOT_PAID;
        }
        if (tradeStatus == TradeStatus.SUCCESS) {
            throw ServiceLogicException.ORDER_PAY_SUCCESS;
        }
        if (tradeStatus == TradeStatus.FAIL) {
            throw ServiceLogicException.ORDER_PAY_FAILED;
        }
        if (tradeStatus == TradeStatus.CANCEL) {
            throw ServiceLogicException.ORDER_PAY_CANCELED;
        }
        if (tradeStatus == TradeStatus.CLOSE) {
            throw ServiceLogicException.ORDER_PAY_CLOSED;
        }

    }

    public String createTradeReturnUrlParameter(long orderId) throws ServiceLogicException {
        LOGGER.info("AlipayPaymentFacade.createReturnUrlParameter, orderId: {}", orderId);
        Map<String, String> params = new HashMap<>();
        try {
            params.put("order_id", String.valueOf(orderId));
            params.put("charset", CHARSET);
            params.put("sign_type", SIGN_TYPE);
            String sign = genericSignature.sign(params);

            params.put("sign", sign);

            ArrayList<NameValuePair> nameValuePairs = new ArrayList<>();
            for (Map.Entry<String, String> entry : params.entrySet()) {
                nameValuePairs.add(new BasicNameValuePair(entry.getKey(), entry.getValue()));
            }
            return URLEncodedUtils.format(nameValuePairs, CHARSET);
        } catch (Exception e) {
            LOGGER.warn("AlipayPaymentFacade.createReturnUrlParameter error, orderId: {}, exception: ", orderId, e);
            throw ServiceLogicException.INVALID_PARAM;
        }
    }

    public List<Long> queryExpiredTrades(int offset, int length) {
        LOGGER.info("TradeBiz.queryExpiredTrades offset is {}, length is {}", offset, length);
        long now = bServiceProxy.getTimestamp();
        return tradeDetailDAO.queryExpiredTrades(now - ONE_DAY, now, offset, length, statusList);
    }

    public List<TradeDetail> queryDailyTrade(long startTime, int offset, int length) {
        return tradeDetailDAO.findByTimeSpanAndTradeStatus(startTime, startTime + ONE_DAY, -1, offset, length);
    }

    public TRResponse setTradeExpired(long transactionId) {
        LOGGER.info("ServiceProxy.setTradeExpired transactionId is {}", transactionId);
        TRResponse trResponse = new TRResponse();
        PerfCounter.count("BackendAutoRunSetTradeExpiredTimes", 1);
        if (isExpiredAndUpdate(transactionId)) {
            notifyBiz.sendNotify(transactionId);
            trResponse.setSuccess(true);
            LOGGER.info("ServiceProxy.setTradeExpired success transactionId is {}", transactionId);
        } else {
            trResponse.setSuccess(false);
            LOGGER.info("ServiceProxy.setTradeExpired false transactionId is {}", transactionId);
        }
        return trResponse;
    }
}
