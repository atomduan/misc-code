package com.xiaomi.mifi.payment.gateway;

import java.util.List;
import java.util.Map;

import com.xiaomi.mifi.insurance.common.util.exception.ServiceLogicException;
import com.xiaomi.mifi.insurance.payment.thrift.BillType;
import com.xiaomi.mifi.insurance.payment.thrift.PaymentGatewayName;
import com.xiaomi.mifi.insurance.payment.thrift.PaymentRequestParam;
import com.xiaomi.mifi.insurance.payment.thrift.PaymentResponseParam;
import com.xiaomi.mifi.insurance.payment.thrift.RefundRequestParam;
import com.xiaomi.mifi.insurance.payment.thrift.TRBillDetail;
import com.xiaomi.mifi.payment.exception.PaymentGatewayResponseException;
import com.xiaomi.mifi.payment.model.CommitDeductRequest;
import com.xiaomi.mifi.payment.model.PayResult;

public interface PaymentGateway {

    /**
     * 布尔常量真，用于填充{@link PaymentRequestParam}的某些参数
     */
    String TRUE = "true";

    /**
     * 布尔常量假，用于填充{@link PaymentRequestParam}的某些参数
     */
    String FALSE = "false";

    PaymentGatewayName getName();

    /**
     * 向支付网关发起提现请求
     *
     * @param params 支付请求的参数
     */
    Map<PaymentResponseParam, String> applyWithdraw(Map<PaymentRequestParam, String> params)
            throws ServiceLogicException, PaymentGatewayResponseException;

    /**
     * 生成app支付串，由商户app发给支付宝sdk
     */
    String createPayRequest(Map<PaymentRequestParam, String> params)
            throws ServiceLogicException, PaymentGatewayResponseException;

    PayResult parsePayNotify(Map<String, String> notification);

    boolean parseReturnUrl(Map<String, String> params);

    /**
     * 向支付网关查询账单
     *
     * @param billDate 账期
     * @param billType 账单类型，进账、出账等
     */
    List<TRBillDetail> queryBill(String billDate, BillType billType)
            throws ServiceLogicException, PaymentGatewayResponseException;

    /**
     * 向支付网关查询账单(新)
     *
     * @param billDate 账期
     * @param billType 账单类型，支付、退款等
     */
    List<TRBillDetail> queryNewBill(String billDate, BillType billType)
            throws ServiceLogicException, PaymentGatewayResponseException;

    /** 生成退款字符串
     *
     * @param params
     * @return
     */
    String createRefundRequest(Map<RefundRequestParam, String> params)
            throws ServiceLogicException, PaymentGatewayResponseException;

    /**
     * 通过前端返回参数拿到交易单流水号
     * @param param
     * @return
     */
    long getTransactionIdFromReturnMap(Map<String, String> param);

    /**
     * 代扣接口
     * 
     * @param params
     * @return
     */
    Map<String, String> commitDeduct(CommitDeductRequest params);

    /**
     * 代扣签约
     * 
     * @param params
     * @return
     */
    Map<String, String> createDeductSign(Map<String, String> params);

}
