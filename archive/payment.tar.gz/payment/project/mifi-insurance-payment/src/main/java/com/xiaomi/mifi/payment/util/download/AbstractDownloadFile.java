package com.xiaomi.mifi.payment.util.download;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;

import org.apache.tools.zip.ZipEntry;
import org.apache.tools.zip.ZipFile;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.xiaomi.mifi.insurance.common.util.exception.ServiceLogicException;
import com.xiaomi.mifi.payment.util.PayCenterUtils;

public abstract class AbstractDownloadFile implements IDownLoadFile {
    private static final Logger LOGGER = LoggerFactory.getLogger(AbstractDownloadFile.class);
    private static byte[] fileByte = new byte[1024];


    @Override
    public void downloadFile(String urlStr, String filePath, String fileDirPath, String fileName)
            throws ServiceLogicException {
        if (!fileExist(filePath)) {
            if (createFileDir(fileDirPath)) {
                downLoadFromUrl(urlStr, fileDirPath, fileName);
            } else {
                LOGGER.error("create file dir failed");
            }
        }
    }

    /**
     * 支付渠道账单是否存在
     *
     * @param filePath
     * @throws java.io.IOException
     */
    public boolean fileExist(String filePath) {
        File file = new File(filePath);
        return file.exists();
    }

    /**
     * 支付渠道账单目录是否存在
     *
     * @param filePath
     * @throws java.io.IOException
     */
    private boolean createFileDir(String filePath) {
        boolean ret = true;
        try {
            File file = new File(filePath);
            if (!file.exists()) {
                ret = file.mkdirs();
                if (ret) {
                    LOGGER.info("create file path success filePath: {}", filePath);
                }
            }
        } catch (Exception e) {
            ret = false;
            LOGGER.error("createFileDir Exception ", e);
        }
        return ret;
    }

    public boolean isZipFile(String filePath) {
        if (filePath.contains(".zip")) {
            return true;
        } else {
            return false;
        }

    }

    /**
     * 支付渠道账单下载到本地
     *
     * @param urlStr
     * @param fileDirPath
     * @throws com.xiaomi.mifi.insurance.common.util.exception.ServiceLogicException
     */
    public void downLoadFromUrl(String urlStr, String fileDirPath, String fileName) throws ServiceLogicException {
        BufferedInputStream bis = null;
        BufferedOutputStream bos = null;
        HttpURLConnection httpUrl = null;
        try {
            URL urlfile = new URL(urlStr);
            File dir = new File(fileDirPath);
            File f = new File(dir, fileName);
            httpUrl = (HttpURLConnection) urlfile.openConnection();
            httpUrl.setConnectTimeout(3 * 1000);
            httpUrl.setRequestProperty("User-Agent", "Mozilla/4.0 (compatible; MSIE 5.0; Windows NT; DigExt)");
            httpUrl.connect();
            bis = new BufferedInputStream(httpUrl.getInputStream());
            bos = new BufferedOutputStream(new FileOutputStream(f));
            int len = 2048;
            byte[] b = new byte[len];
            while ((len = bis.read(b)) != -1) {
                bos.write(b, 0, len);
            }
            bos.flush();
        } catch (Exception e) {
            LOGGER.error("downLoadFromUrl  download file error!", e);
            throw ServiceLogicException.ACCESS_GATEWAY_ERROR;
        } finally {
            try {
                if (httpUrl != null) {
                    httpUrl.disconnect();
                }
                if (bis != null) {
                    bis.close();
                }
                if (bos != null) {
                    bos.close();
                }
            } catch (IOException e) {
                LOGGER.error("down load file ,close the stream exception!", e);
                throw ServiceLogicException.ACCESS_GATEWAY_ERROR;
            }
        }
    }

    public boolean checkIsNotEnd(String cell) {
        String tmp = cell != null ? cell : "";
        boolean flag = false;
        if (!tmp.contains("明细列表结束") && !tmp.contains("交易合计") && !tmp.contains("退款合计") && !tmp.contains("导出时间")
                && !tmp.contains("支出合计") && !tmp.contains("收入")) {
            flag = true;
        }
        return flag;
    }

    /**
     * 解压缩ZIP文件，将ZIP文件里的内容解压到targetDIR目录下
     *
     * @param zipPath 待解压缩的ZIP文件名
     * @param descDir 目标目录
     */
    public List<File> upzipFile(String zipPath, String descDir) throws ServiceLogicException {
        return upzipFile(new File(zipPath), descDir);
    }

    /**
     * 对.zip文件进行解压缩
     *
     * @param targetFile 解压缩文件
     * @param descDir    压缩的目标地址，如：D:\\测试 或 /mnt/d/测试
     * @return
     */
    @SuppressWarnings("rawtypes")
    public List<File> upzipFile(File targetFile, String descDir) throws ServiceLogicException {
        List<File> list = new ArrayList<File>();
        InputStream inStream = null;
        OutputStream outStream = null;
        try {
            ZipFile zipFile = new ZipFile(targetFile, "GBK");
            for (Enumeration entries = zipFile.getEntries(); entries.hasMoreElements();) {
                ZipEntry entry = (ZipEntry) entries.nextElement();
                File file = new File(descDir + File.separator + entry.getName());
                if (entry.isDirectory()) {
                    if (file.mkdirs()) {
                        LOGGER.info("create dir successs [dir:{}]", descDir + File.separator + entry.getName());
                    }
                } else {
                    File parent = file.getParentFile();
                    if (!parent.exists()) {
                        if (parent.mkdirs()) {
                            LOGGER.info("create parent dir {}", descDir);
                        }
                    }
                    if (!file.exists()) {
                        file.createNewFile();
                    }
                    inStream = zipFile.getInputStream(entry);
                    outStream = new FileOutputStream(file);
                    int len = 0;
                    while ((len = inStream.read(fileByte)) > 0) {
                        outStream.write(fileByte, 0, len);
                    }
                    outStream.flush();
                    list.add(file);
                }
            }
        } catch (IOException e) {
            LOGGER.error("unzip file error", e);
            throw ServiceLogicException.ACCESS_GATEWAY_ERROR;
        } finally {
            try {
                if (inStream != null) {
                    inStream.close();
                }
                if (outStream != null) {
                    outStream.close();
                }
            } catch (IOException e) {
                LOGGER.error("unzip file close steam error", e);
                throw ServiceLogicException.ACCESS_GATEWAY_ERROR;
            }
        }
        return list;
    }

    /**
     * 对账单存名称(根据时间和支付渠道存放)
     *
     * @param billDate
     * @return
     */
    public String getFileName(String billDate) {
        String fileName = "";
        if (billDate.length() == 10) {
            fileName = PayCenterUtils.formatStrDate(
                    PayCenterUtils.parseStrTimeToDate(billDate, PayCenterUtils.BILL_TIME_FORMAT),
                    PayCenterUtils.BILL_FILE_NAME_FORMAT);
        } else if (billDate.length() == 7) {
            fileName = PayCenterUtils.formatStrDate(
                    PayCenterUtils.parseStrTimeToDate(billDate, PayCenterUtils.BILL_TIME_MONTH_FORMAT),
                    PayCenterUtils.BILL_FILE_NAME_MONTH_FORMAT);
        }
        return fileName;
    }

    /**
     * 解压账单存放路径
     *
     * @param billDate
     * @return
     */
    public String getFilePath(String billDate, String path) {
        String pathTmp = "";
        if (billDate.length() == 10) {
            pathTmp = path + "/"
                    + PayCenterUtils.formatStrDate(
                            PayCenterUtils.parseStrTimeToDate(billDate, PayCenterUtils.BILL_TIME_FORMAT),
                            PayCenterUtils.BILL_FILE_PATH_FORMAT);
        } else if (billDate.length() == 7) {
            pathTmp = path + "/"
                    + PayCenterUtils.formatStrDate(
                            PayCenterUtils.parseStrTimeToDate(billDate, PayCenterUtils.BILL_TIME_MONTH_FORMAT),
                            PayCenterUtils.BILL_FILE_PATH_MONTH_FORMAT);
        }
        return pathTmp;
    }
}
