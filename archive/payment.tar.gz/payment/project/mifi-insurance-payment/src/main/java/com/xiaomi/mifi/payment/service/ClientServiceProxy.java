package com.xiaomi.mifi.payment.service;

import com.xiaomi.common.perfcounter.PerfCounter;
import com.xiaomi.mifi.insurance.common.util.exception.ErrorCode;
import com.xiaomi.mifi.insurance.common.util.exception.ServiceLogicException;
import com.xiaomi.mifi.paycenter.thrift.service.TRBindDeduct;
import com.xiaomi.mifi.payment.biz.DeductBiz;
import com.xiaomi.mifi.payment.biz.TradeBiz;
import com.xiaomi.mifi.payment.biz.TransactionalTradeBiz;
import com.xiaomi.mifi.payment.biz.facade.PaymentFacade;
import com.xiaomi.mifi.payment.biz.facade.PaymentFacadeRegistry;
import com.xiaomi.mifi.payment.gateway.PaymentGatewayRegistry;
import com.xiaomi.mifi.payment.model.CommitBindDeductRequest;
import com.xiaomi.mifi.payment.model.CommitBindDeductResult;
import com.xiaomi.mifi.payment.model.CommitDeductRequest;
import com.xiaomi.mifi.payment.model.CommitDeductResult;
import com.xiaomi.mifi.payment.model.PaymentChannel;
import com.xiaomi.mifi.payment.thrift.BankCardType;
import com.xiaomi.mifi.payment.thrift.CertType;
import com.xiaomi.mifi.payment.thrift.DeductTradeDetail;
import com.xiaomi.mifi.payment.thrift.NotifyType;
import com.xiaomi.mifi.payment.thrift.TPDeduct;
import com.xiaomi.mifi.payment.thrift.TPDeductSign;
import com.xiaomi.mifi.payment.thrift.TRDeductSign;
import com.xiaomi.mifi.payment.thrift.TPPay;
import com.xiaomi.mifi.payment.thrift.TRDeduct;
import com.xiaomi.mifi.payment.thrift.TRPayResponse;
import com.xiaomi.mifi.payment.thrift.TradeDetail;
import com.xiaomi.mifi.payment.thrift.TradeStatus;
import com.xiaomi.mifi.payment.util.ConvertUtils;
import com.xiaomi.mifi.payment.util.PayCenterUtils;
import com.xiaomi.mifi.payment.util.ResponseUtils;
import com.xiaomi.mifi.payment.util.ValidateUtils;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import static com.xiaomi.mifi.payment.util.ResponseUtils.getResponse;
import static com.xiaomi.mifi.payment.util.ResponseUtils.getSuccessResponse;

@Service
public class ClientServiceProxy {

    private static final Logger LOGGER = LoggerFactory.getLogger(ClientServiceProxy.class);

    @Autowired
    PaymentGatewayRegistry registry;

    @Autowired
    private PaymentFacadeRegistry paymentFacadeRegistry;

    @Autowired
    TradeBiz tradeBiz;

    @Autowired
    DeductBiz deductBiz;

    @Autowired
    TransactionalTradeBiz transactionalTradeBiz;

    public TRPayResponse commitPay(TPPay tpPay) {
        TRPayResponse ret = new TRPayResponse();
        if (tpPay == null) {
            ret.setResponse(getResponse(ErrorCode.PARAMETER_ERROR));
            return ret;
        }
        LOGGER.info("committing pay, order id: {}", tpPay.getOrderId());
        boolean isValidate = ValidateUtils.validateTPPay(tpPay);
        if (!isValidate) {
            LOGGER.error("tpPay is not validate, tpPay is {}", tpPay);
            ret.setResponse(getResponse(ErrorCode.PARAMETER_ERROR));
            return ret;
        }

        TradeDetail tradeDetail = tradeBiz.findByOrderId(tpPay.getOrderId());

        if (tradeDetail != null) {
            // 如果订单还已支付过，不可以继续支付
            int tradeStatus = tradeDetail.getTradeStatus();
            if (tradeStatus != TradeStatus.INIT.getValue() && tradeStatus != TradeStatus.WAIT_PAY.getValue()) {
                LOGGER.info("fail to commit pay, trade already exists, and cannot re-commit, order id: {}, trade status: {}", tpPay.getOrderId(), tradeStatus);
                ret.setResponse(getResponse(ErrorCode.REPEATED_ORDER));
                return ret;
            }
            // 如果还未支付，可继续支付
            LOGGER.info("trade already exists, and can re-commit, order id: {}, trade status: {}", tpPay.getOrderId(), tradeStatus);
        } else {
            // 新建trade记录
            try {
                tradeDetail = transactionalTradeBiz.addNewTrade(tpPay);
            } catch (ServiceLogicException e) {
                PerfCounter.count("TransactionalTradeBizAddNewTradeFailure", 1);
                LOGGER.error("error when add trade detail", e);
                ret.setResponse(getResponse(e));
                return ret;
            }
        }

        String url = tradeBiz.getCounterUrl(tradeDetail.getTransactionId());
        ret.setResponse(getSuccessResponse());
        ret.setCheckoutCounterURL(url);

        return ret;
    }

    public TRDeduct commitDeduct(TPDeduct params) {
        TRDeduct result = new TRDeduct();
        DeductTradeDetail deductTrade = deductBiz.findByOrderId(params.getOrderId());
        CommitDeductRequest request = createCommitDeductRequest(params);
        if (deductTrade != null) {
            if (deductTrade.getTradeStatus() == TradeStatus.SUCCESS.getValue()) {
                LOGGER.info("deduct already success, deduct trade info {}", deductTrade);
                result.setResponse(ResponseUtils.getResponse(ErrorCode.DUPLICATED_ORDER));
                return result;
            }
            LOGGER.info("deduct continue to pay");
        } else {
            try {
                deductTrade = deductBiz.insertDeductDetail(request);
            } catch (ServiceLogicException e) {
                LOGGER.error("exception commit deduct ", e);
                result.setResponse(ResponseUtils.getResponse(e));
                return result;
            }
        }
        try {
            request.setTransactionId(deductTrade.getTransactionId());
            LOGGER.info("deductTrade {}, request {}", deductTrade, request);

            PaymentFacade paymentFacade = paymentFacadeRegistry.getPaymentFacade(PaymentChannel.MICASH); // 目前只有小米钱包有代扣
            CommitDeductResult commitDeductResult = paymentFacade.commitDeduct(request);
        } catch (Exception e) {
            LOGGER.error("exception on commit deduct ", e);
            result.setResponse(ResponseUtils.getResponse(ErrorCode.INTERNAL_SERVER_ERROR));
            return result;
        }
        result.setResponse(ResponseUtils.getSuccessResponse());
        return result;
    }

    public TRDeductSign createDeductSign(TPDeductSign params) {
        TRDeductSign result = new TRDeductSign();
        CommitBindDeductRequest request = new CommitBindDeductRequest();
        request.setBizType(params.getBizType());
        request.setReturnUrl(params.getReturnUrl());
        request.setProductName(params.getProductName());
        String bankList = "";
        if (params.getBankList() != null && params.getBankList().size() > 0) {
            bankList = StringUtils.join(params.getBankList(), "^");
        }
        request.setBankList(bankList);
        request.setExtraInfo(params.getExtraInfo());

        PaymentFacade paymentFacade = paymentFacadeRegistry.getPaymentFacade(PaymentChannel.MICASH);
        CommitBindDeductResult response = paymentFacade.commitBindDeduct(request);
        result.setResponse(response.getResponse());
        result.setSignedUrl(response.getSignedUrl());
        return result;
    }

    private CommitDeductRequest createCommitDeductRequest(TPDeduct deduct) {
        CommitDeductRequest request = new CommitDeductRequest();
        request.setDeductId(deduct.getDeductId());
        request.setTotalFee(deduct.getTotalFee());
        request.setBankCardNo(ConvertUtils.filter(deduct.getBankCardNo()));
        request.setBankUserName(ConvertUtils.filter(deduct.getBankUserName()));
        request.setCertNo(ConvertUtils.filter(deduct.getBankCardNo()));
        
        BankCardType cardType = deduct.getCardType() == null ? BankCardType.DEBIT_CARD : deduct.getCardType();
        request.setCardType(cardType);
        request.setCertType(CertType.ID_CARD);
        request.setCertNo(ConvertUtils.filter(deduct.getCertNo()));
        request.setProductName(deduct.getProductName());
        request.setOrderDesc(deduct.getOrderDesc());
        request.setNotifyType(deduct.getNotifyType() == null ? NotifyType.THRIFT : deduct.getNotifyType());
        request.setNotifyServiceName(deduct.getNotifyServiceName() == null ? "" : deduct.getNotifyServiceName());
        request.setNotifyMethodName(deduct.getNotifyMethodName() == null ? "" : deduct.getNotifyMethodName());
        
        request.setNotifyURL(PayCenterUtils.getDeductNotifyUrl());
        request.setReturnURL(deduct.getReturnURL() == null ? "" : deduct.getReturnURL());
        request.setExpireTime(deduct.getExpireTime());
        request.setXiaomiId(deduct.getXiaomiId());
        request.setOrderId(deduct.getOrderId());
        return request;
    }


}
