package com.xiaomi.mifi.payment.gateway;

import java.io.IOException;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.apache.http.NameValuePair;
import org.apache.http.client.utils.URLEncodedUtils;
import org.apache.http.message.BasicNameValuePair;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.alipay.api.AlipayApiException;
import com.alipay.api.AlipayClient;
import com.alipay.api.DefaultAlipayClient;
import com.alipay.api.domain.AlipayDataDataserviceBillDownloadurlQueryModel;
import com.alipay.api.request.AlipayDataDataserviceBillDownloadurlQueryRequest;
import com.alipay.api.response.AlipayDataDataserviceBillDownloadurlQueryResponse;
import com.google.common.base.Strings;
import com.google.gson.JsonObject;
import com.mifi.insurance.payment.util.ResponseStatus;
import com.xiaomi.common.perfcounter.PerfCounter;
import com.xiaomi.mifi.insurance.common.util.exception.ServiceLogicException;
import com.xiaomi.mifi.insurance.common.util.http.HttpRequester;
import com.xiaomi.mifi.insurance.payment.thrift.BillType;
import com.xiaomi.mifi.insurance.payment.thrift.PaymentGatewayName;
import com.xiaomi.mifi.insurance.payment.thrift.PaymentRequestParam;
import com.xiaomi.mifi.insurance.payment.thrift.PaymentResponseParam;
import com.xiaomi.mifi.insurance.payment.thrift.RefundRequestParam;
import com.xiaomi.mifi.insurance.payment.thrift.TRBillDetail;
import com.xiaomi.mifi.payment.config.Configure;
import com.xiaomi.mifi.payment.crypto.AlipaySignature;
import com.xiaomi.mifi.payment.crypto.MultiFieldsSignature;
import com.xiaomi.mifi.payment.exception.PaymentGatewayResponseException;
import com.xiaomi.mifi.payment.model.CommitBindDeductRequest;
import com.xiaomi.mifi.payment.model.CommitBindDeductResult;
import com.xiaomi.mifi.payment.model.CommitDeductRequest;
import com.xiaomi.mifi.payment.model.PayResult;
import com.xiaomi.mifi.payment.util.ConvertUtils;
import com.xiaomi.mifi.payment.util.PayCenterUtils;
import com.xiaomi.mifi.payment.util.download.CsvDownloadFileService;
import com.xiaomi.mifi.payment.util.download.SftpDownloadFileService;
import com.xiaomi.miliao.zookeeper.ZKFacade;

import net.sf.json.JSONObject;

@Service
public class AlipayPaymentGateway extends AbstractPaymentGateway {

    private static final Logger LOGGER = LoggerFactory.getLogger(AlipayPaymentGateway.class);

    private static final String SERVICE_VERSION = "1.0";

    private static final String CHARSET = "UTF-8";

    private static final String SIGN_TYPE = "RSA2";

    @Autowired
    PaymentGatewayRegistry registry;

    @Autowired
    Configure config;

    @Autowired
    CsvDownloadFileService csvDownloadFileService;

    @Qualifier("httpRequester")
    @Autowired
    HttpRequester httpRequester;

    @Qualifier("alipayMerchantSignature")
    @Autowired
    MultiFieldsSignature merchantSignature;

    private String alipayUrl;
    private String appId;
    private String billFilePath;
    private String urlAPI;

    private String sftpHost;
    private String sftpUserName;
    private String sftpPassword;
    private String sftpPath;
    private SftpDownloadFileService downloadService;

    @PostConstruct
    public void init() {
        registry.register(this);

        alipayUrl = config.getString("url.alipay");
        appId = config.getString("alipay.appid");
        billFilePath = config.getString("bill.file.path");
        urlAPI = config.getString("url.alipay.query.api");
        LOGGER.info("alipay configure info [appId: {}, alipayUrl: {}, billFilePath: {}, urlAPI: {}]", appId,
                alipayUrl, billFilePath, urlAPI);

        sftpHost = config.getString("alipay.sftp.host");
        sftpPath = config.getString("alipay.sftp.path");
        sftpUserName = ((AlipaySignature) merchantSignature).getSftpUserName();
        sftpPassword = ((AlipaySignature) merchantSignature).getSftpPassword();

        // TODO: 仅上线后看一次，之后删除
        // LOGGER.info("sftp config info [sftpHost: {}, sftpPath: {},
        // sftpUserName: {}, sftpPassword: {}]", sftpHost,
        // sftpPath, sftpUserName, sftpPassword);
        downloadService = new SftpDownloadFileService(sftpHost, sftpUserName, sftpPassword, sftpPath);
        setAdapter(new AlipayDataAdapter());
    }

    /*
     * for unit test
     */
    public void setAdaptorForTest() {
        setAdapter(new AlipayDataAdapter());
    }

    @Override
    public PaymentGatewayName getName() {
        return PaymentGatewayName.ALIPAY;
    }

    @Override
    public PayResult parsePayNotify(Map<String, String> notification) {
        HashMap<String, String> params = new HashMap<>(notification);

        String sign = params.remove("sign");
        params.remove("sign_type");

        String transactionIdStr = params.get("out_trade_no"); // 我方生成的订单号
        LOGGER.debug("verifying pay notify, transaction id: {}, sign: {}", transactionIdStr, sign);

        boolean verify = merchantSignature.verify(params, sign);

        PayResult ret = new PayResult();
        if (!verify) {
            LOGGER.warn("signature of signature mismatches, transaction id: {}", transactionIdStr);
            ret.setStatus(ResponseStatus.STATUS_SIGN_MISMATCH);
            return ret;
        }

        String receivedAppId = params.get("app_id");
        if (!appId.equals(receivedAppId)) {
            LOGGER.warn("invalid app id in pay notify, transaction id: {}, app id: {}", transactionIdStr, receivedAppId);
            ret.setStatus(ResponseStatus.STATUS_INVALID_RESULT);
            return ret;
        }
        String tradeId = params.get("trade_no"); // 支付宝生成的账单号
        long transactionId = 0;
        try {
            transactionId = Long.parseLong(transactionIdStr);
        } catch (Exception e) {
            LOGGER.error("error when parse transaction id", e);
        }

        long payTime = 0L;
        String tradeStatusRet = params.get("trade_status");

        String status = ResponseStatus.STATUS_FAIL;
        if ("TRADE_CLOSED".equals(tradeStatusRet)) {
            status = ResponseStatus.STATUS_TRANSACTION_CLOSED;
            PerfCounter.count("AlipayParseTradeClosedNotify", 1);
        } else if ("TRADE_SUCCESS".equals(tradeStatusRet) || "TRADE_FINISHED".equals(tradeStatusRet)) {
            status = ResponseStatus.STATUS_SUCCESS;
            payTime = ConvertUtils.strToTimestamp2(params.get("gmt_payment"));
            PerfCounter.count("AlipayParseTradeSuccessNotify", 1);
        }

        // 打印支付宝异步通知的原始状态、处理后的状态
        LOGGER.info("trade status in alipay pay notify: {}, transaction id: {}, result status: {}", tradeStatusRet, transactionIdStr, status);

        ret.setStatus(status);
        ret.setTransactionId(transactionId);
        ret.setPayTime(payTime);
        ret.setTradeId(tradeId);

        return ret;
    }

    @Override
    public boolean parseReturnUrl(Map<String, String> parameters) {
        HashMap<String, String> params = new HashMap<>(parameters);

        String sign = params.remove("sign");
        params.remove("sign_type");
        params.remove("channel");

        String transactionIdStr = params.get("out_trade_no"); // 我方生成的订单号
        LOGGER.debug("verifying pay return notify, transaction id: {}, sign: {}", transactionIdStr, sign);

        return merchantSignature.verify(params, sign);
    }



    @Override
    public List<TRBillDetail> queryNewBill(String billDate, BillType billType)
            throws ServiceLogicException, PaymentGatewayResponseException {
        List<TRBillDetail> result = new ArrayList<TRBillDetail>();
        try {
            String downloadUrl = "";
            if (!ZKFacade.getZKSettings().getEnvironmentType().isProduction()) {
                downloadUrl = getDownloadUrl("trade", billDate);
            }
            result = getAdapter().parseQueryNewBillResponse(downloadUrl, billDate, billType);
        } catch (Exception e) {
            LOGGER.error("ioexception when get queryNewBill response content", e);
            throw ServiceLogicException.ACCESS_GATEWAY_ERROR;
        }
        LOGGER.info("get response for queryNewBill result size : {}", result.size());
        return result;
    }

    @Override
    HttpRequester getHttpRequester() {
        return httpRequester;
    }

    public String getDownloadUrl(String billType, String billDate) throws AlipayApiException {
        AlipaySignature sign = (AlipaySignature) merchantSignature;
        AlipayClient client = new DefaultAlipayClient(alipayUrl, appId,
                sign.getPrivateKeyContent(), "json", "UTF-8",
                sign.getPublicKeyContent(), "RSA2");
        AlipayDataDataserviceBillDownloadurlQueryRequest alipayRequest = new AlipayDataDataserviceBillDownloadurlQueryRequest();

        AlipayDataDataserviceBillDownloadurlQueryModel model = new AlipayDataDataserviceBillDownloadurlQueryModel();
        model.setBillType(billType);
        model.setBillDate(billDate);
        alipayRequest.setBizModel(model);

        LOGGER.info("reuqest {}", alipayRequest.getTextParams());
        AlipayDataDataserviceBillDownloadurlQueryResponse alipayResponse = client.execute(alipayRequest);
        LOGGER.info("response {}", alipayResponse.getBody());
        return alipayResponse.toString();
    }

    class AlipayDataAdapter implements GatewayDataAdapter {

        @Override
        public String getWithdrawUrl() {
            throw new UnsupportedOperationException("withdraw is not supported");
        }

        @Override
        public String getQueryBillUrl() {
            return alipayUrl;
        }

        @Override
        public String getTransactionId(Map<PaymentRequestParam, String> params) {
            return params.get(PaymentRequestParam.MERCHANT_TRANSACTION_ID);
        }

        @Override
        public Map<String, String> createWithdrawRequest(Map<PaymentRequestParam, String> params)
                throws PaymentGatewayResponseException, ServiceLogicException {
            throw new UnsupportedOperationException("create withdraw method is not supported");
        }

        @Override
        public Map<PaymentResponseParam, String> parseWithdrawResponse(String response)
                throws PaymentGatewayResponseException, ServiceLogicException {
            throw new UnsupportedOperationException("create withdraw method is not supported");
        }

        @Override
        public Map<String, String> createQueryBillRequest(String billDate, BillType billType, boolean isBackfee) {
            throw new UnsupportedOperationException("create createQueryBillRequest method is not supported");
        }

        @Override
        public List<TRBillDetail> parseQueryBillResponse(String fileDownUrl) throws ServiceLogicException {
            throw new UnsupportedOperationException("create parseQueryBillResponse method is not supported");
        }

        @Override
        public String createPayRequest(Map<PaymentRequestParam, String> params)
                throws ServiceLogicException, PaymentGatewayResponseException {
            LOGGER.info("AlipayDataAdapter.createPayRequest params is {}", params);
            String transactionId = params.get(PaymentRequestParam.MERCHANT_TRANSACTION_ID);
            String subject = params.get(PaymentRequestParam.PAY_SUBJECT);
            String description = params.get(PaymentRequestParam.PAY_DESCRIPTION);
            String amount = params.get(PaymentRequestParam.PAY_AMOUNT);
            String notifyUrl = params.get(PaymentRequestParam.NOTIFY_URL);
            String payTimeout = params.get(PaymentRequestParam.PAY_TIMEOUT);
            String returnUrl = params.get(PaymentRequestParam.RETURN_URL);
            boolean allowCreditCard = TRUE.equals(params.get(PaymentRequestParam.PAY_ALLOW_CREDIT_CARD));

            return createPayRequestMap(payTimeout, amount, transactionId, subject, description, notifyUrl, returnUrl, allowCreditCard);
        }

        @Override
        public String sendRequest(Map<String, String> request) throws ServiceLogicException {
            HttpRequester httpRequester = getHttpRequester();
            HttpRequester.HttpResult get;
            try {
                get = httpRequester.get(alipayUrl, request);
            } catch (IOException e) {
                LOGGER.error("error when createPayRequest: {}", request, e);
                throw ServiceLogicException.ACCESS_GATEWAY_ERROR;
            }

            String response;
            try {
                response = get.getString();
            } catch (IOException e) {
                LOGGER.error("IOException when createPayRequest", e);
                throw ServiceLogicException.ACCESS_GATEWAY_ERROR;
            }
            LOGGER.debug("get response createPayRequest, response: {}", response);
            return response;
        }

        @Override
        public Map<String, String> createRefundRequest(Map<RefundRequestParam, String> params)
                throws ServiceLogicException, PaymentGatewayResponseException {
            LOGGER.info("AlipayDataAdapter.createRefundRequest params is {}", params);
            String orderId = params.get(RefundRequestParam.OUTER_ORDER_ID);
            String tradeId = params.get(RefundRequestParam.TARDE_NO);
            String amount = params.get(RefundRequestParam.REFUND_AMOUNT);

            return createRefundRequestMap(orderId, tradeId, amount);
        }

        @Override
        public long getTransactionIdFromReturnMap(Map<String, String> tpReturnParam) {
            return Long.parseLong(tpReturnParam.get("out_trade_no"));
        }

        @Override
        public Map<String, String> createQueryNewBillRequest(String billDate, BillType billType) {
            Map<String, String> params = new HashMap<String, String>();
            params.put("app_id", appId);
            params.put("method", urlAPI);
            params.put("format", "json");// 非必填
            params.put("charset", CHARSET);
            params.put("sign_type", SIGN_TYPE);
            Date now = new Date();
            DateFormat df = PayCenterUtils.createOrderDateFormat();
            params.put("timestamp", df.format(now));// "yyyy-MM-dd HH:mm:ss"
            params.put("version", SERVICE_VERSION);

            Map<String, String> paramsRequest = new HashMap<String, String>();
            paramsRequest.put("bill_type", "trade");
            paramsRequest.put("bill_date", billDate);
            JSONObject jsonObject = JSONObject.fromObject(paramsRequest);
            params.put("biz_content", jsonObject.toString());

            String sign = merchantSignature.sign(params);
            params.put("sign", sign);

            return params;
        }

        @Override
        public List<TRBillDetail> parseQueryNewBillResponse(String response, String billDate, BillType billType)
                throws PaymentGatewayResponseException, ServiceLogicException {
            return Strings.isNullOrEmpty(response) ? parseSftpBill(response, billDate, billType)
                    : parseBillResponse(response, billDate, billType);
        }

        private List<TRBillDetail> parseSftpBill(String response, String billDate, BillType billType)
                throws ServiceLogicException {
            String fileName = downloadService.getFileName(billDate);
            String filePath = downloadService.getFilePath(billDate, billFilePath);

            LOGGER.info("sftp file url {}, path {},fileName {}", response, filePath + "/" + fileName, fileName);
            ArrayList<TRBillDetail> ret = new ArrayList<>();
            try {
                downloadService.downloadFile(response, filePath + "/" + fileName, filePath, fileName);
                ret = (ArrayList<TRBillDetail>) downloadService.zipFileRead(filePath + "/" + fileName, filePath,
                        billDate, billType);
            } catch (Exception e) {
                LOGGER.error("error when javacsv ", e);
                throw ServiceLogicException.ACCESS_GATEWAY_ERROR;
            }

            return ret;
        }

        // only using in staging
        private List<TRBillDetail> parseBillResponse(String response, String billDate, BillType billType) {
            String fileName = csvDownloadFileService.getFileName(billDate);
            String filePath = csvDownloadFileService.getFilePath(billDate, billFilePath);

            if (response.startsWith("http")) {
                response = "https" + response.substring(4);
            }
            LOGGER.info("csv file url {}, path {},fileName {}", response, filePath + "/" + fileName, fileName);
            ArrayList<TRBillDetail> ret = new ArrayList<TRBillDetail>();
            try {
                csvDownloadFileService.downloadFile(response, filePath + "/" + fileName, filePath, fileName);
                ret = (ArrayList<TRBillDetail>) csvDownloadFileService.zipFileRead(filePath + "/" + fileName, filePath,
                        billDate, billType);
            } catch (Exception e) {
                LOGGER.error("error when javacsv .csv ", e);
            }
            return ret;
        }

        private Map<String, String> createRefundRequestMap(String orderId, String tradeId, String amount) {
            // https://doc.open.alipay.com/docs/doc.htm?spm=a219a.7629140.0.0.Q0Evzo&treeId=203&articleId=105285&docType=1
            Map<String, String> params = new HashMap<>();
            params.put("app_id", appId);
            params.put("method", "alipay.trade.refund");
            params.put("format", "JSON");
            params.put("charset", CHARSET);
            params.put("sign_type", SIGN_TYPE);
            params.put("timestamp", PayCenterUtils.formatTimestamp(System.currentTimeMillis()));
            params.put("version", SERVICE_VERSION);
            JsonObject bizObj = new JsonObject();
            bizObj.addProperty("out_trade_no", orderId);
            bizObj.addProperty("trade_no", tradeId);
            bizObj.addProperty("refund_amount", amount);
            params.put("biz_content", bizObj.toString());
            String sign = merchantSignature.sign(params);
            params.put("sign", sign);
            return params;
        }

        private String createPayRequestMap(String timeout, String amount, String transactionId, String subject,
                String description, String notifyUrl, String returnUrl, boolean allowCreditCard) {
            // 参考
            // https://doc.open.alipay.com/doc2/detail.htm?treeId=203&articleId=105463&docType=1
            Map<String, String> params = new HashMap<>();
            params.put("app_id", appId);
            params.put("method", "alipay.trade.wap.pay");
            params.put("format", "JSON");
            params.put("return_url", returnUrl);
            params.put("charset", CHARSET);
            params.put("sign_type", SIGN_TYPE);
            params.put("timestamp", PayCenterUtils.formatTimestamp(System.currentTimeMillis()));
            params.put("version", SERVICE_VERSION);
            params.put("notify_url", notifyUrl);

            StringBuilder enabledPayChannels = new StringBuilder();
            // 余额、余额宝、借记卡快捷总是允许的
            enabledPayChannels.append("balance,moneyFund,debitCardExpress");
            if (allowCreditCard) {
                // 开启信用卡快捷、信用卡支付。是否允许花呗分期由另外的参数控制
                enabledPayChannels.append(",creditCardExpress,creditCard");
            }
            params.put("enable_pay_channels", enabledPayChannels.toString());

            JsonObject bizObj = new JsonObject();
            bizObj.addProperty("body", description);
            bizObj.addProperty("subject", subject);
            bizObj.addProperty("out_trade_no", transactionId);
            if (timeout != null) {
                bizObj.addProperty("timeout_express", timeout);
            }
            bizObj.addProperty("total_amount", amount);
            bizObj.addProperty("product_code", "QUICK_WAP_PAY");

            params.put("biz_content", bizObj.toString());

            String sign = merchantSignature.sign(params);

            params.put("sign", sign);

            ArrayList<NameValuePair> nameValuePairs = new ArrayList<>();
            for (Map.Entry<String, String> entry : params.entrySet()) {
                nameValuePairs.add(new BasicNameValuePair(entry.getKey(), entry.getValue()));
            }
            return URLEncodedUtils.format(nameValuePairs, CHARSET);
        }

        @Override
        public Map<String, String> createDeductRequset(CommitDeductRequest request) {
            return null;
        }

        @Override
        public CommitBindDeductResult createDeductSign(CommitBindDeductRequest params) {
            return null;
        }

    }
}
