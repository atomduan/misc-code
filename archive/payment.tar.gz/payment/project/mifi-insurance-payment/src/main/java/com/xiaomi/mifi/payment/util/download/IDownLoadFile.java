package com.xiaomi.mifi.payment.util.download;

import com.xiaomi.mifi.insurance.common.util.exception.ServiceLogicException;
import com.xiaomi.mifi.insurance.payment.thrift.BillType;
import com.xiaomi.mifi.insurance.payment.thrift.TRBillDetail;

import java.util.List;

public interface IDownLoadFile {
    void downloadFile(String url, String filePath, String fileDirPath, String fileName) throws ServiceLogicException;

    List<TRBillDetail> readFile(String filePath, String billDate, BillType billType) throws ServiceLogicException;
}
