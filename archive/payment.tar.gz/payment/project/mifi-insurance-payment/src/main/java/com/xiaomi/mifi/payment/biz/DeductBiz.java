package com.xiaomi.mifi.payment.biz;

import java.util.ArrayList;
import java.util.List;

import org.elasticsearch.gateway.Gateway;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mifi.insurance.payment.util.ResponseStatus;
import com.xiaomi.common.perfcounter.PerfCounter;
import com.xiaomi.mifi.common.thrift.model.TRResponse;
import com.xiaomi.mifi.insurance.common.util.exception.ErrorCode;
import com.xiaomi.mifi.insurance.common.util.exception.ServiceLogicException;
import com.xiaomi.mifi.insurance.common.util.response.ResponseUtils;
import com.xiaomi.mifi.payment.dao.DeductTradeDetailDAO;
import com.xiaomi.mifi.payment.dao.NotifyDAO;
import com.xiaomi.mifi.payment.model.CommitDeductRequest;
import com.xiaomi.mifi.payment.model.PayResult;
import com.xiaomi.mifi.payment.model.PaymentChannel;
import com.xiaomi.mifi.payment.proxy.BServiceProxy;
import com.xiaomi.mifi.payment.thrift.BillDetail;
import com.xiaomi.mifi.payment.thrift.DeductTradeDetail;
import com.xiaomi.mifi.payment.thrift.Notify;
import com.xiaomi.mifi.payment.thrift.PaymentStatus;
import com.xiaomi.mifi.payment.thrift.TRDetailListRequest;
import com.xiaomi.mifi.payment.thrift.TRDetailListResponse;
import com.xiaomi.mifi.payment.thrift.TradeDetail;
import com.xiaomi.mifi.payment.thrift.TradeStatus;
import com.xiaomi.mifi.payment.thrift.TradeType;
import com.xiaomi.mifi.payment.util.ConvertUtils;
import com.xiaomi.mifi.payment.util.ValidateUtils;

/**
 * Created by mars on 17-4-21.
 */
@Service
public class DeductBiz {
    private static final Logger LOGGER = LoggerFactory.getLogger(DeductBiz.class);
    private static final long ONE_DAY = 24 * 60 * 60 * 1000L;
    private static final List<Integer> statusList = new ArrayList<Integer>() {
        {
            add(TradeStatus.INIT.getValue());
            add(TradeStatus.WAIT_PAY.getValue());
        }
    };
    @Autowired
    private DeductTradeDetailDAO deductTradeDetailDAO;

    @Autowired
    private NotifyBiz notifyBiz;

    @Autowired
    private BServiceProxy bServiceProxy;

    public DeductTradeDetail insertDeductDetail(CommitDeductRequest commitDeductRequest) throws ServiceLogicException {
        LOGGER.info("DeductBiz.insertDeductDetail() invoke, param is {} ", commitDeductRequest.toString());
        DeductTradeDetail deductTradeDetail = ConvertUtils.convertDeductRequest2DeductDetail(commitDeductRequest);
        Notify notify = ConvertUtils.convertDeductRequest2Notify(commitDeductRequest);
        if (notify == null || deductTradeDetail == null) {
            return null;
        }
        deductTradeDetail.setTransactionId(bServiceProxy.getId());
        deductTradeDetail.setTradeId("");
        deductTradeDetail.setErrorCode(0);
        deductTradeDetail.setErrorDesc("");
        long id = deductTradeDetailDAO.insert(deductTradeDetail);
        notify.setTransactionId(deductTradeDetail.getTransactionId());
        notify.setNotifyId(bServiceProxy.getId());
        notify.setTradeType(3);

        long notifyId = notifyBiz.insertNotify(notify);
        if (id > 0 && notifyId > 0) {
            deductTradeDetail.setNotifyId(notify.getNotifyId());

        }
        return deductTradeDetail;
    }

    public int updateDeductDetail(DeductTradeDetail deductTradeDetail) {
        LOGGER.info("DeductBiz.updateDeductDetail() invoke, param is {} ", deductTradeDetail.toString());
        int ret = 0;
        if (deductTradeDetail != null) {
            if (ValidateUtils.validateDeductTradeDetail(deductTradeDetail)) {
                ret = deductTradeDetailDAO.updateDeduct(deductTradeDetail);
            }
        }
        return ret;
    }

    public DeductTradeDetail findByTransactionId(long transactionId) {
        LOGGER.info("DeductBiz.findByTransactionId() invoke, param is {} ", transactionId);
        DeductTradeDetail deductTradeDetail = deductTradeDetailDAO.findByTransactionId(transactionId);
        return deductTradeDetail;
    }

    public DeductTradeDetail findByOrderId(long orderId) {
        LOGGER.info("find orderId invoke, param is {} ", orderId);
        DeductTradeDetail deductTradeDetail = deductTradeDetailDAO.findByOrderId(orderId);
        return deductTradeDetail;
    }

    @Transactional
    public boolean updatePayResult(PayResult payResult) {
        LOGGER.debug("updating pay result, params: {}", payResult);
        // 我方交易流水号
        long transactionId = payResult.getTransactionId();
        String status = payResult.getStatus();

        // 锁住记录
        DeductTradeDetail deductTradeDetail = deductTradeDetailDAO.selectForUpdate(transactionId);
        if (deductTradeDetail == null) {
            LOGGER.warn("trade detail is not found, update pay result failed, transaction id: {}", transactionId);
            PerfCounter.count("UpdatePayResultNotFoundTrade", 1);
            return false;
        }

        int tradeStatus = deductTradeDetail.getTradeStatus();
        if (tradeStatus != TradeStatus.WAIT_PAY.getValue()) {
            // 重复通知
            LOGGER.warn("trade status is not WAIT_PAY, update failed, transaction id: {}", transactionId);
            PerfCounter.count("UpdatePayResultRepeatedTradeNotify", 1);
            return true;
        }

        long now = bServiceProxy.getTimestamp();
        boolean success = ResponseStatus.STATUS_SUCCESS.equals(status);
        TradeStatus newTradeStatus = success ? TradeStatus.SUCCESS : TradeStatus.FAIL;
        if (ResponseStatus.STATUS_TRANSACTION_CLOSED.equals(status)) {
            // 交易关闭
            newTradeStatus = TradeStatus.CLOSE;
        }
        LOGGER.info("get pay result: {}, transaction id: {}, trade status: {}", success, transactionId, newTradeStatus);
        deductTradeDetail.setTradeStatus(newTradeStatus.getValue());
        deductTradeDetail.setPaymentStatus((success ? PaymentStatus.SUCCESS : PaymentStatus.EXPIRED_CLOSE).getValue());
        deductTradeDetail.setUpdateTime(now);
        deductTradeDetail.setReceiveTime(now);
        deductTradeDetail.setPayTime(payResult.getPayTime());
        // 设置来自支付机构的trade id
        deductTradeDetail.setTradeId(payResult.getTradeId());

        PerfCounter.countDuration("TradeDuration", deductTradeDetail.getPayTime() - deductTradeDetail.getCreateTime());
        int rows = deductTradeDetailDAO.updateByTradeStatus(deductTradeDetail, tradeStatus);
        if (rows > 0) {
            PerfCounter.count("UpdatePayResultSucceed", 1);
            return true;
        } else {
            PerfCounter.count("UpdatePayResultFailure", 1);
            return false;
        }
    }

    public TRDetailListResponse querySuccessDeductTradeDetailList(TRDetailListRequest request) {
        LOGGER.info("TradeBiz.querySuccessTradeDetailList() invoke, param is {}, {}, {} ", request.getBeginTime(),
                request.getEndTime(), request.getTradeType());
        TRDetailListResponse response = new TRDetailListResponse();
        List<BillDetail> billData = new ArrayList<BillDetail>();
        try {
            long beginTime = request.getBeginTime();
            long endTime = request.getEndTime();
            int total = deductTradeDetailDAO.findListByPayTimeCount(beginTime, endTime);
            if (total > 0) {
                List<DeductTradeDetail> data = deductTradeDetailDAO.findListByPayTime(beginTime, endTime,
                        request.getStart(),
                        request.getLength());
                if (data != null) {
                    for (DeductTradeDetail tra : data) {
                        BillDetail billDetail = new BillDetail();
                        billDetail.setAmount(tra.getTotalFee());
                        billDetail.setTradeType(com.xiaomi.mifi.insurance.payment.thrift.TradeType.DAIKOU.getValue());
                        billDetail.setChannel(PaymentChannel.MICASH.getIndex());
                        billDetail.setId(tra.getId());
                        billDetail.setOrderId(tra.getOrderId());
                        billDetail.setPayTime(tra.getPayTime());
                        billDetail.setStatus(tra.getPaymentStatus());
                        billDetail.setTransactionId(tra.getTransactionId());
                        billData.add(billDetail);
                    }
                }
            }
            response.setBillDetails(billData);
            response.setResponse(ResponseUtils.getSuccessResponse());
            response.setTotal(total);
        } catch (Exception e) {
            response.setResponse(ResponseUtils.getResponse(ErrorCode.INTERNAL_SERVER_ERROR));
            LOGGER.error("querySuccessDecutTradeDetailList Exception {}", e.toString(), e);
        }

        LOGGER.info("for duizhang TradeBiz.querySuccessTradeDetailList response {}", response);
        return response;
    }

    @Transactional
    public boolean isExpiredAndUpdate(long transactionalId) {
        LOGGER.debug("check trade expireTime, transactionalId: {}", transactionalId);
        DeductTradeDetail tradeDetail = deductTradeDetailDAO.selectForUpdate(transactionalId);

        int oldStatus = tradeDetail.getTradeStatus();
        if (oldStatus == TradeStatus.INIT.getValue() || oldStatus == TradeStatus.WAIT_PAY.getValue()) {
            long expireTime = tradeDetail.getExpireTime();
            long now = bServiceProxy.getTimestamp();
            if (expireTime < now) {
                LOGGER.warn("expired trade, transactionId: {}, now: {}, expireTime: {}", transactionalId, now,
                        tradeDetail.getExpireTime());
                tradeDetail.setTradeStatus(TradeStatus.CLOSE.getValue());
                tradeDetail.setPaymentStatus(PaymentStatus.EXPIRED_CLOSE.getValue());
                deductTradeDetailDAO.updateByTradeStatus(tradeDetail, oldStatus);
                PerfCounter.count("DeductTradeBizSetTradeExpired", 1);
                return true;
            }
            LOGGER.info("trade is in processing, now: {}, expireTime: {}", now, tradeDetail.getExpireTime());
        }
        return false;
    }

    public TRResponse setTradeExpired(long transactionId) {
        LOGGER.info("setTradeExpired transactionId is {}", transactionId);
        TRResponse trResponse = new TRResponse();
        PerfCounter.count("BackendAutoRunSetTradeExpiredTimes", 1);
        if (isExpiredAndUpdate(transactionId)) {
            notifyBiz.sendNotify(transactionId);
            trResponse.setSuccess(true);
            LOGGER.info("setTradeExpired success transactionId is {}", transactionId);
        } else {
            trResponse.setSuccess(false);
            LOGGER.info("setTradeExpired false transactionId is {}", transactionId);
        }
        return trResponse;
    }

    public List<Long> queryExpiredTrades(int offset, int length) {
        LOGGER.info("TradeBiz.queryExpiredTrades offset is {}, length is {}", offset, length);
        long now = bServiceProxy.getTimestamp();
        return deductTradeDetailDAO.queryExpiredTrades(now - ONE_DAY, now, offset, length, statusList);
    }

}
