package com.xiaomi.mifi.payment.biz.facade;

import static com.xiaomi.mifi.payment.util.ResponseUtils.getTRRefundResponse;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.mysql.jdbc.StringUtils;
import com.xiaomi.common.perfcounter.PerfCounter;
import com.xiaomi.mifi.common.thrift.model.TRResponse;
import com.xiaomi.mifi.insurance.common.util.exception.ErrorCode;
import com.xiaomi.mifi.insurance.common.util.exception.ServiceLogicException;
import com.xiaomi.mifi.insurance.payment.thrift.CommitPaymentMethod;
import com.xiaomi.mifi.insurance.payment.thrift.PaymentRequestParam;
import com.xiaomi.mifi.insurance.payment.thrift.RefundRequestParam;
import com.xiaomi.mifi.payment.biz.NotifyBiz;
import com.xiaomi.mifi.payment.biz.RefundBiz;
import com.xiaomi.mifi.payment.biz.TradeBiz;
import com.xiaomi.mifi.payment.config.Configure;
import com.xiaomi.mifi.payment.exception.PaymentGatewayResponseException;
import com.xiaomi.mifi.payment.gateway.PaymentGateway;
import com.xiaomi.mifi.payment.gateway.WeixinPaymentGateway;
import com.xiaomi.mifi.payment.model.CommitBindDeductRequest;
import com.xiaomi.mifi.payment.model.CommitBindDeductResult;
import com.xiaomi.mifi.payment.model.CommitDeductRequest;
import com.xiaomi.mifi.payment.model.CommitDeductResult;
import com.xiaomi.mifi.payment.model.CommitPayRequest;
import com.xiaomi.mifi.payment.model.CommitPayResult;
import com.xiaomi.mifi.payment.model.CommitRefundRequest;
import com.xiaomi.mifi.payment.model.CommitRefundResult;
import com.xiaomi.mifi.payment.model.PaymentChannel;
import com.xiaomi.mifi.payment.proxy.BServiceProxy;
import com.xiaomi.mifi.payment.thrift.CardType;
import com.xiaomi.mifi.payment.thrift.PaymentStatus;
import com.xiaomi.mifi.payment.thrift.RefundDetail;
import com.xiaomi.mifi.payment.thrift.TRPayResponse;
import com.xiaomi.mifi.payment.thrift.TRRefundResponse;
import com.xiaomi.mifi.payment.thrift.TradeDetail;
import com.xiaomi.mifi.payment.thrift.TradeStatus;
import com.xiaomi.mifi.payment.util.WeixinPayUtils;

import zander.com.google.common.base.Strings;

/**
 * Created by mars on 17-4-20.
 */
@Service
public class WeiXinPaymentFacade extends AbstractPaymentFacade {
    private static Logger LOGGER = LoggerFactory.getLogger(WeiXinPaymentFacade.class);

    @Autowired
    PaymentFacadeRegistry registry;

    @Autowired
    WeixinPaymentGateway weixinPaymentGateway;

    @Autowired
    RefundBiz refundBiz;

    @Autowired
    NotifyBiz notifyBiz;

    @Autowired
    TradeBiz tradeBiz;

    @Autowired
    Configure config;

    @Autowired
    BServiceProxy bServiceProxy;

    private String weixinNotifyUrl = "";
    private String weixinReturnUrl = "";

    @PostConstruct
    public void init() {
        registry.register(this);
        weixinNotifyUrl = config.getString("weixin.notify.url");
        weixinReturnUrl = config.getString("weixin.return.url");
    }

    @Override
    public PaymentChannel getChannel() {
        return PaymentChannel.WECHAT;
    }

    @Override
    public CommitPayRequest generatePayment(TradeDetail tradeDetail) {
        LOGGER.info("WeiXinPaymentFacade.generatePayment, tradeDetail: {}", tradeDetail);
        CommitPayRequest commitPayRequest = new CommitPayRequest();
        commitPayRequest.setTransactionId(tradeDetail.getTransactionId());
        commitPayRequest.setGoodName(tradeDetail.getProductName());
        commitPayRequest.setOrderDesc(tradeDetail.getOrderDesc());
        commitPayRequest.setReturnUrl(weixinReturnUrl);
        commitPayRequest.setExpireTime(tradeDetail.getExpireTime());
        commitPayRequest.setTotalFee(tradeDetail.getTotalFee());
        commitPayRequest.setNotifyUrl(weixinNotifyUrl);
        commitPayRequest.setCreateIp(tradeDetail.getCreateIp());
        commitPayRequest.setCreateTime(tradeDetail.getCreateTime());
        LOGGER.info("WeiXinPaymentFacade.generatePayment, return commitPayRequest: {}", commitPayRequest);
        return commitPayRequest;
    }

    @Override
    public CommitRefundRequest generateRefund(RefundDetail refundDetail) {
        return super.generateRefund(refundDetail);
    }

    @Override
    public CommitPayResult commitPay(CommitPayRequest commitPayRequest) {
        LOGGER.info("WeixinPaymentFacade.commitPay commitPayRequest is {}", commitPayRequest);
        CommitPayResult commitPayResult = new CommitPayResult();
        Map<PaymentRequestParam, String> params = new HashMap<>();
        params.put(PaymentRequestParam.MERCHANT_TRANSACTION_ID, String.valueOf(commitPayRequest.getTransactionId()));
        params.put(PaymentRequestParam.PAY_SUBJECT, commitPayRequest.getGoodName());
        params.put(PaymentRequestParam.PAY_DESCRIPTION, commitPayRequest.getOrderDesc());
        params.put(PaymentRequestParam.NOTIFY_URL, commitPayRequest.getNotifyUrl());
        params.put(PaymentRequestParam.RETURN_URL, commitPayRequest.getReturnUrl());
        params.put(PaymentRequestParam.PAY_AMOUNT, String.valueOf(commitPayRequest.getTotalFee()));
        params.put(PaymentRequestParam.PAY_TIMEOUT,
                new DateTime(commitPayRequest.getExpireTime()).toString("yyyyMMddHHmmss"));
        params.put(PaymentRequestParam.CREATE_IP, commitPayRequest.getCreateIp());
        params.put(PaymentRequestParam.CREATE_TIME,
                new DateTime(commitPayRequest.getCreateTime()).toString("yyyyMMddHHmmss"));

        if (commitPayRequest.getAllowedCardType().contains(CardType.CREDIT)) {
            params.put(PaymentRequestParam.PAY_ALLOW_CREDIT_CARD, PaymentGateway.TRUE);
        }
        try {
            String parameters = weixinPaymentGateway.createPayRequest(params);
            commitPayResult.setSuccess(true);
            commitPayResult.setErrorCode(ErrorCode.SUCCESS);
            commitPayResult.setUrl(parameters);
            commitPayResult.setParams("");
            commitPayResult.setMethod(CommitPaymentMethod.FORM);
        } catch (ServiceLogicException | PaymentGatewayResponseException e) {
            LOGGER.error("weixinPaymentGateway.createPayRequest error, params: {}", params);
            commitPayResult.setSuccess(false);
            commitPayResult.setErrorCode(ErrorCode.INTERNAL_SERVER_ERROR);
            commitPayResult.setParams("");
        }
        LOGGER.info("weixinPaymentFacade.commitPay result is {}", commitPayResult.getParams());
        return commitPayResult;
    }

    @Override
    public CommitRefundResult commitRefund(CommitRefundRequest commitRefundRequest) {
        LOGGER.info("WeixinPaymentFacade.commitRefund commitRefundRequest is {}", commitRefundRequest);
        CommitRefundResult commitRefundResult = new CommitRefundResult();
        Map<RefundRequestParam, String> params = new HashMap<>();
        params.put(RefundRequestParam.OUTER_ORDER_ID, String.valueOf(commitRefundRequest.getTradeTransactionId()));
        params.put(RefundRequestParam.TARDE_NO, commitRefundRequest.getOriginTradeId());
        params.put(RefundRequestParam.REFUND_AMOUNT, String.valueOf(commitRefundRequest.getRefundFee()));
        params.put(RefundRequestParam.OUTER_REQUEST_NO, String.valueOf(commitRefundRequest.getRefundTransactionId()));
        try {
            String response = weixinPaymentGateway.createRefundRequest(params);
            commitRefundResult = receiveWeixinRefundReturn(response, commitRefundRequest.getTradeTransactionId());
        } catch (ServiceLogicException | PaymentGatewayResponseException e) {
            LOGGER.error("alipayPaymentGateway.createRefundRequest error, params: {}", params);
            commitRefundResult.setSuccess(false);
            commitRefundResult.setErrorCode(ErrorCode.INTERNAL_SERVER_ERROR);
            commitRefundResult.setResponse("payment internal exception");
        }
        LOGGER.info("AlipayPaymentFacade.commitRefund result is ", commitRefundResult.getResponse());
        return commitRefundResult;
    }

    @Override
    public CommitBindDeductResult commitBindDeduct(CommitBindDeductRequest commitBindDeductRequest) {
        return null;
    }

    @Override
    public CommitDeductResult commitDeduct(CommitDeductRequest commitDeductRequest) {
        throw new UnsupportedOperationException("WeChatPaymentFacade dose not support commitDeduct!");
    }

    @Override
    public TRPayResponse convertCommitPayResult(CommitPayResult result) {
        return null;
    }

    @Override
    public TRRefundResponse convertCommitRefundResult(CommitRefundResult commitRefundResult,
            RefundDetail refundDetail) {
        LOGGER.info("AlipayPaymentFacade.convertCommitRefundResult, commitRefundResult is {}, refundDetail is {}",
                commitRefundResult, refundDetail);
        if (commitRefundResult.isSuccess()) {
            return getTRRefundResponse(ErrorCode.SUCCESS, refundDetail);
        } else {
            // 这里单独返回支付宝退款同步返回结果中的错误信息,放入TRRefundResponse中
            TRResponse trResponse = new TRResponse();
            trResponse.setSuccess(false);
            trResponse.setCode(ErrorCode.REQUEST_FAILED.code);
            trResponse.setDesc(ErrorCode.REFUND_ERROR.externalDescription);
            trResponse.setBizContent(commitRefundResult.getResponse());
            return new TRRefundResponse(trResponse, refundDetail);
        }
    }

    @Override
    public void notifyRefund(Map<String, String> params) throws Exception {
        throw new UnsupportedOperationException("WeChatPaymentFacade dose not support notifyRefund!");
    }

    @Override
    public boolean verifyPayParam(Map<String, String> params){
        if (Strings.isNullOrEmpty(params.get("out_trade_no"))) {
            return false;
        }
        return true;
    }

    @Override
    public boolean verifyRefundParam(Map<String, String> params){
        return true;
    }

    @Override
    public TradeDetail getTradeDetailFromReturnParam(Map<String, String> params) throws ServiceLogicException {
        boolean isVerify = verifyReturnUrlParam(params);
        long transactionId = 0;
        if (isVerify) {
            transactionId = weixinPaymentGateway.getTransactionIdFromReturnMap(params);
        } else {
            LOGGER.warn("WeixinPaymentFacade.verifyReturnUrlParam return false, params: {}", params);
            throw ServiceLogicException.INVALID_PARAM;
        }
        return tradeBiz.findByTransactionId(transactionId);
    }

    @Transactional(propagation = Propagation.NOT_SUPPORTED)
    public CommitRefundResult receiveWeixinRefundReturn(String response, long outerTransactionId) {
        CommitRefundResult commitRefundResult = new CommitRefundResult();

        if (StringUtils.isNullOrEmpty(response)) {
            LOGGER.error("refund response is null");
            commitRefundResult.setSuccess(false);
            commitRefundResult.setErrorCode(ErrorCode.PARAMETER_ERROR);
            commitRefundResult.setResponse("refund response is null");
            PerfCounter.count("WeixinRefundReturnResponseIsNull", 1);
            return commitRefundResult;
        }
        Map<String, String> result = WeixinPayUtils.xmlDataToMap(response);
        String returnCode = result.get("return_code");
        if (returnCode.equals("SUCCESS")) {
            long refundFee = Long.valueOf(result.get("refund_fee"));
            long refundTime = System.currentTimeMillis();
            long originTradeTransactionId = Long.valueOf(result.get("out_trade_no"));
            String refundTradeId = result.get("refund_id");
            if (refundFee < 0 || originTradeTransactionId <= 0 || StringUtils.isNullOrEmpty(refundTradeId)) {
                commitRefundResult.setSuccess(false);
                commitRefundResult.setErrorCode(ErrorCode.REQUEST_FAILED);
                commitRefundResult.setResponse("weixin return parameter error");
                RefundDetail refundDetail = refundBiz.findRefundByTradeTransactionId(outerTransactionId);
                if (refundDetail != null) {
                    refundDetail.setPaymentStatus(PaymentStatus.FAIL.getValue());
                    refundDetail.setStatus(TradeStatus.FAIL.getValue());
                    refundBiz.updateRefundDetail(refundDetail);
                } else {
                    LOGGER.error("refund detail not found, refund transactionId: {}", outerTransactionId);
                }
                notifyBiz.sendRefundNotify(outerTransactionId);
                PerfCounter.count("AlipayRefundReturnParameterError", 1);
                return commitRefundResult;
            }

            RefundDetail refundDetail = refundBiz.findRefundByTradeTransactionId(originTradeTransactionId);
            if (refundDetail.getStatus() == TradeStatus.SUCCESS.getValue()
                    && refundDetail.getPaymentStatus() == PaymentStatus.SUCCESS.getValue()) {
                commitRefundResult.setSuccess(true);
                commitRefundResult.setErrorCode(ErrorCode.REPEATED_REFUND);
                commitRefundResult.setResponse("Refund is already success.");
                PerfCounter.count("WeixinRefundReturnAlreadySucceed", 1);
                return commitRefundResult;
            }

            if (refundDetail.getAmount() == refundFee) {
                refundDetail.setPaymentStatus(PaymentStatus.SUCCESS.getValue());
                refundDetail.setStatus(TradeStatus.SUCCESS.getValue());
                refundDetail.setUpdateTime(System.currentTimeMillis());
                refundDetail.setReceiveTime(System.currentTimeMillis());
                refundDetail.setPayTime(refundTime);
                refundDetail.setRefundTradeId(refundTradeId);
                // 这里先更新退款表的状态,不用等通知一定成功,也不用加事务处理
                refundBiz.updateRefundDetail(refundDetail);
                notifyBiz.sendRefundNotify(originTradeTransactionId);
                commitRefundResult.setSuccess(true);
                commitRefundResult.setErrorCode(ErrorCode.SUCCESS);
                commitRefundResult.setResponse(refundDetail.toString());
                PerfCounter.count("WeixinRefundReturnSucceed", 1);
                PerfCounter.countDuration("WeixinRefundDuration",
                        bServiceProxy.getTimestamp() - refundDetail.getCreateTime());
                return commitRefundResult;
            } else {
                refundDetail.setPaymentStatus(PaymentStatus.FAIL.getValue());
                refundDetail.setStatus(TradeStatus.FAIL.getValue());
                refundBiz.updateRefundDetail(refundDetail);
                notifyBiz.sendRefundNotify(originTradeTransactionId);
                commitRefundResult.setSuccess(false);
                commitRefundResult.setErrorCode(ErrorCode.REFUND_ERROR);
                commitRefundResult.setResponse(response);
                PerfCounter.count("WeixinRefundReturnFeeNotMatch", 1);
                PerfCounter.countDuration("WeixinRefundDuration",
                        bServiceProxy.getTimestamp() - refundDetail.getCreateTime());
                return commitRefundResult;
            }
        } else {
            PerfCounter.count("WeixinRefundReturnFail", 1);
            LOGGER.error("Weixin refund return fail, msg is {}", response);
            commitRefundResult.setSuccess(false);
            commitRefundResult.setErrorCode(ErrorCode.REFUND_ERROR);
            commitRefundResult.setResponse(response);
            RefundDetail refundDetail = refundBiz.findRefundByTradeTransactionId(outerTransactionId);
            if (refundDetail != null) {
                refundDetail.setPaymentStatus(PaymentStatus.FAIL.getValue());
                refundDetail.setStatus(TradeStatus.FAIL.getValue());
                refundBiz.updateRefundDetail(refundDetail);
            } else {
                LOGGER.error("refund detail not found, refund transactionId: {}", outerTransactionId);
            }
            notifyBiz.sendRefundNotify(outerTransactionId);
            return commitRefundResult;
        }
    }

    private boolean verifyReturnUrlParam(Map<String, String> params) {
        if (params == null) {
            return false;
        }

        if (params.get("out_trade_no") == null) {
            return false;
        }

        return weixinPaymentGateway.parseReturnUrl(params);
    }
}
