package com.xiaomi.mifi.payment.proxy;

import javax.annotation.Resource;

import org.apache.thrift.TException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.xiaomi.mifi.idcenter.service.MifiIdCenterService;
import com.xiaomi.mifi.insurance.common.util.exception.ErrorCode;
import com.xiaomi.mifi.insurance.common.util.exception.ServiceLogicException;
import com.xiaomi.mifi.insurance.thrift.service.MifiInsuranceService;
import com.xiaomi.mifi.insurance.thrift.service.TRPayCenterNotify;
import com.xiaomi.mifi.payment.model.ThriftNotifyRequest;
import com.xiaomi.mifi.payment.util.ConvertUtils;

@Service
public class BServiceProxyImpl implements BServiceProxy {
    private static final Logger LOGGER = LoggerFactory.getLogger(BServiceProxyImpl.class);

    @Resource(name = "idCenter")
    private MifiIdCenterService.Iface idCenter;

    @Resource(name = "insuranceNotify")
    private MifiInsuranceService.Iface insuranceService;

    @Override
    public long getId() throws ServiceLogicException {
        try {
            long id = idCenter.getId("mifi-insurance-payment");
            LOGGER.info("idCenter.getId : {}", id);
            return id;
        } catch (TException e) {
            LOGGER.error("error when get id from idCenter", e);
        }
        throw ServiceLogicException.INTERNAL_SERVICE_ERROR;
    }

    @Override
    public long getTimestamp() {
        return System.currentTimeMillis();
    }

    @Override
    public void insurancePayCenterNotify(ThriftNotifyRequest thriftNotifyRequest) throws ServiceLogicException {
        try {
            TRPayCenterNotify trPayCenterNotify = ConvertUtils.convertCommitNotify2PayCenterNotify(thriftNotifyRequest);
            insuranceService.insurancePayCenterNotify(trPayCenterNotify);
        } catch (TException e) {
            LOGGER.error("BServiceProxyImpl.insurancePayCenterNotify exception thriftNotifyRequest:{}", thriftNotifyRequest);
            throw new ServiceLogicException(ErrorCode.INTERNAL_SERVER_ERROR);
        }
    }
}
