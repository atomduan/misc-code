package com.xiaomi.mifi.payment.dao;

import java.util.List;

import com.xiaomi.mifi.payment.thrift.TradeDetail;

import net.paoding.rose.jade.annotation.DAO;
import net.paoding.rose.jade.annotation.ReturnGeneratedKeys;
import net.paoding.rose.jade.annotation.SQL;
import net.paoding.rose.jade.annotation.UseMaster;

/**
 * Created by mars on 17-4-20.
 */
@DAO
public interface TradeDetailDAO {
    String TABLE_NAME = "trade_detail";

    String IFColumns = "channel, trade_type, trade_status, seller_id, order_id, transaction_id, trade_id, total_fee, currency, product_name, order_desc, payment_status, pay_time, notify_id, return_url, error_desc, error_code, xiaomi_id, pay_method, expire_time, create_time, update_time, receive_time, create_ip";

    String IFFields = ":1.id, :1.channel, :1.tradeType, :1.tradeStatus, :1.sellerId, :1.orderId, :1.transactionId, :1.tradeId, :1.totalFee, :1.currency, :1.productName, :1.orderDesc, :1.paymentStatus, :1.payTime, :1.notifyId, :1.returnUrl, :1.errorDesc, :1.errorCode, :1.xiaomiId, :1.payMethod, :1.expireTime, :1.createTime, :1.updateTime, :1.receiveTime, :1.createIp";

    String INSERT_VALUES = ":1.channel, :1.tradeType, :1.tradeStatus, :1.sellerId, :1.orderId, :1.transactionId, :1.tradeId, :1.totalFee, :1.currency, :1.productName, :1.orderDesc, :1.paymentStatus, :1.payTime, :1.notifyId, :1.returnUrl, :1.errorDesc, :1.errorCode, :1.xiaomiId, :1.payMethod, :1.expireTime, :1.createTime, :1.updateTime, :1.receiveTime, :1.createIp";

    String IFUpdate = "channel=:1.channel, trade_status=:1.tradeStatus, seller_id=:1.sellerId, trade_id=:1.tradeId, payment_status=:1.paymentStatus, pay_time=:1.payTime, notify_id=:1.notifyId, return_url=:1.returnUrl, error_desc=:1.errorDesc, error_code=:1.errorCode, xiaomi_id=:1.xiaomiId, pay_method=:1.payMethod, expire_time=:1.expireTime, create_time=:1.createTime, update_time=:1.updateTime, receive_time=:1.receiveTime, create_ip=:1.createIp";

    String SELECT_COLUMNS = "id, " + IFColumns;

    @ReturnGeneratedKeys
    @SQL("INSERT INTO " + TABLE_NAME + "(" + IFColumns + ")VALUES(" + INSERT_VALUES + ")")
    long insert(TradeDetail tradeDetail);

    @UseMaster
    @SQL("SELECT " + SELECT_COLUMNS + " FROM " + TABLE_NAME + " WHERE order_id=:1")
    TradeDetail findByOrderId(long orderId);

    @UseMaster
    @SQL("SELECT " + SELECT_COLUMNS + " FROM " + TABLE_NAME + " WHERE transaction_id=:1")
    TradeDetail findByTransactionId(long transactionId);

    @UseMaster
    @SQL("SELECT " + SELECT_COLUMNS + " FROM " + TABLE_NAME + " WHERE transaction_id=:1 FOR UPDATE")
    TradeDetail selectForUpdate(long transactionId);

    @SQL("SELECT " + SELECT_COLUMNS + " FROM " + TABLE_NAME + " WHERE create_time>=:1 and create_time<=:2 #if(:3>=0) {and trade_status=:3} LIMIT :4, :5")
    List<TradeDetail> findByTimeSpanAndTradeStatus(long beginTime, long endTime, int tradeStatus, int offset, int length);

    @SQL("UPDATE " + TABLE_NAME + " SET " + IFUpdate + " WHERE transaction_id=:1.transactionId")
    int updateTradeDetail(TradeDetail tradeDetail);

    @SQL("UPDATE " + TABLE_NAME + " SET " + IFUpdate + " WHERE transaction_id=:1.transactionId AND trade_status=:2")
    int updateByTradeStatus(TradeDetail tradeDetail, int oldStatus);

    @SQL("SELECT " + SELECT_COLUMNS + " FROM " + TABLE_NAME
            + " WHERE pay_time>=:1 AND pay_time<=:2 AND channel=:3 AND payment_status=3")
    List<TradeDetail> findByPayTime(long beginTime, long endTime, int channel);

    @SQL("SELECT " + SELECT_COLUMNS + " FROM " + TABLE_NAME
            + " WHERE pay_time>=:1 AND pay_time<=:2 AND payment_status=3 ORDER BY `id` LIMIT :3, :4")
    List<TradeDetail> findListByPayTime(long beginTime, long endTime, int pageStart, int pageNum);

    @SQL("SELECT COUNT(*) FROM " + TABLE_NAME
            + " WHERE pay_time>=:1 AND pay_time<=:2 AND payment_status=3")
    int findListByPayTimeCount(long beginTime, long endTime);

    @SQL("SELECT transaction_id FROM " + TABLE_NAME
            + " WHERE create_time>:1 AND expire_time<:2 AND trade_status IN (:5) LIMIT :3, :4")
    List<Long> queryExpiredTrades(long createTime, long currentTime, int offset, int count, List<Integer> tradeStatus);
}
