package com.xiaomi.mifi.payment.gateway;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.net.URISyntaxException;
import java.security.PublicKey;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import javax.annotation.PostConstruct;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.commons.lang.StringUtils;
import org.apache.http.NameValuePair;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.client.utils.URLEncodedUtils;
import org.apache.http.message.BasicNameValuePair;
import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;

import com.google.common.base.Preconditions;
import com.mifi.insurance.payment.util.ResponseStatus;
import com.xiaomi.common.perfcounter.PerfCounter;
import com.xiaomi.mifi.insurance.common.util.exception.ServiceLogicException;
import com.xiaomi.mifi.insurance.common.util.http.HttpRequester;
import com.xiaomi.mifi.insurance.payment.thrift.BillType;
import com.xiaomi.mifi.insurance.payment.thrift.PaymentGatewayName;
import com.xiaomi.mifi.insurance.payment.thrift.PaymentRequestParam;
import com.xiaomi.mifi.insurance.payment.thrift.PaymentResponseParam;
import com.xiaomi.mifi.insurance.payment.thrift.RefundRequestParam;
import com.xiaomi.mifi.insurance.payment.thrift.TRBillDetail;
import com.xiaomi.mifi.insurance.payment.thrift.TradeType;
import com.xiaomi.mifi.payment.config.Configure;
import com.xiaomi.mifi.payment.crypto.CryptoUtils;
import com.xiaomi.mifi.payment.crypto.MultiFieldsSignature;
import com.xiaomi.mifi.payment.exception.PaymentGatewayResponseException;
import com.xiaomi.mifi.payment.model.CommitBindDeductRequest;
import com.xiaomi.mifi.payment.model.CommitBindDeductResult;
import com.xiaomi.mifi.payment.model.CommitDeductRequest;
import com.xiaomi.mifi.payment.model.PayResult;
import com.xiaomi.mifi.payment.thrift.CardType;
import com.xiaomi.mifi.payment.util.PayCenterUtils;
import com.xiaomi.mifi.payment.util.ResponseUtils;
import com.xiaomi.mifi.payment.util.WeixinPayUtils;
import com.xiaomi.miliao.net.NetworkUtil;

@Service
public class MiCashpayPaymentGateway extends AbstractPaymentGateway {

    private static final Logger LOGGER = LoggerFactory.getLogger(MiCashpayPaymentGateway.class);

    private static final String SERVICE_VERSION = "1.0";

    private static final String CHARSET = "UTF-8";

    private static final String SIGN_TYPE = "RSA";

    private static final String NEWLINE_SEPARATOR = "\n|\r\n|\r";

    private static final String SEPARATOR = ",";
    @Autowired
    PaymentGatewayRegistry registry;
    @Autowired
    Configure config;

    @Qualifier("httpRequester")
    @Autowired
    HttpRequester httpRequester;

    @Qualifier("merchantSignature")
    @Autowired
    MultiFieldsSignature merchantSignature;

    @Qualifier("payMerchantSignature")
    @Autowired
    MultiFieldsSignature payMerchantSignature;

    @Autowired
    @Qualifier("notifyMipayRefundUrlPattern")
    private String notifyUrl;

    private String requestWithdrawUrl;
    private String queryBillUrl;
    private String merchantId;
    private String payMerchantId;
    private PublicKey cashpayPublicKey;
    private String cashpayRefundUrl;
    private String deductSignPageUrl;
    private String deductUrl;

    @PostConstruct
    public void init() {
        registry.register(this);

        requestWithdrawUrl = config.getString("url.cashpay.withdraw");
        queryBillUrl = config.getString("url.cashpay.querybill");

        LOGGER.debug("get cashpay withdraw url: {}, query bill url: {}", requestWithdrawUrl, queryBillUrl);
        merchantId = config.getString("cashpay.merchant.id");
        payMerchantId = config.getString("cashpay.pay.merchant.id");
        String cashpayPk = config.getString("cashpay.pk");

        cashpayPublicKey = CryptoUtils.generatePublicKey(cashpayPk);
        LOGGER.info("load merchant id: {}, cashpay pk: {}", merchantId, cashpayPk);

        cashpayRefundUrl = config.getString("url.cashpay.refund");
        deductSignPageUrl = config.getString("cashpay.deduct.signpage.url");
        deductUrl = config.getString("cashpay.mipay.host.url") + "/merchant/deduct";

        setAdapter(new MiCashpayDataAdapter());
    }

    /*
     * for unit test
     */
    public void setAdaptorForTest() {
        setAdapter(new MiCashpayDataAdapter());
    }

    @Override
    public PaymentGatewayName getName() {
        return PaymentGatewayName.CASHPAY;
    }

    @Override
    public PayResult parsePayNotify(Map<String, String> notification) {
        HashMap<String, String> params = new HashMap<>(notification);

        String sign = params.remove("sign");

        String transactionIdStr = params.get("outOrderId"); // 我方生成的订单号
        LOGGER.debug("verifying pay notify, transaction id: {}, sign: {}", transactionIdStr, sign);

        boolean verify = payMerchantSignature.verify(params, sign);

        PayResult ret = new PayResult();
        if (!verify) {
            LOGGER.warn("signature of signature mismatches, transaction id: {}", transactionIdStr);
            ret.setStatus(ResponseStatus.STATUS_SIGN_MISMATCH);
            return ret;
        }

        String tradeId = params.get("tradeId"); // 小米钱包生成的账单号
        long transactionId = 0;
        try {
            transactionId = Long.parseLong(transactionIdStr);
        } catch (Exception e) {
            LOGGER.error("error when parse transaction id", e);
        }

        String payTimeStr = params.get("payTime");
        long payTime = 0;
        try {
            payTime = Long.parseLong(payTimeStr) * 1000;
        } catch (Exception e) {
            LOGGER.error("error when parse pay time", payTime);
        }
        String tradeStatusRet = params.get("tradeStatus");

        String status = null;
        if ("TRADE_CLOSED".equals(tradeStatusRet)) {
            status = ResponseStatus.STATUS_TRANSACTION_CLOSED;
            LOGGER.info("MI cash pay trade status is TRADE_CLOSED, transactionId is {}", transactionId);
            PerfCounter.count("MiCashParseTradeCloseNotifyTimes", 1);
        } else if ("TRADE_SUCCESS".equals(tradeStatusRet)) {
            status = ResponseStatus.STATUS_SUCCESS;
            LOGGER.info("MI cash pay trade status is TRADE_SUCCESS, transactionId is {}", transactionId);
            PerfCounter.count("MiCashParseTradeSuccessNotifyTimes", 1);
        } else if ("TRADE_CANCEL".equals(tradeStatusRet)) {
            status = ResponseStatus.STATUS_TRANSACTION_CANCELED;
            LOGGER.info("MI cash pay trade status is TRADE_CANCEL, transactionId is {}", transactionId);
            PerfCounter.count("MiCashParseTradeCancelNotifyTimes", 1);
        } else if("WAIT_PAY".equals(tradeStatusRet)){
            status = ResponseStatus.STATUS_WAIT_PAY;
            LOGGER.info("MI cash pay trade status is WAIT_PAY, transactionId is {}", transactionId);
            PerfCounter.count("MiCashParseTradeWaitPayNotifyTimes", 1);
        }
        ret.setStatus(status);
        ret.setTransactionId(transactionId);
        ret.setPayTime(payTime);
        ret.setTradeId(tradeId);

        return ret;
    }

    @Override
    public boolean parseReturnUrl(Map<String, String> params) {
        HashMap<String, String> parameters = new HashMap<>(params);

        String sign = parameters.remove("sign");
        parameters.remove("channel");

        String transactionIdStr = params.get("outOrderId"); // 我方生成的订单号
        LOGGER.debug("verifying pay return notify, transaction id: {}, sign: {}", transactionIdStr, sign);

        return payMerchantSignature.verify(parameters, sign);
    }

    @Override
    public List<TRBillDetail> queryNewBill(String billDate, BillType billType)
            throws ServiceLogicException, PaymentGatewayResponseException {
        return queryBill(billDate, billType, false);
    }

    @Override
    public Map<String, String> commitDeduct(CommitDeductRequest params) {
        Map<String, String> request = getAdapter().createDeductRequset(params);
        try {
            String content = getHttpRequester().postString(deductUrl, null, request);
            LOGGER.info("commit deduct response {}", content);
            Map<String, String> result = WeixinPayUtils.xmlDataToMap(content);
            return result;
        } catch (IOException e) {
            LOGGER.error("exception in commit deduct", e);
        }
        return null;
    }

    public CommitBindDeductResult createDeductSign(CommitBindDeductRequest params) {
        return getAdapter().createDeductSign(params);

    }

    @Override
    HttpRequester getHttpRequester() {
        return httpRequester;
    }

    class MiCashpayDataAdapter implements GatewayDataAdapter {

        @Override
        public String getWithdrawUrl() {
            return requestWithdrawUrl;
        }

        @Override
        public String getQueryBillUrl() {
            return queryBillUrl;
        }

        @Override
        public String getTransactionId(Map<PaymentRequestParam, String> params) {
            return params.get(PaymentRequestParam.MERCHANT_TRANSACTION_ID);
        }

        @Override
        public String createPayRequest(Map<PaymentRequestParam, String> params)
                throws ServiceLogicException, PaymentGatewayResponseException {
            String transactionId = params.get(PaymentRequestParam.MERCHANT_TRANSACTION_ID);
            String subject = params.get(PaymentRequestParam.PAY_SUBJECT);
            String description = params.get(PaymentRequestParam.PAY_DESCRIPTION);
            String amount = params.get(PaymentRequestParam.PAY_AMOUNT);
            String notifyUrl = params.get(PaymentRequestParam.NOTIFY_URL);
            String returnUrl = params.get(PaymentRequestParam.RETURN_URL);
            String timeout = params.get(PaymentRequestParam.PAY_TIMEOUT);
            boolean allowCreditCard = TRUE.equals(params.get(PaymentRequestParam.PAY_ALLOW_CREDIT_CARD));
            String xiaomiId = params.get(PaymentRequestParam.XIAOMI_ID);

            return createPayRequestMap(transactionId,subject,description,amount,notifyUrl,returnUrl,timeout,allowCreditCard,xiaomiId);
        }

        @Override
        public String sendRequest(Map<String, String> request) throws ServiceLogicException {
            HttpRequester httpRequester = getHttpRequester();
            HttpRequester.HttpResult get;
            try {
                get = httpRequester.get(cashpayRefundUrl, request);
            } catch (IOException e) {
                LOGGER.error("error when sendRequest: {}", request, e);
                throw ServiceLogicException.ACCESS_GATEWAY_ERROR;
            }

            String response;
            try {
                response = get.getString();
            } catch (IOException e) {
                LOGGER.error("IOException when sendRequest", e);
                throw ServiceLogicException.ACCESS_GATEWAY_ERROR;
            }
            LOGGER.debug("get response sendRequest, response: {}", response);
            return response;
        }

        @Override
        public Map<String, String> createWithdrawRequest(Map<PaymentRequestParam, String> params) throws PaymentGatewayResponseException, ServiceLogicException {
            String drawAmount = params.get(PaymentRequestParam.DRAW_AMOUNT);
            String transactionId = params.get(PaymentRequestParam.MERCHANT_TRANSACTION_ID);
            String drawDescription = params.get(PaymentRequestParam.DRAW_DESCRIPTION);
            String notifyUrl = params.get(PaymentRequestParam.NOTIFY_URL);
            String userId = params.get(PaymentRequestParam.XIAOMI_ID);

            try {
                Preconditions.checkNotNull(drawAmount);
                Preconditions.checkNotNull(transactionId);
            } catch (NullPointerException e) {
                LOGGER.warn("some params it missing for withdraw request");
                throw ServiceLogicException.MISSING_PARAM;
            }

            String encAmount = CryptoUtils.rsaEncryptBase64(cashpayPublicKey, String.valueOf(drawAmount));
            return createWithdrawRequestMap(userId, encAmount, transactionId, drawDescription, notifyUrl);
        }

        @Override
        public Map<PaymentResponseParam, String> parseWithdrawResponse(String response)
                throws PaymentGatewayResponseException, ServiceLogicException {
            Map<PaymentResponseParam, String> responseParams = new HashMap<>();
            try {
                DocumentBuilder db = DocumentBuilderFactory.newInstance().newDocumentBuilder();
                Document doc = db.parse(new ByteArrayInputStream(response.getBytes()));

                String isSuccess = doc.getElementsByTagName("isSuccess").item(0).getTextContent();

                if ("T".equals(isSuccess)) {
                    String outTransferId = doc.getElementsByTagName("outTransferId").item(0).getTextContent();
                    String transferId = doc.getElementsByTagName("transferId").item(0).getTextContent();
                    String transferDesc = doc.getElementsByTagName("transferDesc").item(0).getTextContent();

                    LOGGER.debug("request withdraw successfully, transaction id: {}, paycenter transferId: {}",
                            outTransferId, transferId);

                    responseParams.put(PaymentResponseParam.MERCHANT_TRANSACTION_ID, outTransferId);
                    responseParams.put(PaymentResponseParam.DRAW_ID, transferId);
                    responseParams.put(PaymentResponseParam.DRAW_RESULT_DESCRIPTION, transferDesc);

                    return responseParams;
                } else {
                    String responseCode = doc.getElementsByTagName("responseCode").item(0).getTextContent();
                    LOGGER.warn("withdraw failed, response code: {}", responseCode);
                    throw new PaymentGatewayResponseException(getName(), responseCode);
                }
            } catch (PaymentGatewayResponseException e) {
                throw e;
            } catch (Exception e) {
                LOGGER.error("error when parse refund response", e);
                throw ServiceLogicException.ACCESS_GATEWAY_ERROR;
            }
        }

        @Override
        public Map<String, String> createQueryBillRequest(String billDate, BillType billType, boolean isBackFee) {
            Map<String, String> params = new HashMap<String, String>();
            params.put("service", "queryMerchantBill");
            params.put("serviceVersion", SERVICE_VERSION);

            if (isBackFee) {
                params.put("partnerId", merchantId);
            } else {
                params.put("partnerId", payMerchantId);
            }
            params.put("inputCharset", CHARSET);
            params.put("billDate", billDate);
            // 商户向用户打钱，billType = REFUND，
            // 商户收到用户的退款（打钱失败），billType = PAY
            params.put("billType", billType == BillType.INCOME ? "PAY" : "REFUND");

            String requestIp = NetworkUtil.getLocalHostIp();
            Date now = new Date();
            DateFormat df = PayCenterUtils.createOrderDateFormat();

            params.put("requestTime", df.format(now));
            params.put("requestIp", requestIp);
            String sign = "";
            if (isBackFee) {
                sign = merchantSignature.sign(params);
            } else {
                sign = payMerchantSignature.sign(params);
            }

            params.put("sign", sign);
            params.put("signType", SIGN_TYPE);

            return params;
        }

        @Override
        public List<TRBillDetail> parseQueryBillResponse(String response) throws ServiceLogicException {
            ArrayList<TRBillDetail> ret = new ArrayList<>();
            try {
                DocumentBuilder db = DocumentBuilderFactory.newInstance().newDocumentBuilder();
                Document doc = db.parse(new ByteArrayInputStream(response.getBytes()));
                String isSuccess = doc.getElementsByTagName("isSuccess").item(0).getTextContent();
                if (isSuccess.equals("T")) {
                    NodeList nodeList = doc.getElementsByTagName("billDetail");
                    if (nodeList.getLength() == 0) {
                        LOGGER.debug("query mi cashpay bill is empty");
                        return ret;
                    }
                    String billTypeValue = doc.getElementsByTagName("billType").item(0).getTextContent();
                    BillType billType = BillType.INCOME;
                    if ("REFUND".equals(billTypeValue)) {
                        billType = BillType.OUTCOME;
                    }
                    String billDetail = doc.getElementsByTagName("billDetail").item(0).getTextContent();
                    String[] billDetailArray = billDetail.split(NEWLINE_SEPARATOR);
                    for (int i = 1; i < billDetailArray.length; i++) {
                        String[] billDetailVersion1 = billDetailArray[i].split(SEPARATOR);
                        String tradeId = billDetailVersion1[0].trim();
                        String merchantOrderId = billDetailVersion1[2].trim();
                        String tradeTypeValue = billDetailVersion1[3].trim();
                        // 代发交易，不管是商户向用户代发，还是退款，tradeTypeValue 均为 转账
                        TradeType tradeType;
                        if ("转账".equals(tradeTypeValue)) {
                            tradeType = TradeType.TRANSFER;
                        } else if (("支付".equals(tradeTypeValue))) {
                            tradeType = TradeType.PAY;
                        } else if ("退款".equals(tradeTypeValue)) {
                            tradeType = TradeType.REFUND;
                        } else {
                            LOGGER.warn("ignore unexpected trade type when query bill: {}", tradeTypeValue);
                            continue;
                        }
                        String time = billDetailVersion1[1].trim();
                        String amount = billDetailVersion1[4].trim();

                        TRBillDetail bill = new TRBillDetail();
                        bill.setTradeId(tradeId);
                        bill.setAmount(PayCenterUtils.parseAmountV0(amount));
                        bill.setOrderId(merchantOrderId);
                        bill.setTime(PayCenterUtils.parseEpochTime(time).getTime());
                        bill.setTradeType(tradeType);
                        bill.setGateway(getName());
                        bill.setBillType(billType);

                        ret.add(bill);
                        LOGGER.debug(
                                "get mi cashpay bill, merchantOrderId: {}, "
                                        + "tradeId: {}, tradeTypeValue: {}, tradeTime: {}, amount: {}",
                                merchantOrderId, tradeId, tradeTypeValue, time, amount);
                    }
                } else {
                    String responseCode = doc.getElementsByTagName("responseCode").item(0).getTextContent();
                    LOGGER.warn("error, query mi cashpay bill, responseCode: {}", responseCode);
                }
            } catch (ParserConfigurationException e) {
                LOGGER.error("parse error query mi cashpay bill", e);
                throw ServiceLogicException.ACCESS_GATEWAY_ERROR;
            } catch (Exception e) {
                LOGGER.error("io error query mi cashpay bill", e);
                throw ServiceLogicException.ACCESS_GATEWAY_ERROR;
            }

            return ret;

        }

        @Override
        public Map<String, String> createQueryNewBillRequest(String billDate, BillType billType) {
            return null;
        }

        @Override
        public List<TRBillDetail> parseQueryNewBillResponse(String response, String onestr, BillType twostr) throws PaymentGatewayResponseException, ServiceLogicException {
            return null;
        }

        @Override
        public Map<String, String> createRefundRequest(Map<RefundRequestParam, String> params)
                throws ServiceLogicException, PaymentGatewayResponseException {
            String orderId = params.get(RefundRequestParam.OUTER_ORDER_ID);
            String refundTransactionId = params.get(RefundRequestParam.OUTER_REQUEST_NO);
            String amount = params.get(RefundRequestParam.REFUND_AMOUNT);

            String requestIp = NetworkUtil.getLocalHostIp();
            String refundReason = "reason";
            String requestTime = new DateTime().toString("yyyy-MM-dd HH:mm:ss");
            return createRefundRequestMap(refundTransactionId, orderId, Long.valueOf(amount), refundReason, requestIp,
                    requestTime, notifyUrl);
        }

        @Override
        public long getTransactionIdFromReturnMap(Map<String, String> tpReturnParam) {
            return Long.parseLong(tpReturnParam.get("outOrderId"));
        }

        private Map<String, String> createWithdrawRequestMap(String userId, String amount, String transactionId,
                String description, String notifyUrl) {
            Map<String, String> params = new HashMap<>();

            params.put("service", "transfer");
            params.put("serviceVersion", SERVICE_VERSION);
            params.put("partnerId", merchantId);
            params.put("inputCharset", CHARSET);
            params.put("notifyUrl", notifyUrl);
            params.put("outTransferId", transactionId);
            params.put("benefitUserId", userId);
            params.put("needUserVerify", "false");
            params.put("transferAmount", amount);

            if (!StringUtils.isEmpty(description)) {
                params.put("transferDesc", description);
            }

            Date now = new Date();
            DateFormat df = PayCenterUtils.createOrderDateFormat();

            String requestIp = NetworkUtil.getLocalHostIp();
            LOGGER.debug("get request ip: {}", requestIp);

            params.put("requestIp", requestIp);
            params.put("requestTime", df.format(now));

            String sign = merchantSignature.sign(params);

            LOGGER.info("get query bill sign: {}", sign);

            params.put("sign", sign);
            params.put("signType", SIGN_TYPE);

            return params;
        }

        private String createPayRequestMap(String transactionId, String subject, String description, String amount,
                String notifyUrl, String returnUrl, String timeout, boolean allowCreditCard,String xiaomiId) {
            Map<String, String> params = new HashMap<>();
            // basic params
            params.put("service", "miCashPay");
            params.put("partnerId", payMerchantId);
            params.put("inputCharset", CHARSET);
            params.put("notifyUrl", notifyUrl);
            params.put("returnUrl", returnUrl);

            // business params
            params.put("outOrderId", transactionId);
            params.put("xiaomiId", xiaomiId);
            params.put("orderDesc", description);
            params.put("totalFee", amount);
            params.put("createTime", String.valueOf(System.currentTimeMillis() / 1000));
            params.put("productName", subject);
            params.put("expireTime", timeout);
            // 目前h5不针对这个参数作特别处理，余额和银行卡都会显示
            params.put("payMethod", "directPay");

            // cardType为借记卡时，信用卡不会显示，只支持余额支付和借记卡支付
            CardType cardType = CardType.DEBIT;
            if (allowCreditCard) {
                // cardType为信用卡时，支持余额支付、借记卡支付、信用卡支付
                cardType = CardType.CREDIT;
            }
            params.put("cardType", cardType == CardType.DEBIT ? "DEBIT_CARD" : "CREDIT_CARD");

            String sign = payMerchantSignature.sign(params);

            params.put("sign", sign);

            ArrayList<NameValuePair> nameValuePairs = new ArrayList<>();
            for (Map.Entry<String, String> entry : params.entrySet()) {
                nameValuePairs.add(new BasicNameValuePair(entry.getKey(), entry.getValue()));
            }
            return URLEncodedUtils.format(nameValuePairs, CHARSET);
        }

        private Map<String, String> createRefundRequestMap(String partnerRefundId, String outOrderId, long refundFee,
                String refundReason, String requestIp, String requestTime, String notifyUrl) {
            Map<String, String> params = new HashMap<>();
            // basic params
            params.put("service", "refundCashPayTrade");
            params.put("serviceVersion", "1.0.1");
            params.put("partnerId", payMerchantId);
            params.put("notifyUrl", notifyUrl);
            params.put("inputCharset", CHARSET);

            // business params
            params.put("partnerRefundId", partnerRefundId);
            params.put("outOrderId", outOrderId);
            params.put("refundFee", String.valueOf(refundFee));
            params.put("refundReason", refundReason);
            params.put("requestIp", requestIp);
            params.put("requestTime", requestTime);

            String sign = payMerchantSignature.sign(params);

            params.put("sign", sign);
            params.put("signType", "RSA");

            return params;
        }

        // 代扣
        private Map<String, String> createDeductRequestMap(String notifyUrl, long outOrderId, String orderDesc,
                String productName, long totalFee, long xiaomiId, String deductId, String cardType, long expireTime) {
            Map<String, String> params = new TreeMap<String, String>();
            params.put("service", "createDeductByMerchant");
            params.put("partnerId", payMerchantId);
            if (StringUtils.isNotEmpty(notifyUrl)) {
                params.put("notifyUrl", notifyUrl);
            }
            params.put("inputCharset", CHARSET);
            params.put("outOrderId", String.format("%020d", outOrderId));
            params.put("orderDesc", orderDesc);
            params.put("totalFee", String.valueOf(totalFee));
            params.put("createTime", String.valueOf(System.currentTimeMillis() / 1000));
            params.put("xiaomiId", String.valueOf(xiaomiId));
            params.put("payMethod", "bankPay");
            params.put("sellerId", payMerchantId);
            params.put("deductId", deductId);
            params.put("cardType", cardType);
            params.put("goodType", "ordinary");
            // params.put("expireTime", expireTime / 60 + "m");

            String sign = payMerchantSignature.sign(params);
            params.put("signType", SIGN_TYPE);
            params.put("sign", sign);
            return params;
        }

        @Override
        public Map<String, String> createDeductRequset(CommitDeductRequest params) {
            Map<String, String> result = createDeductRequestMap(params.getNotifyURL(), params.getTransactionId(),
                    params.getOrderDesc(), params.getProductName(), params.getTotalFee(), params.getXiaomiId(),
                    params.getDeductId(), params.getCardType().toString(), params.getExpireTime());

            LOGGER.info("create deduct request [params: {}, result: {}]", params, result);
            return result;
        }

        public CommitBindDeductResult createDeductSign(CommitBindDeductRequest params) {
            CommitBindDeductResult result = new CommitBindDeductResult();
            
            try { 
                String signedUrl = createDeductSignUrl(params.getReturnUrl(), params.getProductName(),
                        params.getBankList(), params.getExtraInfo());
                result.setSignedUrl(signedUrl);
                result.setResponse(ResponseUtils.getSuccessResponse());
            } catch (Exception e) {
                result.setResponse(ResponseUtils.getResponse(ServiceLogicException.INTERNAL_SERVICE_ERROR));
            }
            LOGGER.info("create deduct sign [params:{}, result:{}]", params, result);
            return result;
        }

        private String createDeductSignUrl(String returnUrl, String productName,
                String bankList, String extraInfo) {
            Map<String, String> params = new HashMap<String, String>();
            params.put("partnerId", payMerchantId);
            params.put("returnUrl", returnUrl);
            params.put("productName", productName);
            params.put("showInstructPage", "0"); // 跳过引导页
            params.put("showSuccessPage", "0"); // 跳过结果确认页

            if (StringUtils.isNotEmpty(bankList)) {
                params.put("bankList", bankList);
            }
            if (StringUtils.isNotEmpty(extraInfo)) {
                params.put("extraInfo", extraInfo);
            }
            String sign = payMerchantSignature.sign(params);
            params.put("signature", sign);
            
            try {
                URIBuilder builder = new URIBuilder(deductSignPageUrl);
                for (Map.Entry<String, String> entry : params.entrySet()) {
                    builder.addParameter(entry.getKey(), entry.getValue());
                }
                return builder.toString();
            } catch (URISyntaxException e) {
                LOGGER.info("create deduct sign url exception ", e);
                throw new RuntimeException(e);
            }
        }
    }
}
