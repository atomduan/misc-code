package com.xiaomi.mifi.payment.dao;

import java.util.List;

import com.xiaomi.mifi.insurance.payment.thrift.DeductTradeDetail;
import com.xiaomi.mifi.insurance.payment.thrift.RefundDetail;
import com.xiaomi.mifi.insurance.payment.thrift.TradeDetail;

import net.paoding.rose.jade.annotation.DAO;
import net.paoding.rose.jade.annotation.SQL;

@DAO
public interface StatDAO {

    /**
     * 查询没有成功通知的支付订单
     * 
     * @param time
     * @return
     */
    @SQL("SELECT " + TradeDetailDAO.SELECT_COLUMNS + " FROM `" + TradeDetailDAO.TABLE_NAME + "` WHERE `payment_status`=3 AND"
            + " `transaction_id` IN (SELECT `transaction_id` FROM notify WHERE notify_status != 1) AND `create_time`>=:1")
    List<TradeDetail> findTradeNoNotify(long time);

    /**
     * 查询没有成功通知的代扣订单
     * 
     * @param time
     * @return
     */
    @SQL("SELECT " + DeductTradeDetailDAO.SELECT_COLUMNS + " FROM `" + DeductTradeDetailDAO.TABLE_NAME + "` WHERE `payment_status`=3 AND"
            + " `transaction_id` IN (SELECT `transaction_id` FROM `notify` WHERE notify_status != 1) AND `create_time`>=:1")
    List<DeductTradeDetail> findDeductTradeNoNotify(long time);

    /**
     * 查询没有成功通知的退款订单
     * 
     * @param time
     * @return
     */
    @SQL("SELECT " + RefundDetailDAO.SELECT_COLUMNS + " FROM `" + RefundDetailDAO.TABLE_NAME + "` WHERE `payment_status`=3 AND " +
    " `origin_transaction_id` IN (SELECT `transaction_id` FROM `notify` WHERE `notify_status` != 1) AND `create_time`>=:1")
    List<RefundDetail> findRefundNoNotify(long time);
}