package com.xiaomi.mifi.payment.gateway;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.xiaomi.mifi.insurance.common.util.exception.ServiceLogicException;
import com.xiaomi.mifi.insurance.common.util.http.HttpRequester;
import com.xiaomi.mifi.insurance.payment.thrift.BillType;
import com.xiaomi.mifi.insurance.payment.thrift.PaymentRequestParam;
import com.xiaomi.mifi.insurance.payment.thrift.PaymentResponseParam;
import com.xiaomi.mifi.insurance.payment.thrift.RefundRequestParam;
import com.xiaomi.mifi.insurance.payment.thrift.TRBillDetail;
import com.xiaomi.mifi.payment.exception.PaymentGatewayResponseException;
import com.xiaomi.mifi.payment.model.CommitDeductRequest;

public abstract class AbstractPaymentGateway implements PaymentGateway {

    private static final Logger LOGGER = LoggerFactory.getLogger(AbstractPaymentGateway.class);

    private GatewayDataAdapter adapter;

    @Override
    public Map<PaymentResponseParam, String> applyWithdraw(Map<PaymentRequestParam, String> params)
            throws ServiceLogicException, PaymentGatewayResponseException {
        String withdrawUrl = adapter.getWithdrawUrl();
        Map<String, String> requestParams = adapter.createWithdrawRequest(params);
        String transactionId = adapter.getTransactionId(params);

        HttpRequester httpRequester = getHttpRequester();
        HttpRequester.HttpResult post;
        try {
            post = httpRequester.post(withdrawUrl, null, requestParams);
        } catch (IOException e) {
            LOGGER.error("error when send withdraw request, transaction id: {}", transactionId, e);
            throw ServiceLogicException.ACCESS_GATEWAY_ERROR;
        }

        String response;
        try {
            response = post.getString();
        } catch (IOException e) {
            LOGGER.error("IOException when get withdraw response content", e);
            throw ServiceLogicException.ACCESS_GATEWAY_ERROR;
        }

        LOGGER.debug("get response for withdraw request, transaction id: {}, response: {}", transactionId, response);
        return adapter.parseWithdrawResponse(response);
    }

    @Override
    public String createPayRequest(Map<PaymentRequestParam, String> params)
            throws ServiceLogicException, PaymentGatewayResponseException {
        LOGGER.info("AbstractPaymentGateway.createPayRequest, params: {} ", params);
        return adapter.createPayRequest(params);
    }

    @Override
    public List<TRBillDetail> queryBill(String billDate, BillType billType)
            throws ServiceLogicException, PaymentGatewayResponseException {
        return queryBill(billDate, billType, true);
    }

    @Override
    public String createRefundRequest(Map<RefundRequestParam, String> params)
            throws ServiceLogicException, PaymentGatewayResponseException {
        Map<String, String> request = adapter.createRefundRequest(params);
        LOGGER.info("AbstractPaymentGateway.createRefundRequest params:{}", request);
        return adapter.sendRequest(request);
    }

    @Override
    public long getTransactionIdFromReturnMap(Map<String, String> param) {
        LOGGER.debug("getTransactionIdFromReturnMap param:{}", param);
        return adapter.getTransactionIdFromReturnMap(param);
    }

    protected List<TRBillDetail> queryBill(String billDate, BillType billType, boolean isBackfee)
            throws ServiceLogicException, PaymentGatewayResponseException {
        LOGGER.info("when send query bill request, bill data: {}, trade type: {}", billDate, billType);
        String queryBillUrl = adapter.getQueryBillUrl();
        Map<String, String> requestParams = adapter.createQueryBillRequest(billDate, billType, isBackfee);

        HttpRequester httpRequester = getHttpRequester();
        String response = "";
        try {
            response = httpRequester.postString(queryBillUrl, null, requestParams);
        } catch (IOException e) {
            LOGGER.error("error when send query bill request, bill data: {}, trade type: {}", billDate, billType, e);
            throw ServiceLogicException.ACCESS_GATEWAY_ERROR;
        }

        LOGGER.debug("get response for query bill request, response: {}", response);

        return adapter.parseQueryBillResponse(response);
    }

    @Override
    public Map<String, String> commitDeduct(CommitDeductRequest params) {
        return new HashMap<String, String>();
    }

    @Override
    public Map<String, String> createDeductSign(Map<String, String> params) {
        return null;
    }

    abstract HttpRequester getHttpRequester();

    GatewayDataAdapter getAdapter() {
        return adapter;
    }

    void setAdapter(GatewayDataAdapter adapter) {
        this.adapter = adapter;
    }

}
