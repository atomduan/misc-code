package com.xiaomi.mifi.payment.util;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.security.KeyStore;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.net.ssl.SSLContext;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.Unmarshaller;

import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.SSLContexts;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import com.mifi.insurance.payment.util.ErrorCode;
import com.mysql.jdbc.StringUtils;
import com.xiaomi.common.perfcounter.PerfCounter;

public class WeixinPayUtils {

    private static Logger LOGGER = LoggerFactory.getLogger(WeixinPayUtils.class);
    private static KeyStore keyStore = null;
    private static String mchId = "";
    static {
        init();
        try {
            keyStore = KeyStore.getInstance("PKCS12");
            String certPath = System.getProperty("weixin.cert.local.path"); // "/home/work/data/mifi_insurance_payment/weixin/pkcs12.cert";
            mchId = System.getProperty("weixin.mchid");// "";
            File file = new File(certPath);
            if (file.exists()) {
                FileInputStream instream = new FileInputStream(file);
                try {
                    keyStore.load(instream, mchId.toCharArray());
                } finally {
                    instream.close();
                }
            } else {
                LOGGER.warn("Cound not find file certPath : {}", certPath);
            }
        } catch (Exception e) {
            LOGGER.warn("init key store failed", e);
        }
    }

    private static void init() {
        Properties properties = System.getProperties();
        try {
            Resource res = new ClassPathResource("config.properties");
            properties.load(res.getInputStream());
            System.setProperties(properties);
        } catch (IOException e) {
            LOGGER.error("init config.properties fail:", e);
        }
    }

    public static String generateXmlString(Map<String, String> params) {
        Element root = DocumentHelper.createElement("xml");
        Document document = DocumentHelper.createDocument(root);
        document.setXMLEncoding(CommonUtils.CHARSET_UTF8);
        for (String key : params.keySet()) {
            String value = params.get(key);
            if (StringUtils.isNullOrEmpty(value)) {
                continue;
            }
            if (value.contains("<") || value.contains(">") || value.contains("&")) {
                root.addElement(key).addCDATA(value);
            } else {
                root.addElement(key).addText(value);
            }
        }
        String xmlString = document.asXML();
        LOGGER.info("generated xmlString:{}", xmlString);
        return xmlString;
    }

    public static Object xmlDataToObject(Class<?> targetClass, String response, String encoding) {
        try{
            JAXBContext jaxbContext = JAXBContext.newInstance(targetClass);
            Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
            ByteArrayInputStream is = new ByteArrayInputStream(response.getBytes(encoding));
            return unmarshaller.unmarshal(is);
        } catch (Exception e) {
            PerfCounter.count("JAXB_UNMARSHAL_ERROR", 1);
            LOGGER.info("JAXB UNMARSHAL ERROR: response {}, {}", response, e);
            return null;
        }
    }

    public static Map<String, String> xmlDataToMap(String xmlStr) {
        Map<String, String> result = new HashMap<String, String>();
        try {
            Document document = DocumentHelper.parseText(xmlStr);
            List<Element> elements = document.getRootElement().elements();
            for (Element ele : elements) {
                result.put(ele.getName(), ele.getText());
            }
        } catch (DocumentException e) {
            LOGGER.error("parse xml error: xmlStr:{}, exception: {}", xmlStr, e);
        }
        return result;
    }

    public static String sendHttpPostString(String url, String mchid, String xmlParams) throws Exception {
        mchid = mchid == null ? mchId : mchid;
        SSLContext sslcontext = SSLContexts.custom().loadKeyMaterial(keyStore, mchid.toCharArray()).build();
        SSLConnectionSocketFactory sslsf = new SSLConnectionSocketFactory(sslcontext, new String[] { "TLSv1" }, null,
                SSLConnectionSocketFactory.BROWSER_COMPATIBLE_HOSTNAME_VERIFIER);
        CloseableHttpClient httpclient = HttpClients.custom().setSSLSocketFactory(sslsf).build();
        try {
            LOGGER.info("request url {}, mchid {}, xmlParams {}", url, mchid, xmlParams);
            HttpPost httpPost = new HttpPost(url);
            StringEntity postEntity = new StringEntity(xmlParams, CommonUtils.CHARSET_UTF8);
            httpPost.setEntity(postEntity);
            CloseableHttpResponse response = httpclient.execute(httpPost);
            try {
                HttpEntity entity = response.getEntity();
                String responseString = EntityUtils.toString(entity, CommonUtils.CHARSET_UTF8);
                LOGGER.info("response {}", responseString);
                EntityUtils.consume(entity);
                return responseString;
            } finally {
                response.close();
            }
        } finally {
            httpclient.close();
        }
    }

    public static Map<String, String> sendHttpPost(String url, String mchid, String xmlParams) throws Exception {
        return xmlDataToMap(sendHttpPostString(url, mchid, xmlParams));
    }

    public static String getFailResponse(ErrorCode error) {
        Map<String, String> params = new HashMap<String, String>();
        params.put("return_code", "FAIL");
        params.put("return_msg", error.externalDescription);
        return generateXmlString(params);
    }

    public static String getSuccessResponse() {
        Map<String, String> params = new HashMap<String, String>();
        params.put("return_code", "SUCCESS");
        params.put("return_msg", "OK");
        return generateXmlString(params);
    }
}
