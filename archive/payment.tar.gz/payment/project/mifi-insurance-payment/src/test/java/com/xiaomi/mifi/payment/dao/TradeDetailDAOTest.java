package com.xiaomi.mifi.payment.dao;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.xiaomi.mifi.payment.thrift.Channel;
import com.xiaomi.mifi.payment.thrift.Currency;
import com.xiaomi.mifi.payment.thrift.PayMethod;
import com.xiaomi.mifi.payment.thrift.PaymentStatus;
import com.xiaomi.mifi.payment.thrift.TradeDetail;
import com.xiaomi.mifi.payment.thrift.TradeStatus;
import com.xiaomi.mifi.payment.util.CommonUtils;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:applicationContext.xml")
public class TradeDetailDAOTest extends BaseDAOTest {

    private static Logger LOGGER = LoggerFactory.getLogger(TradeDetailDAOTest.class);

    @Autowired
    TradeDetailDAO dao;

    private static final long NOW_TIMESTAMP = System.currentTimeMillis();

    @Override
    @Before
    public void setUp() throws Exception {
        super.setUp();
        initDBData();
    }

    @Test
    public void testInsert() {
        TradeDetail tradeDetail = new TradeDetail();
        tradeDetail.setChannel(Channel.ALIPAY.getValue());
        tradeDetail.setCurrency(Currency.CNY.getValue());
        tradeDetail.setCreateTime(System.currentTimeMillis());
        tradeDetail.setUpdateTime(System.currentTimeMillis());
        tradeDetail.setExpireTime(System.currentTimeMillis());
        tradeDetail.setReceiveTime(System.currentTimeMillis());
        tradeDetail.setOrderDesc("test order desc");
        tradeDetail.setNotifyId(12345L);
        tradeDetail.setPaymentStatus(PaymentStatus.COMMIT.getValue());
        tradeDetail.setTradeStatus(TradeStatus.INIT.getValue());
        tradeDetail.setOrderId(123213L);
        tradeDetail.setTransactionId(88888L);
        tradeDetail.setProductName("test product");
        tradeDetail.setReturnUrl("test return url");
        tradeDetail.setXiaomiId("101010101010");
        tradeDetail.setPayMethod(PayMethod.DIRECT_PAY.getValue());
        long id = dao.insert(tradeDetail);
        Assert.assertEquals(4, id);
    }

    @Test
    public void testFind() {
        testInsert();
        TradeDetail tradeDetail = dao.findByTransactionId(1L);
        Assert.assertNull(tradeDetail);
        tradeDetail = dao.findByTransactionId(88888888L);
        Assert.assertNotNull(tradeDetail);
    }

    @Test
    public void testUpdate() {
        testInsert();
        TradeDetail tradeDetail = dao.findByOrderId(11111L);
        Assert.assertNotNull(tradeDetail);
        Assert.assertEquals(0L, tradeDetail.getPayTime());
        tradeDetail.setPayTime(12345678L);
        tradeDetail.setTradeStatus(TradeStatus.SUCCESS.getValue());
        int ret = dao.updateTradeDetail(tradeDetail);
        Assert.assertEquals(1, ret);
        tradeDetail = dao.findByOrderId(11111L);
        Assert.assertNotNull(tradeDetail);
        Assert.assertEquals(12345678L, tradeDetail.getPayTime());
        Assert.assertEquals(TradeStatus.SUCCESS.getValue(), tradeDetail.getTradeStatus());
    }

    @Test
    public void testFindList() {
        List<TradeDetail> list = dao.findByTimeSpanAndTradeStatus(NOW_TIMESTAMP - 1000 * 5,
                NOW_TIMESTAMP + 1000 * 5, TradeStatus.INIT.getValue(), 0, 30);
        Assert.assertNotNull(list);
        Assert.assertEquals(3, list.size());
        Assert.assertEquals(11111L, list.get(0).getOrderId());
        Assert.assertEquals(222222L, list.get(1).getOrderId());
        Assert.assertEquals(3333333L, list.get(2).getOrderId());
    }

    @Test
    public void testFindList2() {
        List<TradeDetail> list = dao.findByTimeSpanAndTradeStatus(NOW_TIMESTAMP - 1000 * 5,
                NOW_TIMESTAMP + 1000 * 5, TradeStatus.INIT.getValue(), 0, 2);
        Assert.assertNotNull(list);
        Assert.assertEquals(2, list.size());
        Assert.assertEquals(11111L, list.get(0).getOrderId());
        Assert.assertEquals(222222L, list.get(1).getOrderId());
        list = dao.findByTimeSpanAndTradeStatus(NOW_TIMESTAMP - 1000 * 5,
                NOW_TIMESTAMP + 1000 * 5, TradeStatus.INIT.getValue(), 2, 2);
        Assert.assertNotNull(list);
        Assert.assertEquals(1, list.size());
        Assert.assertEquals(3333333L, list.get(0).getOrderId());
    }

    @Test
    public void testFindList3() {
        List<TradeDetail> list = dao.findByTimeSpanAndTradeStatus(NOW_TIMESTAMP - 60 * 1000,
                NOW_TIMESTAMP + 60 * 1000, -1, 0, 30);
        Assert.assertNotNull(list);
        Assert.assertEquals(3, list.size());

        TradeDetail tradeDetail3 = new TradeDetail();
        tradeDetail3.setChannel(Channel.CASHPAY.getValue());
        tradeDetail3.setCurrency(Currency.CNY.getValue());
        tradeDetail3.setCreateTime(System.currentTimeMillis());
        tradeDetail3.setUpdateTime(System.currentTimeMillis());
        tradeDetail3.setExpireTime(System.currentTimeMillis() + CommonUtils.TIME_SPAN_ONE_HOUR);
        tradeDetail3.setOrderDesc("test order desc");
        tradeDetail3.setNotifyId(543210L);
        tradeDetail3.setPayTime(System.currentTimeMillis());
        tradeDetail3.setPaymentStatus(PaymentStatus.SUCCESS.getValue());
        tradeDetail3.setTradeStatus(TradeStatus.INIT.getValue());
        tradeDetail3.setOrderId(222221L);
        tradeDetail3.setTransactionId(999999991L);
        tradeDetail3.setProductName("test product 3");
        tradeDetail3.setReturnUrl("test return url 3");
        dao.insert(tradeDetail3);

        List<TradeDetail> list3 = dao.findByPayTime(System.currentTimeMillis() - 600 * 1000, System.currentTimeMillis(),
                Channel.CASHPAY.getValue());
        Assert.assertNotNull(list3);
        Assert.assertEquals(1, list3.size());
    }

    @Test
    public void testFindListByPayTime() {
        TradeDetail tradeDetail = new TradeDetail();
        tradeDetail.setChannel(Channel.ALIPAY.getValue());
        tradeDetail.setCurrency(Currency.CNY.getValue());
        tradeDetail.setCreateTime(System.currentTimeMillis());
        tradeDetail.setUpdateTime(System.currentTimeMillis());
        tradeDetail.setPayTime(System.currentTimeMillis());
        tradeDetail.setExpireTime(System.currentTimeMillis() + CommonUtils.TIME_SPAN_ONE_HOUR);
        tradeDetail.setOrderDesc("test order desc");
        tradeDetail.setNotifyId(1234567L);
        tradeDetail.setPaymentStatus(PaymentStatus.SUCCESS.getValue());
        long id = 0;
        try {
            id = dao.insert(tradeDetail);
        } catch (Exception e) {
            LOGGER.error("TradeDetailDAOTest.testFindListByPayTime", e);
        }
        List<TradeDetail> list = dao.findListByPayTime(NOW_TIMESTAMP - 10000000, NOW_TIMESTAMP + 100000000, 0, 10);
        Assert.assertNotNull(list);
        Assert.assertEquals(1, list.size());
    }

    @Test
    public void testFindListByPayTimeCount() {
        TradeDetail tradeDetail = new TradeDetail();
        tradeDetail.setChannel(Channel.ALIPAY.getValue());
        tradeDetail.setCurrency(Currency.CNY.getValue());
        tradeDetail.setCreateTime(System.currentTimeMillis());
        tradeDetail.setUpdateTime(System.currentTimeMillis());
        tradeDetail.setExpireTime(System.currentTimeMillis() + CommonUtils.TIME_SPAN_ONE_HOUR);
        tradeDetail.setPayTime(System.currentTimeMillis());
        tradeDetail.setOrderDesc("test order desc");
        tradeDetail.setNotifyId(1234568L);
        tradeDetail.setPaymentStatus(PaymentStatus.SUCCESS.getValue());
        try {
            long id = dao.insert(tradeDetail);
        } catch (Exception e) {
            LOGGER.error("TradeDetailDAOTest.testFindListByPayTimeCount", e);
        }
        int num = dao.findListByPayTimeCount(NOW_TIMESTAMP - 10000000, NOW_TIMESTAMP + 100000000);
        Assert.assertNotNull(num);
        Assert.assertEquals(1, num);
    }

    @Test
    public void testExpiredTrades() {
        List<Integer> statusList = new ArrayList<>();
        statusList.add(0);
        statusList.add(1);

        List<Long> list = dao.queryExpiredTrades(NOW_TIMESTAMP - 1500, NOW_TIMESTAMP + 2000, 0, 2, statusList);
        Assert.assertEquals(2, list.size());
        Assert.assertEquals(88888888L, list.get(0).longValue());
        Assert.assertEquals(99999999L, list.get(1).longValue());

        list = dao.queryExpiredTrades(NOW_TIMESTAMP - 1500, NOW_TIMESTAMP + 2000, 2, 2, statusList);
        Assert.assertEquals(1, list.size());
        Assert.assertEquals(66666666L, list.get(0).longValue());

        list = dao.queryExpiredTrades(NOW_TIMESTAMP - 900, NOW_TIMESTAMP + 900, 0, 2, statusList);
        Assert.assertEquals(0, list.size());

        list = dao.queryExpiredTrades(NOW_TIMESTAMP - 900, NOW_TIMESTAMP + 1800, 0, 2, statusList);
        Assert.assertEquals(2, list.size());
        Assert.assertEquals(99999999L, list.get(0).longValue());
        Assert.assertEquals(66666666L, list.get(1).longValue());
    }

    private void initDBData() {
        TradeDetail tradeDetail = new TradeDetail();
        tradeDetail.setChannel(Channel.ALIPAY.getValue());
        tradeDetail.setCurrency(Currency.CNY.getValue());
        tradeDetail.setCreateTime(NOW_TIMESTAMP - 1000);
        tradeDetail.setUpdateTime(NOW_TIMESTAMP - 1000);
        tradeDetail.setExpireTime(NOW_TIMESTAMP + 1000);
        tradeDetail.setReceiveTime(NOW_TIMESTAMP);
        tradeDetail.setOrderDesc("test order desc");
        tradeDetail.setNotifyId(12345L);
        tradeDetail.setPaymentStatus(PaymentStatus.COMMIT.getValue());
        tradeDetail.setTradeStatus(TradeStatus.INIT.getValue());
        tradeDetail.setOrderId(11111L);
        tradeDetail.setTransactionId(88888888L);
        tradeDetail.setProductName("test product");
        tradeDetail.setReturnUrl("test return url");
        tradeDetail.setXiaomiId("101010101010");
        tradeDetail.setPayMethod(PayMethod.DIRECT_PAY.getValue());
        dao.insert(tradeDetail);

        tradeDetail = new TradeDetail();
        tradeDetail.setChannel(Channel.ALIPAY.getValue());
        tradeDetail.setCurrency(Currency.CNY.getValue());
        tradeDetail.setCreateTime(NOW_TIMESTAMP - 500);
        tradeDetail.setUpdateTime(NOW_TIMESTAMP - 500);
        tradeDetail.setExpireTime(NOW_TIMESTAMP + 1000);
        tradeDetail.setReceiveTime(NOW_TIMESTAMP);
        tradeDetail.setOrderDesc("test order desc");
        tradeDetail.setNotifyId(12345L);
        tradeDetail.setPaymentStatus(PaymentStatus.COMMIT.getValue());
        tradeDetail.setTradeStatus(TradeStatus.INIT.getValue());
        tradeDetail.setOrderId(222222L);
        tradeDetail.setTransactionId(99999999L);
        tradeDetail.setProductName("test product");
        tradeDetail.setReturnUrl("test return url");
        tradeDetail.setXiaomiId("101010101010");
        tradeDetail.setPayMethod(PayMethod.DIRECT_PAY.getValue());
        dao.insert(tradeDetail);

        tradeDetail = new TradeDetail();
        tradeDetail.setChannel(Channel.ALIPAY.getValue());
        tradeDetail.setCurrency(Currency.CNY.getValue());
        tradeDetail.setCreateTime(NOW_TIMESTAMP - 300);
        tradeDetail.setUpdateTime(NOW_TIMESTAMP - 300);
        tradeDetail.setExpireTime(NOW_TIMESTAMP + 1000);
        tradeDetail.setReceiveTime(NOW_TIMESTAMP);
        tradeDetail.setOrderDesc("test order desc");
        tradeDetail.setNotifyId(12345L);
        tradeDetail.setPaymentStatus(PaymentStatus.COMMIT.getValue());
        tradeDetail.setTradeStatus(TradeStatus.INIT.getValue());
        tradeDetail.setOrderId(3333333L);
        tradeDetail.setTransactionId(66666666L);
        tradeDetail.setProductName("test product");
        tradeDetail.setReturnUrl("test return url");
        tradeDetail.setXiaomiId("101010101010");
        tradeDetail.setPayMethod(PayMethod.DIRECT_PAY.getValue());
        dao.insert(tradeDetail);
    }

    @Test
    public void testFindTradeDetails() {
        List<TradeDetail> list = dao.findByTimeSpanAndTradeStatus(System.currentTimeMillis() + 24 * 60 * 60 * 1000L,
                System.currentTimeMillis() + 2* 24 * 60 * 60 * 1000L, -1, 0, 30);
        Assert.assertNotNull(list);
        Assert.assertEquals(0, list.size());
    }
}
