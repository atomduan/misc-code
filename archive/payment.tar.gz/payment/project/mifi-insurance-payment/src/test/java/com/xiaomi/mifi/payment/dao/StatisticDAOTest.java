package com.xiaomi.mifi.payment.dao;

import com.xiaomi.mifi.insurance.payment.thrift.PaymentStatistic;
import com.xiaomi.mifi.payment.thrift.Channel;
import com.xiaomi.mifi.payment.thrift.TradeStatus;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.List;

/**
 * Created by mars on 17-5-26.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:applicationContext.xml")
public class StatisticDAOTest extends BaseDAOTest {
    private static final Logger LOGGER = LoggerFactory.getLogger(StatisticDAOTest.class);

    @Autowired
    private DailyStatisticDAO dao;

    @Override
    @Before
    public void setUp() throws Exception {
        super.setUp();
        PaymentStatistic paymentStatistic = new PaymentStatistic();
        paymentStatistic.setDate("2017-5-25");
        paymentStatistic.setChannel(Channel.ALIPAY.getValue());
        paymentStatistic.setResultType(TradeStatus.SUCCESS.getValue());
        paymentStatistic.setType(1);
        paymentStatistic.setCount(8);
        dao.insert(paymentStatistic);
        PaymentStatistic paymentStatistic2 = new PaymentStatistic();
        paymentStatistic2.setDate("2017-5-24");
        paymentStatistic2.setChannel(Channel.CASHPAY.getValue());
        paymentStatistic2.setResultType(TradeStatus.FAIL.getValue());
        paymentStatistic2.setCount(5);
        paymentStatistic2.setType(2);
        dao.insert(paymentStatistic2);
    }

    @Test
    public void testInsert() {
        PaymentStatistic paymentStatistic = new PaymentStatistic();
        paymentStatistic.setDate("2017-5-26");
        paymentStatistic.setChannel(Channel.ALIPAY.getValue());
        paymentStatistic.setResultType(TradeStatus.SUCCESS.getValue());
        paymentStatistic.setChannel(9);
        paymentStatistic.setType(2);
        Assert.assertTrue(dao.insert(paymentStatistic) > 0);
        PaymentStatistic paymentStatistic2 = new PaymentStatistic();
        paymentStatistic2.setDate("2017-5-26");
        paymentStatistic2.setChannel(1024);
        paymentStatistic2.setResultType(1024);
        paymentStatistic2.setChannel(9);
        paymentStatistic2.setType(2);
        Assert.assertTrue(dao.insert(paymentStatistic2) > 0);
    }

    @Test
    public void testQuery() {
        List<PaymentStatistic> paymentStatistics;
        paymentStatistics = dao.queryByDate("2017-5-25");
        Assert.assertEquals(1, paymentStatistics.size());
        Assert.assertEquals(8, paymentStatistics.get(0).getCount());
        Assert.assertEquals(1, paymentStatistics.get(0).getChannel());
        Assert.assertEquals(2, paymentStatistics.get(0).getResultType());
        Assert.assertEquals("2017-5-25", paymentStatistics.get(0).getDate());
    }

    @Test
    public void testQueryAll() {
        List<PaymentStatistic> list = dao.queryAll(0, 2);
        Assert.assertEquals(2, list.size());
        Assert.assertEquals(1, list.get(0).getType());
        Assert.assertEquals(8, list.get(0).getCount());
        Assert.assertEquals(1, list.get(0).getChannel());
        Assert.assertEquals(2, list.get(0).getResultType());
        Assert.assertEquals("2017-5-25", list.get(0).getDate());
        Assert.assertEquals(2, list.get(1).getType());
        Assert.assertEquals(5, list.get(1).getCount());
        Assert.assertEquals(4, list.get(1).getChannel());
        Assert.assertEquals(5, list.get(1).getResultType());
        Assert.assertEquals("2017-5-24", list.get(1).getDate());
        list = dao.queryAll(0, 1);
        Assert.assertEquals(1, list.size());
        Assert.assertEquals(1, list.get(0).getType());
        Assert.assertEquals(8, list.get(0).getCount());
        Assert.assertEquals(1, list.get(0).getChannel());
        Assert.assertEquals(2, list.get(0).getResultType());
        Assert.assertEquals("2017-5-25", list.get(0).getDate());
        list = dao.queryAll(1, 2);
        Assert.assertEquals(1, list.size());
        Assert.assertEquals(2, list.get(0).getType());
        Assert.assertEquals(5, list.get(0).getCount());
        Assert.assertEquals(4, list.get(0).getChannel());
        Assert.assertEquals(5, list.get(0).getResultType());
        Assert.assertEquals("2017-5-24", list.get(0).getDate());
    }
}
