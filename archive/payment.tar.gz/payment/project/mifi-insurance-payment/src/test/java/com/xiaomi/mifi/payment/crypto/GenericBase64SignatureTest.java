package com.xiaomi.mifi.payment.crypto;

import org.junit.Assert;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;

public class GenericBase64SignatureTest {

    private static final Logger LOGGER = LoggerFactory.getLogger(GenericBase64SignatureTest.class);

    @Test
    public void sign() throws Exception {
        GenericBase64Signature signature = new GenericBase64Signature();
        signature.setPrivateKeyContent("MIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQCuKxruLevo0B2fioty4NShdbisbEpjIqfNK5CxQr9h+kvZ1uHXRckfXA+RszQ4qcozOuCoeDRLhBGD5UHgrupqk2p0CrFU++lUz6GWErY0XKJfWSS+5+1d7HgkVAOVLxB+iUySiGTa0rbicwWdbO1RVsGlFmcLEohBa0hz2R79Z82c6pFcmDUqUYo1Fp6ldCyNBBkSWHh47PY7jXDUlBJPdFAsQXLFSmH1vcpSu4/OOOvfynFbPocSV8AB9/ipWTissJRLNGollqkI2XuoI6R12JnmrAtjcQ+AsGmTK+xtq5yH83s1yDnKGnogILiJYkSvO5c/GAF5qY5LePFEw7C9AgMBAAECggEATBHnoT/NWdIMHjKU1Yf9Vsfj8OsbUlFAmQv+Fm3gyRpZJrwDx9JjFZ9P7YMnu9fsyJNerDZUIOd9/u2S6F99Yy8fv68r5MJiFvjYyoNBsX0ELkDxG7CQrAUsNDG9ntr/iUTOfPG1mx2NYzp5qVh6Dpyl10UBnIRrnqcM7gxWzLZgnCx9BlFnadhyFHlK0y3mmY9yXi0jz4KUUwu0PRtj6iYt5FpHHW80McGEmCvF1AhQ+jARYOSxOPnh9SlZTnUUaroFxpahTYP3sfbOeLPGHmJsNKlm/rhZoNI79L60R3Kydjg22jn9kFyH5OWwWIkVOIYhNnbJCyKGtapxt5MaAQKBgQDmnoyUqfLmwx7TD7/MOmkU7i0WGEcxL9tBLpptyzKqPprMKIh1igpayjQWxvm8jZ1wrfE7TIfNcMLuQlgNe49zofzZnhBvQaZDAR9uY/9mjo98YTFTKfe/FIUegIMwSbNi1BcO+tGqqBzion+srXjn4+ASZEE1Y55v9w8sc7gWKQKBgQDBVhyCd9jXY584GoFT88QHYkGDEdNxYsT5HUMUs6s8OosrfJD2b9pqLzUTDEEy/F3no7594igJ7eVI9OYMvJz0aJZjz6i0BTvDj/fdno8Ao4ZEGBp0UvNxrppdeE43k/OzZevCo48sclIWjD8fDMQtajyF4xEvYMePciq9gCcQdQKBgHZwkw5+wcsWBqyq9/vxO6qOMAWa7mUqiNZPEuy0YQ7iHCoh3wNOo8bA9kOEaRoXOPZ3vt6PjWdLNDGdTQ+Pl7rxRKSW8yXQd40N9JCDNtX6/WIJoIVvlldCOKPTqIySLVjiR/1ff3K/6CXVAvEyHlgpxhhr+LlssiAaqGZSAAcRAoGBAL5qdGvfY/dHjBJysHuh86keEc3oqarcD4oXUvE5v+Xy9wzeg9vj8GdylUBsam6v9kDlmgFb0/lrj86aPVXAEon51Fz7snmTSfhjfEmPF+MWK3A3mR6GcHS/9hMnIUpF8tj3AgvSkXnCIq1Idga7yR+9qVxodo2GMSZL2GKJrG/dAoGAfSnRxxDtz6qMgRH1WkMrwDEzFe8Ii1qlRll9XJdyo/4IK1h7N3cYztLvWfD/rFruEa8urJCY9WPGuKU1SZqGTIBd1dUglhhYBV97OZMgu4dxmD/3uchfh7BpLyc65MJErzc7Jmu3BWYTV4EaJdZiz+L29LDN6Wvw0ZnfhyCYp8I=");
        signature.setPublicKeyContent("MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEArisa7i3r6NAdn4qLcuDUoXW4rGxKYyKnzSuQsUK/YfpL2dbh10XJH1wPkbM0OKnKMzrgqHg0S4QRg+VB4K7qapNqdAqxVPvpVM+hlhK2NFyiX1kkvuftXex4JFQDlS8QfolMkohk2tK24nMFnWztUVbBpRZnCxKIQWtIc9ke/WfNnOqRXJg1KlGKNRaepXQsjQQZElh4eOz2O41w1JQST3RQLEFyxUph9b3KUruPzjjr38pxWz6HElfAAff4qVk4rLCUSzRqJZapCNl7qCOkddiZ5qwLY3EPgLBpkyvsbauch/N7Ncg5yhp6ICC4iWJErzuXPxgBeamOS3jxRMOwvQIDAQAB");
        signature.init();

        String id = "slfksdjf09823012";
        HashMap<String, String> param = new HashMap<>();
        param.put("id", id);

        String sign = signature.sign(param);

        LOGGER.info("get sign: {}", sign);
        Assert.assertNotNull(sign);

        boolean verify = signature.verify(param, sign);
        Assert.assertTrue(verify);
    }
}