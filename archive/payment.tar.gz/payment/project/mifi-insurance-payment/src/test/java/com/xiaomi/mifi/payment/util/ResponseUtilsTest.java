package com.xiaomi.mifi.payment.util;

import org.junit.Assert;
import org.junit.Test;

import com.xiaomi.mifi.common.thrift.model.TRResponse;
import com.xiaomi.mifi.insurance.common.util.exception.ErrorCode;
import com.xiaomi.mifi.insurance.common.util.exception.ServiceLogicException;
import com.xiaomi.mifi.insurance.payment.thrift.PaymentGatewayName;
import com.xiaomi.mifi.payment.exception.PaymentGatewayResponseException;

/**
 * Created by niqunhao on 17/2/10.
 */
public class ResponseUtilsTest {
    @Test
    public void getResponseServiceLogicException() throws Exception {
        ErrorCode errorCode = ErrorCode.ACCESS_GATEWAY_ERROR;
        ServiceLogicException serviceLogicException = new ServiceLogicException(errorCode);
        TRResponse trResponse = ResponseUtils.getResponse(serviceLogicException);
        Assert.assertNotNull(trResponse);
        Assert.assertEquals(false, trResponse.success);
        Assert.assertEquals("access gateway error", errorCode.externalDescription);
        Assert.assertEquals("访问网关时IO错误", errorCode.internalDescription);

    }

    @Test
    public void getResponsePaymentGateway() throws Exception {

        PaymentGatewayName paymentGatewayName = PaymentGatewayName.CASHPAY;
        PaymentGatewayResponseException paymentGatewayResponseException = new PaymentGatewayResponseException(
                paymentGatewayName, "Success");
        TRResponse trResponse;
        trResponse = ResponseUtils.getResponse(paymentGatewayResponseException);
        Assert.assertNotNull(trResponse);
        Assert.assertEquals(false, trResponse.success);
        Assert.assertEquals(ErrorCode.REQUEST_FAILED.code, trResponse.getCode());
        Assert.assertEquals(ErrorCode.REQUEST_FAILED.internalDescription, trResponse.getDesc());
        Assert.assertEquals("Success", trResponse.getBizContent());

    }

    @Test
    public void getResponseErrorCode() throws Exception {

        ErrorCode errorCode = ErrorCode.SUCCESS;
        TRResponse trResponse = ResponseUtils.getResponse(errorCode);
        Assert.assertNotNull(trResponse);
        Assert.assertEquals(true, trResponse.success);
        Assert.assertEquals(10000, errorCode.code);
        Assert.assertEquals("Success", errorCode.externalDescription);
        Assert.assertEquals("成功", errorCode.internalDescription);

        errorCode = ErrorCode.GATEWAY_NOT_FOUND;
        trResponse = ResponseUtils.getResponse(errorCode);
        Assert.assertNotNull(trResponse);
        Assert.assertEquals(false, trResponse.success);
        Assert.assertEquals("payment gateway not found", errorCode.externalDescription);
        Assert.assertEquals("支付网关没找到", errorCode.internalDescription);

    }

}
