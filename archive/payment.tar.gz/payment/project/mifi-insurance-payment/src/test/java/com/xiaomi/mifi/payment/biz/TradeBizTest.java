package com.xiaomi.mifi.payment.biz;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Matchers.anyLong;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.xiaomi.mifi.insurance.common.util.exception.ServiceLogicException;
import com.xiaomi.mifi.payment.crypto.MultiFieldsSignature;
import com.xiaomi.mifi.payment.proxy.BServiceProxy;
import com.xiaomi.mifi.payment.thrift.*;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import com.xiaomi.mifi.payment.dao.TradeDetailDAO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Created by mars on 17-4-25.
 */
@RunWith(MockitoJUnitRunner.class)
public class TradeBizTest {
    private static final Logger LOGGER = LoggerFactory.getLogger(TradeBizTest.class);

    @InjectMocks
    private TradeBiz tradeBiz;

    @Mock
    private TradeDetailDAO tradeDetailDAO;

    @Mock
    private BServiceProxy bServiceProxy;

    @Mock
    MultiFieldsSignature genericSignature;

    @Test
    public void testQueryPaymentInfoNotFound() {
        when(tradeDetailDAO.findByOrderId(anyInt())).thenReturn(null);
        TradeDetail tradeDetail = tradeBiz.queryPaymentInfo(12345L);
        Assert.assertNull(tradeDetail);
    }

    @Test
    public void testQueryPaymentInfoFound() {
        when(tradeDetailDAO.findByOrderId(anyInt())).thenReturn(new TradeDetail());
        TradeDetail tradeDetail = tradeBiz.queryPaymentInfo(12345L);
        Assert.assertNotNull(tradeDetail);
    }

    @Test
    public void testQueryPaymentInfoNegativeId() {
        TradeDetail tradeDetail = tradeBiz.queryPaymentInfo(-12345L);
        Assert.assertNull(tradeDetail);
    }

    @Test
    public void testQueryDetails() {
        long now = System.currentTimeMillis();
        List<TradeDetail> list = new ArrayList<>();
        TradeDetail tradeDetail = new TradeDetail();
        tradeDetail.setOrderId(12345L);
        list.add(tradeDetail);
        when(tradeDetailDAO.findByTimeSpanAndTradeStatus(now, now + 1000L, TradeStatus.SUCCESS.getValue(), 0, 30)).thenReturn(list);
        list = tradeBiz.queryTradeDetails(now, now + 1000L, TradeStatus.SUCCESS, 0, 30);
        Assert.assertEquals(1, list.size());
        Assert.assertEquals(12345L, list.get(0).getOrderId());
    }

    @Test
    public void testQueryDetailsInvalidParam() {
        List<TradeDetail> tradeDetailList = tradeBiz.queryTradeDetails(System.currentTimeMillis(),
                System.currentTimeMillis() - 1000, TradeStatus.SUCCESS, 0, 30);
        Assert.assertTrue(tradeDetailList.size() == 0);
    }

    @Test
    public void testInsertTradeDetail() {
        when(tradeDetailDAO.insert(any(TradeDetail.class))).thenReturn(1L);
        TradeDetail tradeDetail = new TradeDetail();
        tradeDetail.setOrderId(111L);
        tradeDetail.setTransactionId(123L);
        long ret = tradeBiz.insertTradeDetail(tradeDetail);
        Assert.assertTrue(ret > 0);
    }

    @Test
    public void testUpdateTradeDetail() {
        when(tradeDetailDAO.updateTradeDetail(any(TradeDetail.class))).thenReturn(1);
        TradeDetail tradeDetail = new TradeDetail();
        tradeDetail.setOrderId(111L);
        tradeDetail.setTransactionId(123L);
        int ret = tradeBiz.updateTradeDetail(tradeDetail);
        Assert.assertTrue(ret > 0);
    }

    @Test
    public void testQuerySuccessTradeDetailList() {
        TRDetailListResponse response = new TRDetailListResponse();
        List<TradeDetail> data = new ArrayList<>();
        TradeDetail trs = new TradeDetail();
        data.add(trs);
        long beginTime = 14587878788l;
        long endTime = 14987878788l;

        Integer num2 = tradeDetailDAO.findListByPayTimeCount(beginTime, endTime);
        List<TradeDetail> data2 = tradeDetailDAO.findListByPayTime(beginTime, endTime, 0, 10);

        Assert.assertNotNull(num2);
        Assert.assertNotNull(data2);
    }

    @Test
    public void checkTradeStatus() throws Exception {
        TradeDetail tradeDetail = new TradeDetail();
        // 交易状态符合预期
        tradeDetail.setTradeStatus(TradeStatus.INIT.getValue());
        TradeBiz.checkTradeStatus(tradeDetail, TradeStatus.INIT);

        // 交易状态符合预期
        tradeDetail.setTradeStatus(TradeStatus.INIT.getValue());
        TradeBiz.checkTradeStatus(tradeDetail, TradeStatus.INIT, TradeStatus.WAIT_PAY);

        // 以下情况，交易状态不符合预期
        try {
            TradeBiz.checkTradeStatus(tradeDetail, null);
            Assert.fail();
        } catch (ServiceLogicException e) {
            Assert.assertEquals(ServiceLogicException.ORDER_NOT_PAID, e);
        }

        tradeDetail.setTradeStatus(TradeStatus.WAIT_PAY.getValue());
        try {
            TradeBiz.checkTradeStatus(tradeDetail, null);
            Assert.fail();
        } catch (ServiceLogicException e) {
            Assert.assertEquals(ServiceLogicException.ORDER_NOT_PAID, e);
        }

        tradeDetail.setTradeStatus(TradeStatus.INIT.getValue());
        try {
            TradeBiz.checkTradeStatus(tradeDetail, TradeStatus.WAIT_PAY);
            Assert.fail();
        } catch (ServiceLogicException e) {
            Assert.assertEquals(ServiceLogicException.ORDER_NOT_PAID, e);
        }

        tradeDetail.setTradeStatus(TradeStatus.SUCCESS.getValue());
        try {
            TradeBiz.checkTradeStatus(tradeDetail, TradeStatus.INIT, TradeStatus.WAIT_PAY);
            Assert.fail();
        } catch (ServiceLogicException e) {
            Assert.assertEquals(ServiceLogicException.ORDER_PAY_SUCCESS, e);
        }

        tradeDetail.setTradeStatus(TradeStatus.FAIL.getValue());
        try {
            TradeBiz.checkTradeStatus(tradeDetail, TradeStatus.INIT, TradeStatus.WAIT_PAY);
            Assert.fail();
        } catch (ServiceLogicException e) {
            Assert.assertEquals(ServiceLogicException.ORDER_PAY_FAILED, e);
        }

        tradeDetail.setTradeStatus(TradeStatus.CANCEL.getValue());
        try {
            TradeBiz.checkTradeStatus(tradeDetail, TradeStatus.INIT, TradeStatus.WAIT_PAY);
            Assert.fail();
        } catch (ServiceLogicException e) {
            Assert.assertEquals(ServiceLogicException.ORDER_PAY_CANCELED, e);
        }

        tradeDetail.setTradeStatus(TradeStatus.CLOSE.getValue());
        try {
            TradeBiz.checkTradeStatus(tradeDetail, TradeStatus.INIT, TradeStatus.WAIT_PAY);
            Assert.fail();
        } catch (ServiceLogicException e) {
            Assert.assertEquals(ServiceLogicException.ORDER_PAY_CLOSED, e);
        }

    }

    @Test
    public void testCreateTradeReturnUrlParameters() throws ServiceLogicException {
        String sign = "PAISDFN(*$ADFUInaoipuweh23*(*(&098";
        Map<String, String> params = new HashMap<>();
        params.put("order_id", "1234");
        params.put("sign_type", "RSA2");
        params.put("charset", "UTF-8");
        when(genericSignature.sign(params)).thenReturn(sign);
        String url = tradeBiz.createTradeReturnUrlParameter(1234);
        params.put("sign", sign);
        verify(genericSignature).sign(params);
        Assert.assertEquals("sign=PAISDFN%28*%24ADFUInaoipuweh23*%28*%28%26098&sign_type=RSA2&charset=UTF-8&order_id=1234", url);
    }

    @Test
    public void testIsExpiredAndUpdate() {
        long transactionId = 88888888L;
        TradeDetail tradeDetail = new TradeDetail();
        tradeDetail.setTransactionId(transactionId);
        tradeDetail.setTradeStatus(TradeStatus.WAIT_PAY.getValue());
        tradeDetail.setExpireTime(System.currentTimeMillis() - 100 * 1000L);
        when(tradeDetailDAO.selectForUpdate(transactionId)).thenReturn(tradeDetail);
        when(bServiceProxy.getTimestamp()).thenReturn(System.currentTimeMillis());
        boolean ret = tradeBiz.isExpiredAndUpdate(transactionId);
        verify(tradeDetailDAO).updateByTradeStatus(tradeDetail, TradeStatus.WAIT_PAY.getValue());
        Assert.assertTrue(ret);
    }
}
