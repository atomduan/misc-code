package com.xiaomi.mifi.payment.gateway;

import com.mifi.insurance.payment.util.ResponseStatus;
import com.xiaomi.mifi.insurance.common.util.exception.ServiceLogicException;
import com.xiaomi.mifi.insurance.common.util.http.HttpRequester;
import com.xiaomi.mifi.insurance.payment.thrift.PaymentRequestParam;
import com.xiaomi.mifi.insurance.payment.thrift.PaymentResponseParam;
import com.xiaomi.mifi.payment.biz.TradeBiz;
import com.xiaomi.mifi.payment.crypto.CryptoUtils;
import com.xiaomi.mifi.payment.crypto.MultiFieldsSignature;
import com.xiaomi.mifi.payment.exception.PaymentGatewayResponseException;
import com.xiaomi.mifi.payment.model.PayResult;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.test.util.ReflectionTestUtils;

import java.io.IOException;
import java.security.PublicKey;
import java.util.HashMap;
import java.util.Map;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class MiCashPaymentGatewayTest {

    @Mock
    HttpRequester.HttpResult post;
    @Mock
    MultiFieldsSignature merchantSignature;
    @Mock
    MultiFieldsSignature payMerchantSignature;
    Map<PaymentRequestParam, String> params = new HashMap<>();
    @Mock
    private HttpRequester httpRequester;
    @Mock
    TradeBiz tradeBiz;
    @InjectMocks
    private MiCashpayPaymentGateway miCashpayPaymentGateway;

    private String requestWithdrawUrl;

    private String merchantId;

    private PublicKey cashpayPublicKey;

    @Before
    public void setup() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testApplyWithdraw() throws PaymentGatewayResponseException, ServiceLogicException, IOException {
        //初始化参数
        miCashpayPaymentGateway = new MiCashpayPaymentGateway();
        miCashpayPaymentGateway.setAdaptorForTest();

        params.put(PaymentRequestParam.XIAOMI_ID, "10010");
        params.put(PaymentRequestParam.DRAW_AMOUNT, "1000");
        String transactionId = System.currentTimeMillis() + "3829721937123923422";
        params.put(PaymentRequestParam.MERCHANT_TRANSACTION_ID, transactionId);
        params.put(PaymentRequestParam.DRAW_DESCRIPTION, "withdraw test");
        params.put(PaymentRequestParam.NOTIFY_URL, "http://agent.mi.com");

        //设置变量
        String cashpayPk = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDZc0pM/86uai1g8XCGou5QMw/t" +
                "Mh0R9uS3ePySWA/2NaIJfwxttNqpekPCQDt0dsa/YmI6LricVGMTmpUnpHljohL/" +
                "aOVIJXUuxdE6BiFAfggwe2rLOY8DPsj6nZa9U0lB1bJsIM1h0S4tQNhabBIxDVKo" +
                "rGaHjTEpm639lTd8SwIDAQAB";
        cashpayPublicKey = CryptoUtils.generatePublicKey(cashpayPk);
        ReflectionTestUtils.setField(miCashpayPaymentGateway, "cashpayPublicKey", cashpayPublicKey);
        requestWithdrawUrl = "http://staging.insurance.mi.com";
        merchantId = "0089757";
        ReflectionTestUtils.setField(miCashpayPaymentGateway, "requestWithdrawUrl", requestWithdrawUrl);
        ReflectionTestUtils.setField(miCashpayPaymentGateway, "merchantId", merchantId);
        ReflectionTestUtils.setField(miCashpayPaymentGateway, "merchantSignature", merchantSignature);
        ReflectionTestUtils.setField(miCashpayPaymentGateway, "httpRequester", httpRequester);

        ArgumentCaptor<Map> argument = ArgumentCaptor.forClass(Map.class);
        String sign = "benefitUserId=110000&createTime=1388487642&notifyUrl=http://oneboxhost/mock/notify&outTransferId=48794928118907008081&partnerId=10000001 &transferAmount=1";
        when(merchantSignature.sign(any(Map.class))).thenReturn(sign);
        when(httpRequester.post(eq(requestWithdrawUrl), eq((Map<String, String>) null), argument.capture())).thenReturn(post);
        String syncResponse = "<cashpayTransfer>\n" +
                "    <baseInfo>\n" +
                "        <isSuccess>T</isSuccess>\n" +
                "        <partnerId>10000000</partnerId>\n" +
                "        <responseCode>TRANSFER_SUCCESS</responseCode>\n" +
                "        <sign>GycJ87odkBcQn_2chRyZNW04ezpflG0F9960p9VxUeParU6-WVVbcXkQOYtZOknPQJx3TNh79-X5DuPPELXOLtxw_PHWRHDko7VZRxCkeiQEUR851e_vDzzINujxo4FjqSVFDem0eEn_jR0mSOuUcb2NZqM2kBshJzPN03Nl3uw.</sign>\n" +
                "        <signType>RSA</signType>\n" +
                "    </baseInfo>\n" +
                "    <transferInfo>\n" +
                "        <outTransferId>45662c538cb54c0cafc12766f9b76989</outTransferId>\n" +
                "        <transferDesc>商户10000000向用户4062701转账0.01元</transferDesc>\n" +
                "        <transferId>20150617194605644001010300881784</transferId>\n" +
                "    </transferInfo>\n" +
                "</cashpayTransfer>";
        when(post.getString()).thenReturn(syncResponse);
        Map<PaymentResponseParam, String> responseParamStringMap;
        responseParamStringMap = miCashpayPaymentGateway.applyWithdraw(params);
        verify(merchantSignature).sign(any(Map.class));
        verify(httpRequester).post(eq(requestWithdrawUrl), eq((Map<String, String>) null), argument.capture());
        verify(post).getString();
        //验证请求参数
        Map<String, String> requestParams = argument.getValue();
        Assert.assertEquals("transfer", requestParams.get("service"));
        Assert.assertEquals(merchantId, requestParams.get("partnerId"));
        Assert.assertEquals("http://agent.mi.com", requestParams.get("notifyUrl"));
        //Assert.assertEquals(encAmount, requestParams.get("transferAmount"));
        Assert.assertEquals("10010", requestParams.get("benefitUserId"));
        //验证返回结果
        Assert.assertEquals("45662c538cb54c0cafc12766f9b76989", responseParamStringMap.get(PaymentResponseParam.MERCHANT_TRANSACTION_ID));
        Assert.assertEquals("20150617194605644001010300881784", responseParamStringMap.get(PaymentResponseParam.DRAW_ID));
        Assert.assertEquals("商户10000000向用户4062701转账0.01元", responseParamStringMap.get(PaymentResponseParam.DRAW_RESULT_DESCRIPTION));

    }

    @Test
    public void testParseNotify(){
        when(payMerchantSignature.verify(Mockito.anyMap(), Mockito.anyString())).thenReturn(false);
        PayResult parsePayNotify = miCashpayPaymentGateway.parsePayNotify(new HashMap<String, String>());
        Assert.assertEquals(ResponseStatus.STATUS_SIGN_MISMATCH, parsePayNotify.getStatus());

        Map<String, String> map = new HashMap<>();
        map.put("outOrderId", "12345678");
        map.put("tradeId", "87654321");
        map.put("payTime", "1479121238");
        map.put("tradeStatus", "TRADE_CANCEL");
        when(payMerchantSignature.verify(Mockito.anyMap(), Mockito.anyString())).thenReturn(true);
        PayResult parsePayNotify2 = miCashpayPaymentGateway.parsePayNotify(map);
        Assert.assertEquals(12345678L, parsePayNotify2.getTransactionId());
        Assert.assertEquals("87654321", parsePayNotify2.getTradeId());
        Assert.assertEquals(1479121238000L, parsePayNotify2.getPayTime());
        Assert.assertEquals(ResponseStatus.STATUS_TRANSACTION_CANCELED, parsePayNotify2.getStatus());

        Map<String,String> map3 = new HashMap<>(map);
        map3.put("tradeStatus", "TRADE_CLOSED");
        when(payMerchantSignature.verify(Mockito.anyMap(), Mockito.anyString())).thenReturn(true);
        PayResult parsePayNotify3 = miCashpayPaymentGateway.parsePayNotify(map3);
        Assert.assertEquals(ResponseStatus.STATUS_TRANSACTION_CLOSED, parsePayNotify3.getStatus());

        Map<String,String> map4 = new HashMap<>(map);
        map4.put("tradeStatus","TRADE_SUCCESS");
        when(payMerchantSignature.verify(Mockito.anyMap(), Mockito.anyString())).thenReturn(true);
        PayResult parsePayNotify4 = miCashpayPaymentGateway.parsePayNotify(map4);
        Assert.assertEquals(ResponseStatus.STATUS_SUCCESS, parsePayNotify4.getStatus());

        Map<String,String> map5 = new HashMap<>(map);
        map5.put("tradeStatus","WAIT_PAY");
        when(payMerchantSignature.verify(Mockito.anyMap(), Mockito.anyString())).thenReturn(true);
        PayResult parsePayNotify5 = miCashpayPaymentGateway.parsePayNotify(map5);
        Assert.assertEquals(ResponseStatus.STATUS_WAIT_PAY, parsePayNotify5.getStatus());
    }
}