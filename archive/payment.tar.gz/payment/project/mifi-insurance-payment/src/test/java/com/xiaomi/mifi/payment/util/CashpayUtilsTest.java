package com.xiaomi.mifi.payment.util;

import static com.xiaomi.mifi.payment.util.PayCenterUtils.createOrderDateFormat;

import java.text.DateFormat;
import java.util.Date;

import org.junit.Assert;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class CashpayUtilsTest {
    private static final Logger LOGGER = LoggerFactory.getLogger(CashpayUtilsTest.class);

    @Test
    public void TestCreateOrderDateFormat() {
        Date date = new Date(2017 - 1900, 02 - 1, 10, 15, 00);
        DateFormat df = createOrderDateFormat();
        String actual = df.format(date);
        Assert.assertEquals("2017-02-10 15:00:00", actual);
    }

    @Test
    public void parseEpochTime() {
        String ts = "2017-02-22 13:35:24";
        Date date = PayCenterUtils.parseEpochTime(ts);
        Assert.assertNotNull(date);
        Assert.assertEquals(2017 - 1900, date.getYear());
        Assert.assertEquals(2 - 1, date.getMonth());
        Assert.assertEquals(22, date.getDate());
        Assert.assertEquals(13, date.getHours());
        Assert.assertEquals(35, date.getMinutes());
        Assert.assertEquals(24, date.getSeconds());
    }

    @Test
    public void parseAmount() throws Exception {
        int amount = PayCenterUtils.parseAmount("1000.00");
        Assert.assertEquals(100000, amount);

        amount = PayCenterUtils.parseAmount("0.64");
        Assert.assertEquals(64, amount);

        amount = PayCenterUtils.parseAmount("0.65");
        Assert.assertEquals(65, amount);

        amount = PayCenterUtils.parseAmount("0.69");
        Assert.assertEquals(69, amount);

        amount = PayCenterUtils.parseAmount("0.01");
        Assert.assertEquals(1, amount);

        amount = PayCenterUtils.parseAmount("0.00");
        Assert.assertEquals(0, amount);

        amount = PayCenterUtils.parseAmount("100.69");
        Assert.assertEquals(10069, amount);
    }
}
