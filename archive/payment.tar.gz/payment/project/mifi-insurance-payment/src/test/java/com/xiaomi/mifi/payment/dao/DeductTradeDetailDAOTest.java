package com.xiaomi.mifi.payment.dao;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.xiaomi.mifi.payment.thrift.DeductTradeDetail;

/**
 * Created by mars on 17-4-24.
 */

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:applicationContext.xml")
public class DeductTradeDetailDAOTest extends BaseDAOTest {
    private static final Logger LOGGER = LoggerFactory.getLogger(DeductTradeDetailDAOTest.class);
    @Autowired
    DeductTradeDetailDAO dao;

    @Override
    @Before
    public void setUp() throws Exception {
        super.setUp();
    }

    @Test
    public void testInsert() throws Exception {
        DeductTradeDetail deductTradeDetail = new DeductTradeDetail();
        deductTradeDetail.setNotifyId(12345L);
        deductTradeDetail.setTotalFee(1000);
        deductTradeDetail.setReceiveTime(System.currentTimeMillis());
        deductTradeDetail.setReturnUrl("test return url");
        deductTradeDetail.setTransactionId(12345678L);
        deductTradeDetail.setDeductId("111111111111111111");
        long id = 0;
        try {
            id = dao.insert(deductTradeDetail);
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
        }
        Assert.assertEquals(1, id);
    }

    @Test
    public void testFind() {
        DeductTradeDetail deductTradeDetail = new DeductTradeDetail();
        deductTradeDetail.setNotifyId(12345L);
        deductTradeDetail.setTotalFee(1000);
        deductTradeDetail.setReturnUrl("test return url");
        deductTradeDetail.setTransactionId(12345678L);
        deductTradeDetail.setDeductId("1111111111");
        dao.insert(deductTradeDetail);
        DeductTradeDetail deductTradeDetail2 = dao.findByDeductId("1111111111");
        Assert.assertNotNull(deductTradeDetail2);
    }

    @Test
    public void testUpdate() {
        DeductTradeDetail deductTradeDetail = new DeductTradeDetail();
        deductTradeDetail.setNotifyId(12345L);
        deductTradeDetail.setTotalFee(1000);
        deductTradeDetail.setReturnUrl("test return url");
        deductTradeDetail.setTransactionId(12345678L);
        deductTradeDetail.setDeductId("11111");
        dao.insert(deductTradeDetail);
        DeductTradeDetail deductTradeDetail2 = dao.findByDeductId("11111");
        Assert.assertNotNull(deductTradeDetail2);
        deductTradeDetail2.setTransactionId(22222L);
        dao.updateDeduct(deductTradeDetail2);
        DeductTradeDetail deductTradeDetail3 = dao.findByDeductId("11111");
        Assert.assertNotNull(deductTradeDetail3);
        Assert.assertEquals(22222L, deductTradeDetail3.getTransactionId());
    }
}
