package com.xiaomi.mifi.payment.dao;

import com.xiaomi.mifi.insurance.payment.thrift.PayChannel;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.sql.ResultSet;
import java.sql.Statement;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:applicationContext.xml")
public class PayChannelDAOTest extends BaseDAOTest {

    @Autowired
    PayChannelDAO dao;

    @Override
    @Before
    public void setUp() throws Exception {
        super.setUp();

        try (Statement st = conn.createStatement()) {
            st.executeUpdate("INSERT INTO " + PayChannelDAO.TABLE_NAME + "(" + PayChannelDAO.INSERT_COLUMNS + ")VALUES('wxpay','微信支付','http://xx.com/wxpay.png',2)");
        }
    }

    @Test
    public void insert() throws Exception {
        PayChannel one = new PayChannel();
        one.setName("alipay");
        one.setDisplayName("支付宝");
        one.setIconUrl("http://xxx.com/alipay.png");
        one.setChannelId(1);

        dao.insert(one);

        try (Statement st = conn.createStatement()) {
            ResultSet rs = st.executeQuery("SELECT " + PayChannelDAO.SELECT_COLUMNS + " FROM " + PayChannelDAO.TABLE_NAME + " WHERE name='alipay'");
            Assert.assertTrue(rs.next());

            Assert.assertEquals("alipay", rs.getString("name"));
            Assert.assertEquals("支付宝", rs.getString("display_name"));
            Assert.assertEquals("http://xxx.com/alipay.png", rs.getString("icon_url"));
            Assert.assertEquals(1, rs.getInt("channel_id"));

        }
    }

    @Test
    public void findByChannelId() throws Exception {
        PayChannel one = dao.findByChannelId(2);
        Assert.assertNotNull(one);
        Assert.assertEquals("wxpay", one.getName());
    }
}