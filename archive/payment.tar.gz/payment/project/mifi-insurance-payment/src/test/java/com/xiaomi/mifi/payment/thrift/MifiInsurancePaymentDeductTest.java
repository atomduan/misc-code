package com.xiaomi.mifi.payment.thrift;

import java.util.UUID;

import org.apache.thrift.TException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.xiaomi.miliao.thrift.ClientFactory;

public class MifiInsurancePaymentDeductTest {

    private static final Logger LOGGER = LoggerFactory.getLogger(MifiInsurancePaymentDeductTest.class);

    public static void main(String[] args) throws TException {
        MifiInsurancePaymentClientService.Iface client = ClientFactory
                .getClient(MifiInsurancePaymentClientService.Iface.class, 5000);
        String logId = UUID.randomUUID().toString();
        TPDeductSign request = new TPDeductSign();
        request.setBizType(0);
        request.setReturnUrl("http://www.baidu.com");
        request.setProductName("小米保险");
        
        TRDeductSign result = client.createDeductSign(logId, request);
        LOGGER.info("create deduct sign result {}", result);

        TPDeduct tpDeduct = new TPDeduct();
        tpDeduct.setDeductId("20160624100043647016020300880023");
        tpDeduct.setXiaomiId(4166015);
        tpDeduct.setCertType(CertType.ID_CARD);
        tpDeduct.setCardType(BankCardType.DEBIT_CARD);
        tpDeduct.setOrderId(20000000008L);
        tpDeduct.setProductName("小米保险");
        tpDeduct.setTotalFee(1);
        tpDeduct.setOrderDesc("小米");
        tpDeduct.setNotifyType(NotifyType.HTTP);
        tpDeduct.setBankUserName("aaaa");
        tpDeduct.setNotifyServiceName("AAAA");
        tpDeduct.setNotifyMethodName("BBBB");
        client.commitDeduct(logId, tpDeduct);
    }
}
