package com.xiaomi.mifi.payment.crypto;

import org.junit.Assert;
import org.junit.Test;

import java.security.PublicKey;

public class CryptoUtilsTest {
    @Test
    public void generatePublicKey() throws Exception {
        String pk = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDDWwRHPVDCD81vulmut/+ME1+ZUMf9sf2S1jYmtTsOPP+cmYXFL7DCwWh59WOhVcHBsgcm6IYIJB8yCWP9T6mbeitKRLq8UiCctp+aCLNW6Q1/DdD0mzw0JDtZsAWZ8cfze7K/gV7OmnB9fA4iA4Wix6K4I68pwvafm3AyS12TSwIDAQAB";
        PublicKey publicKey = CryptoUtils.generatePublicKey(pk);
        Assert.assertNotNull(publicKey);

        byte[] bytes = CryptoUtils.rsaEncrypt(publicKey, "123");
        Assert.assertNotNull(bytes);
    }

}