package com.xiaomi.mifi.payment.gateway;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Assert;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.xiaomi.mifi.insurance.payment.thrift.BillType;
import com.xiaomi.mifi.insurance.payment.thrift.PaymentRequestParam;
import com.xiaomi.mifi.insurance.payment.thrift.RefundRequestParam;
import com.xiaomi.mifi.insurance.payment.thrift.TRBillDetail;
import com.xiaomi.mifi.payment.crypto.WeixinSignature;
import com.xiaomi.mifi.payment.util.WeixinPayUtils;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:applicationContext.xml")
public class WeixinPaymentGatewayTest {

    private static final Logger LOGGER = LoggerFactory.getLogger(WeixinPaymentGatewayTest.class);

    @Autowired
    WeixinPaymentGateway gateway;

    @Autowired
    WeixinSignature weixinSignature;

    @Ignore
    @Test
    public void pay() throws Exception {
        HashMap<PaymentRequestParam, String> params = new HashMap<>();
        String transactionId = System.currentTimeMillis() + "";
        String subject = "test中文";
        String description = "test description中文";
        String amount = "101";
        String notifyUrl = "http://ins.staging.mifi.pt.xiaomi.com/api/notify/alipay/pay";
        String returnUrl = "http://staging.mifi.pt.xiaomi.com/cashpay/xxx";

        params.put(PaymentRequestParam.MERCHANT_TRANSACTION_ID, transactionId);
        params.put(PaymentRequestParam.PAY_SUBJECT, subject);
        params.put(PaymentRequestParam.PAY_DESCRIPTION, description);
        params.put(PaymentRequestParam.PAY_AMOUNT, amount);
        params.put(PaymentRequestParam.NOTIFY_URL, notifyUrl);
        params.put(PaymentRequestParam.RETURN_URL, returnUrl);
        params.put(PaymentRequestParam.CREATE_IP, "");
        String response = gateway.createPayRequest(params);

        LOGGER.debug("get response: {}", response);
        Assert.assertNotNull(response);
    }

    @Ignore
    @Test
    public void refund() throws Exception {
        HashMap<RefundRequestParam, String> params = new HashMap<>();
        params.put(RefundRequestParam.OUTER_ORDER_ID, "392090090647846912");
        params.put(RefundRequestParam.REFUND_AMOUNT, "1");
        params.put(RefundRequestParam.OUTER_REQUEST_NO, "111111111111111");
        params.put(RefundRequestParam.TARDE_NO, "1111111111111");
        String response = gateway.createRefundRequest(params);
        LOGGER.info(response);
        Assert.assertNotNull(response);
    }

    @Ignore
    @Test
    public void downloadBillList() throws Exception {
        String billDate = "20170605";
        List<TRBillDetail> result = gateway.queryNewBill(billDate, BillType.INCOME);
        System.out.println(result);
        // List<TRBillDetail> result1 = gateway.queryNewBill(billDate,
        // BillType.OUTCOME);
        // System.out.println(result1);
    }

    @Ignore
    @Test
    public void makeNotifyXmlRepsonse() {
        String params = "<xml> <appid><![CDATA[wxa57d07f93c926626]]></appid>  <bank_type><![CDATA[CFT]]></bank_type>  <fee_type><![CDATA[CNY]]></fee_type>  <is_subscribe><![CDATA[Y]]></is_subscribe>  <mch_id><![CDATA[1480002212]]></mch_id>  <nonce_str><![CDATA[5d2b6c2a8db53831f7eda20af46e531c]]></nonce_str>   <out_trade_no><![CDATA[392135002140704768]]></out_trade_no>  <result_code><![CDATA[SUCCESS]]></result_code>  <return_code><![CDATA[SUCCESS]]></return_code> <sub_mch_id><![CDATA[10000100]]></sub_mch_id>  <time_end><![CDATA[20140903131540]]></time_end>  <total_fee>1</total_fee>  <trade_type><![CDATA[JSAPI]]></trade_type>  <transaction_id><![CDATA[1004400740201409030005092168]]></transaction_id></xml>";
        Map<String,String> maps = WeixinPayUtils.xmlDataToMap(params);
        String sign = weixinSignature.getSign(maps);
        maps.put("sign", sign);
        LOGGER.info(WeixinPayUtils.generateXmlString(maps));
    }

}
