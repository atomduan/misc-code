package com.xiaomi.mifi.payment.crypto;

import org.junit.Assert;
import org.junit.Test;

import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.util.HashMap;

public class SHA256WithRSASignatureTest {
    @Test
    public void getSignatureAlgorithm() throws Exception {
        KeyPairGenerator kpg = KeyPairGenerator.getInstance("RSA");
        KeyPair keyPair = kpg.generateKeyPair();
        HashMap<String, String> data = new HashMap<>();
        String expected = "SHA256WithRSA";
        SHA256WithRSASignature signature = new SHA256WithRSASignature();
        Assert.assertEquals(expected, signature.getSignatureAlgorithm());
        data.put("key", "value");
        signature.privateKey = keyPair.getPrivate();
        String sign = signature.sign(data);
        Assert.assertNotNull(sign);
    }

}