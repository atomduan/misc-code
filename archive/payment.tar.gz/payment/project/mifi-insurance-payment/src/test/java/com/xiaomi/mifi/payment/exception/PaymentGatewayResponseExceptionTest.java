package com.xiaomi.mifi.payment.exception;

import com.xiaomi.mifi.insurance.payment.thrift.PaymentGatewayName;
import org.junit.Assert;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class PaymentGatewayResponseExceptionTest {

    private static final Logger LOGGER = LoggerFactory.getLogger(PaymentGatewayResponseExceptionTest.class);

    @Test
    public void toJson() throws Exception {
        PaymentGatewayResponseException e = new PaymentGatewayResponseException(PaymentGatewayName.CASHPAY, "INVALID");

        Assert.assertEquals("INVALID", e.getResponseCode());
    }

}