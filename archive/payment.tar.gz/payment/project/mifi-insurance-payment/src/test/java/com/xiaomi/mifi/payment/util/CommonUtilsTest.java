package com.xiaomi.mifi.payment.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.thrift.TException;
import org.junit.Test;

import com.xiaomi.mifi.payment.thrift.CardType;
import com.xiaomi.mifi.payment.thrift.Channel;
import com.xiaomi.mifi.payment.thrift.NotifyType;
import com.xiaomi.mifi.payment.thrift.TPPay;
import com.xiaomi.mifi.payment.thrift.TradeType;

/**
 * Created by mars on 17-4-24.
 */
public class CommonUtilsTest {

    @Test
    public void testOutputObject() throws TException {
        TPPay tpPay = new TPPay();
        Map<Channel, List<CardType>> payChannel = new HashMap<>();

        List<CardType> cardTypeListAlipay = new ArrayList<>();
        cardTypeListAlipay.add(CardType.CREDIT);
        payChannel.put(Channel.ALIPAY, cardTypeListAlipay);

        List<CardType> cardTypeListMiChash = new ArrayList<>();
        cardTypeListMiChash.add(CardType.CREDIT);
        cardTypeListMiChash.add(CardType.DEBIT);
        payChannel.put(Channel.CASHPAY, cardTypeListMiChash);

        tpPay.setPayChannel(payChannel);
        tpPay.setTradeType(TradeType.PAY);
        tpPay.setOrderId(8888888888L);
        tpPay.setTotalFee(888L);
        tpPay.setProductName("testProduct");
        tpPay.setOrderDesc("testOrderDesc");
        tpPay.setExpireTime(System.currentTimeMillis() + 60 * 60 * 1000);// 一小时
        tpPay.setNotifyType(NotifyType.THRIFT);
        tpPay.setNotifyServiceName("MifiInsuranceService");
        tpPay.setNotifyMethodName("payCenterNotify");
        tpPay.setNotifyURL("test notify url");
        tpPay.setReturnURL("test return url");
        String objString =  tpPay.toString();
        System.out.println(objString);
    }

}
