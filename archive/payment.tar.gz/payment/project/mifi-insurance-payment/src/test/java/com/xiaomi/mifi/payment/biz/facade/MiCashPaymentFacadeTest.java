package com.xiaomi.mifi.payment.biz.facade;

import java.util.HashMap;
import java.util.Map;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.test.util.ReflectionTestUtils;

import com.xiaomi.mifi.insurance.common.util.exception.ErrorCode;
import com.xiaomi.mifi.insurance.common.util.exception.ServiceLogicException;
import com.xiaomi.mifi.insurance.payment.thrift.CommitPaymentMethod;
import com.xiaomi.mifi.payment.biz.RefundBiz;
import com.xiaomi.mifi.payment.exception.PaymentGatewayResponseException;
import com.xiaomi.mifi.payment.gateway.MiCashpayPaymentGateway;
import com.xiaomi.mifi.payment.model.CommitPayRequest;
import com.xiaomi.mifi.payment.model.CommitPayResult;
import com.xiaomi.mifi.payment.model.CommitRefundRequest;
import com.xiaomi.mifi.payment.model.CommitRefundResult;
import com.xiaomi.mifi.payment.thrift.CardType;
import com.xiaomi.mifi.payment.thrift.PaymentStatus;
import com.xiaomi.mifi.payment.thrift.RefundDetail;
import com.xiaomi.mifi.payment.thrift.TradeStatus;

/**
 * Created by tianbo on 17-5-17.
 */
@RunWith(MockitoJUnitRunner.class)
public class MiCashPaymentFacadeTest {
    @Mock
    MiCashpayPaymentGateway miCashpayPaymentGateway;

    @InjectMocks
    MiCashPaymentFacade miCashPaymentFacade;

    @Mock
    RefundBiz refundBiz;

    @Test
    public void testCommitRefund() throws ServiceLogicException, PaymentGatewayResponseException {
        // isSuccess=F && responseCode=CALL_SERVICE_FAILED
        String asynResponseFailed = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n" +
                "\n" +
                "<cashpay> \n" +
                "  <isSuccess>F</isSuccess>  \n" +
                "  <responseCode>CALL_SERVICE_FAILED</responseCode> \n" +
                "</cashpay>";
        Mockito.when(miCashpayPaymentGateway.createRefundRequest(Mockito.anyMap())).thenReturn(asynResponseFailed);
        CommitRefundRequest commitRefundRequest = new CommitRefundRequest();
        commitRefundRequest.setTradeTransactionId(391864202908925952L);
        commitRefundRequest.setRefundTransactionId(391864243025346560L);
        commitRefundRequest.setRefundFee(1234L);

        CommitRefundResult commitRefundResultFailed = miCashPaymentFacade.commitRefund(commitRefundRequest);
        Assert.assertEquals(ErrorCode.REFUND_ERROR, commitRefundResultFailed.getErrorCode());
        Assert.assertEquals(false, commitRefundResultFailed.isSuccess());

        // isSuccess=T && responseCode=SUCCESS
        String asynResponseSuccess = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n" +
                "\n" +
                "<cashpay> \n" +
                "  <isSuccess>T</isSuccess>  \n" +
                "  <responseCode>SUCCESS</responseCode>  \n" +
                "  <refundTrade> \n" +
                "    <refundId>20141229145137264000010300882039</refundId>  \n" +
                "    <refundDesc>refund</refundDesc>  \n" +
                "    <tradeId>20141229145129042001010300881274</tradeId>  \n" +
                "    <partnerRefundId>ece5774577664bed91</partnerRefundId>  \n" +
                "    <outOrderId>391864202908925952</outOrderId>  \n" +
                "    <createTime>2017-12-29 14:51:37</createTime>  \n" +
                "    <applyRefundFee>1234</applyRefundFee>  \n" +
                "    <refundFee>0</refundFee>  \n" +
                "    <refundStatus>APPLY_REFUND</refundStatus>  \n" +
                "    <failDesc/> \n" +
                "  </refundTrade> \n" +
                "</cashpay>\n";
        Mockito.when(miCashpayPaymentGateway.createRefundRequest(Mockito.anyMap())).thenReturn(asynResponseSuccess);
        RefundDetail refundDetail = new RefundDetail();
        refundDetail.setStatus(TradeStatus.SUCCESS.getValue());
        refundDetail.setPaymentStatus(PaymentStatus.SUCCESS.getValue());
        Mockito.when(refundBiz.findRefundByTradeTransactionId(Mockito.anyLong())).thenReturn(refundDetail);
        CommitRefundResult commitRefundResultSuccess = miCashPaymentFacade.commitRefund(commitRefundRequest);
        Assert.assertEquals(ErrorCode.REPEATED_REFUND, commitRefundResultSuccess.getErrorCode());
        Assert.assertEquals(true, commitRefundResultSuccess.isSuccess());
        Assert.assertEquals("Refund is already success", commitRefundResultSuccess.getResponse());

        //isSuccess=T && responseCode=APPLY_REFUND_MORE_THAN_ONCE_ERROR
        String asynResponseSuccess2 = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n" +
                "\n" +
                "<cashpay> \n" +
                "  <isSuccess>T</isSuccess>  \n" +
                "  <responseCode>APPLY_REFUND_MORE_THAN_ONCE_ERROR</responseCode>  \n" +
                "  <refundTrade> \n" +
                "    <refundId>20141229145137264000010300882039</refundId>  \n" +
                "    <refundDesc>refund</refundDesc>  \n" +
                "    <tradeId>20141229145129042001010300881274</tradeId>  \n" +
                "    <partnerRefundId>ece5774577664bed91</partnerRefundId>  \n" +
                "    <outOrderId>391878755441704960</outOrderId>  \n" +
                "    <createTime>2017-12-29 14:51:37</createTime>  \n" +
                "    <applyRefundFee>1234</applyRefundFee>  \n" +
                "    <refundFee>0</refundFee>  \n" +
                "    <refundStatus>APPLY_REFUND</refundStatus>  \n" +
                "    <failDesc/> \n" +
                "  </refundTrade> \n" +
                "</cashpay>\n";
        Mockito.when(miCashpayPaymentGateway.createRefundRequest(Mockito.anyMap())).thenReturn(asynResponseSuccess2);
        CommitRefundResult commitRefundResultSuccess2 = miCashPaymentFacade.commitRefund(commitRefundRequest);
        Assert.assertEquals(ErrorCode.REPEATED_REFUND, commitRefundResultSuccess2.getErrorCode());
        Assert.assertEquals(true, commitRefundResultSuccess2.isSuccess());
        Assert.assertEquals("Refund is already success", commitRefundResultSuccess2.getResponse());

        //create refund request throws exception
        Mockito.when(miCashpayPaymentGateway.createRefundRequest(Mockito.anyMap()))
                .thenThrow(new ServiceLogicException(ErrorCode.REFUND_ERROR));
        CommitRefundResult commitRefundResultFailed2 = miCashPaymentFacade.commitRefund(new CommitRefundRequest());
        Assert.assertEquals(ErrorCode.INTERNAL_SERVER_ERROR, commitRefundResultFailed2.getErrorCode());
        Assert.assertEquals("refund internal exception", commitRefundResultFailed2.getResponse());
        Assert.assertEquals(false, commitRefundResultFailed2.isSuccess());
    }

    @Test
    public void testCommitPay() throws ServiceLogicException,PaymentGatewayResponseException{
        CommitPayRequest commitPayRequest = new CommitPayRequest();
        commitPayRequest.setTransactionId(12345678L);
        commitPayRequest.setGoodName("小米健康险");
        commitPayRequest.setOrderDesc("小米保险");
        commitPayRequest.setTotalFee(1234L);
        commitPayRequest.setNotifyUrl("http://mi.notify.com");
        commitPayRequest.setReturnUrl("http://mi.return.com");
        commitPayRequest.setExpireTime(System.currentTimeMillis()+30*60*1000);
        commitPayRequest.getAllowedCardType().add(CardType.CREDIT);
        ReflectionTestUtils.setField(miCashPaymentFacade, "urlCashPay", "http://mi.pay");
        CommitPayResult payResult = miCashPaymentFacade.commitPay(commitPayRequest);
        Assert.assertEquals(true, payResult.isSuccess());
        Assert.assertEquals(ErrorCode.SUCCESS, payResult.getErrorCode());
        Assert.assertEquals(CommitPaymentMethod.REDIRECT, payResult.getMethod());
        Assert.assertEquals("http://mi.pay", payResult.getUrl());

        Mockito.when(miCashpayPaymentGateway.createPayRequest(Mockito.anyMap()))
                .thenThrow(new ServiceLogicException(ErrorCode.INTERNAL_SERVER_ERROR));
        CommitPayResult result = miCashPaymentFacade.commitPay(commitPayRequest);
        Assert.assertEquals(ErrorCode.INTERNAL_SERVER_ERROR, result.getErrorCode());
        Assert.assertEquals(false, result.isSuccess());
    }

    @Test
    public void testVerifyPayParam(){
        Map<String, String> emptyMap = new HashMap<>();
        Assert.assertEquals(false, miCashPaymentFacade.verifyPayParam(emptyMap));

        Map<String, String> missingParamMap = new HashMap<>();
        missingParamMap.put("outOrderId", "12345678");
        missingParamMap.put("tradeId", "12345678");
        missingParamMap.put("totalFee", "1200");
        missingParamMap.put("tradeStatus", "TRADE_SUCCESS");
        Assert.assertEquals(false, miCashPaymentFacade.verifyPayParam(missingParamMap));
        Map<String,String> map=new HashMap<>(missingParamMap);
        map.put("payTime", "1478121129");
        Assert.assertEquals(true, miCashPaymentFacade.verifyPayParam(map));
    }

    @Test
    public void testVerifyRefundParam(){
        Map<String, String> emptyMap = new HashMap<>();
        Assert.assertEquals(false, miCashPaymentFacade.verifyRefundParam(emptyMap));

        Map<String, String> missingParamMap = new HashMap<>();
        missingParamMap.put("refundId", "1234567810");
        missingParamMap.put("partnerRefundId", "1234567811");
        missingParamMap.put("outOrderId", "1234567812");
        missingParamMap.put("refundDesc", "refund");
        missingParamMap.put("refundTime", "1481234912");
        missingParamMap.put("responseCode", "SUCCESS");
        missingParamMap.put("responseDesc", "desc");
        Assert.assertEquals(false, miCashPaymentFacade.verifyRefundParam(missingParamMap));
        Map<String, String> map = new HashMap<>(missingParamMap);
        map.put("refundFee", "1200");
        Assert.assertEquals(true, miCashPaymentFacade.verifyRefundParam(map));
    }
}
