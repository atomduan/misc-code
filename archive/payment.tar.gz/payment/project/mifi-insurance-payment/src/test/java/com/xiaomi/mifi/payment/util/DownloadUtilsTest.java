package com.xiaomi.mifi.payment.util;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.xiaomi.mifi.insurance.common.util.exception.ServiceLogicException;
import com.xiaomi.mifi.insurance.payment.thrift.BillType;
import com.xiaomi.mifi.insurance.payment.thrift.TRBillDetail;
import com.xiaomi.mifi.payment.util.download.SftpDownloadFileService;

import junit.framework.Assert;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:applicationContext.xml")
public class DownloadUtilsTest {

    SftpDownloadFileService downloadService = new SftpDownloadFileService(null, null, null, null);
    String fileName = "20885211421729680156_20170821.zip";
    String basePath = new File(getClass().getClassLoader().getResource(fileName).getFile()).getParent()
            + File.separatorChar;

    @Ignore
    @Test
    public void testZipRead() {
        List<TRBillDetail> result = new ArrayList<TRBillDetail>();
        try {
            result = downloadService.zipFileRead(basePath + fileName, basePath, "2017-08-21",
                    BillType.INCOME);
        } catch (ServiceLogicException e) {
            e.printStackTrace();
        }
        Assert.assertEquals(225, result.size());
    }

    @Test
    public void test() {
        System.out.println(PayCenterUtils.parseAmount("19.90"));
        System.out.println(PayCenterUtils.parseAmountV0("19.90"));
    }

}
