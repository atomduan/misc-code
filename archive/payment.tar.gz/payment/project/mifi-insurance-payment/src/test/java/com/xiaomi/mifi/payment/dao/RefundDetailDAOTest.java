package com.xiaomi.mifi.payment.dao;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.xiaomi.mifi.payment.thrift.Channel;
import com.xiaomi.mifi.payment.thrift.RefundDetail;

/**
 * Created by mars on 17-4-24.
 */

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:applicationContext.xml")
public class RefundDetailDAOTest extends BaseDAOTest {
    @Autowired
    RefundDetailDAO dao;

    private static final long NOW_TIMESTAMP = System.currentTimeMillis();

    @Override
    @Before
    public void setUp() throws Exception {
        super.setUp();
    }

    @Test
    public void testInsert() {
        RefundDetail refundDetail = new RefundDetail();
        refundDetail.setChannel(Channel.ALIPAY.getValue());
        refundDetail.setAmount(1000);
        refundDetail.setCreateTime(System.currentTimeMillis());
        refundDetail.setReceiveTime(System.currentTimeMillis());
        refundDetail.setCurrency(com.xiaomi.mifi.payment.thrift.Currency.CNY.getValue());
        refundDetail.setOrderId(12345L);
        refundDetail.setRefundTransactionId(88888888L);
        long id = dao.insert(refundDetail);
        Assert.assertEquals(1, id);
    }

    @Test
    public void testFind() {
        testInsert();
        RefundDetail refundDetail = dao.findRefundDetailByRefundTransactionId(88888888L);
        Assert.assertNotNull(refundDetail);
    }

    @Test
    public void testUpdate() {
        testInsert();
        RefundDetail refundDetail = dao.findRefundDetailByRefundTransactionId(88888888L);
        Assert.assertNotNull(refundDetail);
        RefundDetail refundDetail2 = dao.findRefundDetailByRefundTransactionId(88888888L);
        Assert.assertEquals(12345L, refundDetail2.getOrderId());
        Assert.assertNotNull(refundDetail2);
        refundDetail2.setOrderId(54321L);
        int ret = dao.updateRefund(refundDetail2);
        Assert.assertEquals(1, ret);
        RefundDetail refundDetail3 = dao.findRefundDetailByRefundTransactionId(88888888L);
        Assert.assertNotNull(refundDetail3);
        Assert.assertEquals(54321L, refundDetail3.getOrderId());
    }

    @Test
    public void testFindListByPayTime() {
        RefundDetail refundDetail = new RefundDetail();
        refundDetail.setChannel(Channel.ALIPAY.getValue());
        refundDetail.setStatus(2);
        refundDetail.setRefundTransactionId(1234567890L);
        refundDetail.setOrderId(1234567L);
        dao.insert(refundDetail);
        List<RefundDetail> list = dao.findListByPayTime(NOW_TIMESTAMP - 100000000, NOW_TIMESTAMP + 100000000, 0, 10);
        Assert.assertNotNull(list);
    }

    @Test
    public void testFindListByPayTimeCount() {
        RefundDetail refundDetail = new RefundDetail();
        refundDetail.setChannel(Channel.ALIPAY.getValue());
        refundDetail.setStatus(2);
        refundDetail.setRefundTransactionId(12345678999L);
        refundDetail.setOrderId(123456789L);
        dao.insert(refundDetail);
        int num = dao.findListByPayTimeCount(NOW_TIMESTAMP - 10000000, NOW_TIMESTAMP + 10000000);
        Assert.assertNotNull(num);
    }

    @Test
    public void testQuerySuccessRefundDetailList() {
        List<RefundDetail> data = new ArrayList<>();
        RefundDetail trs = new RefundDetail();
        data.add(trs);
        long beginTime = 14587878788l;
        long endTime = 14987878788l;

        Integer num2 = dao.findListByPayTimeCount(beginTime, endTime);
        List<RefundDetail> data2 = dao.findListByPayTime(beginTime, endTime, 0, 10);

        Assert.assertNotNull(num2);
        Assert.assertNotNull(data2);
    }

    @Test
    public void testFindByOrderId() {
        testInsert();
        RefundDetail refundDetail = dao.findByOrderId(12345L);
        Assert.assertNotNull(refundDetail);
        Assert.assertEquals(88888888L, refundDetail.getRefundTransactionId());
    }

    @Test
    public void testFindRefund() {
        testInsert();
        List<RefundDetail> list = dao.findByTimeSpanAndStatus(System.currentTimeMillis() - 60 * 1000L,
                System.currentTimeMillis() + 24 * 60 * 60 * 1000L, -1, 0, 50);
        Assert.assertNotNull(list);
        Assert.assertEquals(1, list.size());
        Assert.assertEquals(12345L, list.get(0).getOrderId());
    }
}
