package com.xiaomi.mifi.payment.dao;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.xiaomi.mifi.payment.thrift.Notify;

/**
 * Created by mars on 17-4-24.
 */

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:applicationContext.xml")
public class NotifyDAOTest extends BaseDAOTest {
    private static final Logger LOGGER = LoggerFactory.getLogger(NotifyDAOTest.class);
    @Autowired
    NotifyDAO dao;

    @Override
    @Before
    public void setUp() throws Exception {
        super.setUp();
    }

    @Test
    public void testInsert() throws Exception {
        Notify notify = new Notify();
        notify.setNotifyMethodName("test notify mathod name");
        notify.setNotifyServiceName("test notify service name");
        notify.setCreateTime(System.currentTimeMillis());
        notify.setUpdateTime(System.currentTimeMillis());
        notify.setTransactionId(88888888L);
        long id = 0;
        try {
            id = dao.insert(notify);
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
        }
        Assert.assertEquals(1, id);
    }

    @Test
    public void testFind() {
        Notify notify = new Notify();
        notify.setNotifyMethodName("test notify mathod name");
        notify.setNotifyServiceName("test notify service name");
        notify.setCreateTime(System.currentTimeMillis());
        notify.setUpdateTime(System.currentTimeMillis());
        notify.setTransactionId(88888888L);
        dao.insert(notify);
        Notify notify2 = dao.findByTransactionId(88888888L);
        Assert.assertNotNull(notify2);
    }

    @Test
    public void testUpdate() {
        Notify notify = new Notify();
        notify.setNotifyMethodName("test notify mathod name");
        notify.setNotifyServiceName("test notify service name");
        notify.setCreateTime(System.currentTimeMillis());
        notify.setUpdateTime(System.currentTimeMillis());
        notify.setTransactionId(88888888L);
        dao.insert(notify);
        Notify notify2 = dao.findByTransactionId(88888888L);
        Assert.assertNotNull(notify2);
        notify2.setTransactionId(99999999L);
        dao.updateNotify(notify2);
        Notify notify3 = dao.findByTransactionId(88888888L);
        Assert.assertNull(notify3);
        Notify notify4 = dao.findByTransactionId(99999999L);
        Assert.assertNotNull(notify4);
    }
}
