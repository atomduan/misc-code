package com.xiaomi.mifi.payment.dao;

import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.xiaomi.mifi.payment.thrift.CardType;
import com.xiaomi.mifi.payment.thrift.Channel;
import com.xiaomi.mifi.payment.thrift.SupportChannels;

/**
 * Created by mars on 17-4-24.
 */

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:applicationContext.xml")
public class SupportChannelsTest extends BaseDAOTest {
    private static final Logger LOGGER = LoggerFactory.getLogger(SupportChannelsTest.class);
    @Autowired
    SupportChannelsDAO dao;

    @Override
    @Before
    public void setUp() throws Exception {
        super.setUp();
    }

    @Test
    public void testInsert() throws Exception {
        SupportChannels supportChannels = new SupportChannels();
        supportChannels.setChannel(Channel.ALIPAY.getValue());
        supportChannels.setCardType(CardType.DEBIT.getValue());
        supportChannels.setOrderId(12345L);
        supportChannels.setTransactionId(88888888L);
        long id = 0;
        try {
            id = dao.insert(supportChannels);
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
        }
        Assert.assertEquals(1, id);
    }

    @Test
    public void testFind() {
        SupportChannels supportChannels = new SupportChannels();
        supportChannels.setChannel(Channel.ALIPAY.getValue());
        supportChannels.setCardType(CardType.DEBIT.getValue());
        supportChannels.setOrderId(12345L);
        supportChannels.setTransactionId(88888888L);
        dao.insert(supportChannels);
        List<SupportChannels> supportChannelsList = dao.findByOrderId(12345L);
        Assert.assertNotNull(supportChannelsList);
        Assert.assertEquals(1, supportChannelsList.size());
    }

    @Test
    public void testUpdate() {
        SupportChannels supportChannels = new SupportChannels();
        supportChannels.setChannel(Channel.ALIPAY.getValue());
        supportChannels.setCardType(CardType.DEBIT.getValue());
        supportChannels.setOrderId(12345L);
        supportChannels.setTransactionId(88888888L);
        dao.insert(supportChannels);
        List<SupportChannels> supportChannelsList = dao.findByOrderId(12345L);
        Assert.assertNotNull(supportChannelsList);
        Assert.assertEquals(1, supportChannelsList.size());
        SupportChannels sc = supportChannelsList.get(0);
        sc.setTransactionId(54321L);
        dao.updateSupportChannels(sc);
        List<SupportChannels> supportChannelsList2 = dao.findByOrderId(12345L);
        Assert.assertNotNull(supportChannelsList2);
        Assert.assertEquals(1, supportChannelsList2.size());
        SupportChannels sc2 = supportChannelsList2.get(0);
        Assert.assertEquals(54321L, sc2.getTransactionId());
    }
}
