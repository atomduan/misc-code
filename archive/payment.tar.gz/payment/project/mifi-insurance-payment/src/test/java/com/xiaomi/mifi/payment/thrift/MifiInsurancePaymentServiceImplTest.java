package com.xiaomi.mifi.payment.thrift;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyMap;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import java.util.HashMap;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import com.xiaomi.mifi.insurance.payment.thrift.TPSubmitPayment;
import com.xiaomi.mifi.payment.service.ServiceProxy;

@RunWith(MockitoJUnitRunner.class)
public class MifiInsurancePaymentServiceImplTest {

    @InjectMocks
    private MifiInsurancePaymentServiceImpl mifiInsurancePaymentService;

    @Mock
    private ServiceProxy serviceProxy;

    @Test
    public void submitPayment() throws Exception {
        mifiInsurancePaymentService.submitPayment(new TPSubmitPayment());
        verify(serviceProxy, times(1)).submitPayment(any(TPSubmitPayment.class));
    }

    @Test
    public void notifyCashpayPay() throws Exception {
        mifiInsurancePaymentService.notifyCashpayPay(new HashMap<String, String>());
        verify(serviceProxy, times(1)).notifyCashpayPay(anyMap());
    }

    @Test
    public void notifyCashpayRefund() throws Exception {
        mifiInsurancePaymentService.notifyCashpayRefund(new HashMap<String, String>());
        verify(serviceProxy, times(1)).notifyCashpayRefund(anyMap());
    }

    @Test
    public void asyncNotifyAlipayPay() throws Exception {
        mifiInsurancePaymentService.asyncNotifyAlipayPay(new HashMap<String, String>());
        verify(serviceProxy, times(1)).notifyAlipayPay(anyMap());
    }

}
