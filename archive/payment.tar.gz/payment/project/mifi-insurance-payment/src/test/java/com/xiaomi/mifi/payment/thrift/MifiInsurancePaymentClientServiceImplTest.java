package com.xiaomi.mifi.payment.thrift;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyLong;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.xiaomi.mifi.insurance.common.util.exception.ErrorCode;
import com.xiaomi.mifi.payment.service.ClientServiceProxy;
import com.xiaomi.mifi.payment.util.ResponseUtils;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import com.xiaomi.mifi.payment.model.PaymentChannel;
import com.xiaomi.mifi.payment.service.ServiceProxy;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by mars on 17-4-18.
 */
@RunWith(MockitoJUnitRunner.class)
public class MifiInsurancePaymentClientServiceImplTest {
    @InjectMocks
    private MifiInsurancePaymentClientServiceImpl mifiInsurancePaymentClientService;

    @Mock
    ClientServiceProxy clientServiceProxy;

    @Mock
    private ServiceProxy serviceProxy;

    @Test
    public void commitPay() throws Exception {
        mifiInsurancePaymentClientService.commitPay(new TPPay());
        verify(clientServiceProxy, times(1)).commitPay(any(TPPay.class));
    }

    @Test
    public void refund() throws Exception {
        mifiInsurancePaymentClientService.refund(new TPRefund());
        verify(serviceProxy, times(1)).refund(any(TPRefund.class));
    }

    @Test
    public void queryPaymentInfo() throws Exception {
        mifiInsurancePaymentClientService.queryPaymentInfo(123L);
        verify(serviceProxy, times(1)).queryPaymentInfo(anyLong());
    }

    @Test
    public void queryTradeDetails() throws Exception {
        TRTradeDetailList trTradeDetailList = new TRTradeDetailList();
        trTradeDetailList.setResponse(ResponseUtils.getResponse(ErrorCode.SUCCESS));
        List<TradeDetail> tradeDetails = new ArrayList<>();
        TradeDetail tradeDetail = new TradeDetail();
        tradeDetail.setOrderId(12345L);
        tradeDetails.add(tradeDetail);
        trTradeDetailList.setDetails(tradeDetails);
        when(serviceProxy.queryTradeDetails(111L, 222L, TradeStatus.SUCCESS, 0, 30)).thenReturn(trTradeDetailList);
        mifiInsurancePaymentClientService.queryTradeDetailsUsingPage(111L, 222L, TradeStatus.SUCCESS, 0, 30);
        verify(serviceProxy, times(1)).queryTradeDetails(111L, 222L, TradeStatus.SUCCESS, 0, 30);
    }

    @Test
    public void querySuccessTradeDetails() throws Exception {
        TRTradeDetailList trTradeDetailList = new TRTradeDetailList();
        trTradeDetailList.setResponse(ResponseUtils.getSuccessResponse());
        List<TradeDetail> list = new ArrayList<>();
        TradeDetail tradeDetail = new TradeDetail();
        tradeDetail.setOrderId(12345L);
        list.add(tradeDetail);
        trTradeDetailList.setDetails(list);
        when(serviceProxy.querySuccessTradeDetails(111L, 222L, 1)).thenReturn(trTradeDetailList);
        TRTradeDetailList ret = mifiInsurancePaymentClientService.querySuccessTradeDetails(111L, 222L, PaymentChannel.ALIPAY.getIndex());
        verify(serviceProxy, times(1)).querySuccessTradeDetails(111L, 222L, PaymentChannel.ALIPAY.getIndex());
        Assert.assertTrue(ret.getResponse().isSuccess());
        Assert.assertEquals(12345L, ret.getDetails().get(0).getOrderId());
    }

    @Test
    public void querySuccessTradeRefundDetails() throws Exception {
        TRDetailListRequest request = new TRDetailListRequest();
        request.setBeginTime(111L);
        request.setEndTime(222L);
        request.setTradeType(TradeType.REFUND.getValue());
        request.setStart(0);
        request.setLength(20);
        mifiInsurancePaymentClientService.querySuccessTradeRefundDetails(request);
        verify(serviceProxy, times(1)).querySuccessTradeRefundDetails(any(TRDetailListRequest.class));
    }
}
