package com.xiaomi.mifi.payment.service;

import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Matchers.anyLong;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.xiaomi.mifi.insurance.payment.thrift.*;
import com.xiaomi.mifi.payment.thrift.*;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.xiaomi.mifi.common.thrift.model.TRResponse;
import com.xiaomi.mifi.insurance.common.util.exception.ErrorCode;
import com.xiaomi.mifi.insurance.common.util.exception.ServiceLogicException;
import com.xiaomi.mifi.payment.biz.DeductBiz;
import com.xiaomi.mifi.payment.biz.NotifyBiz;
import com.xiaomi.mifi.payment.biz.RefundBiz;
import com.xiaomi.mifi.payment.biz.StatisticBiz;
import com.xiaomi.mifi.payment.biz.SupportChannelsBiz;
import com.xiaomi.mifi.payment.biz.TradeBiz;
import com.xiaomi.mifi.payment.biz.facade.AlipayPaymentFacade;
import com.xiaomi.mifi.payment.biz.facade.MiCashPaymentFacade;
import com.xiaomi.mifi.payment.biz.facade.PaymentFacadeRegistry;
import com.xiaomi.mifi.payment.exception.PaymentGatewayResponseException;
import com.xiaomi.mifi.payment.exception.PaymentInternalException;
import com.xiaomi.mifi.payment.gateway.MiCashpayPaymentGateway;
import com.xiaomi.mifi.payment.gateway.PaymentGateway;
import com.xiaomi.mifi.payment.gateway.PaymentGatewayRegistry;
import com.xiaomi.mifi.payment.model.CommitPayRequest;
import com.xiaomi.mifi.payment.model.CommitPayResult;
import com.xiaomi.mifi.payment.model.PaymentChannel;
import com.xiaomi.mifi.payment.thrift.RefundDetail;
import com.xiaomi.mifi.payment.thrift.TradeDetail;
import com.xiaomi.mifi.payment.util.ConvertUtils;
import com.xiaomi.mifi.payment.util.ResponseUtils;
import com.xiaomi.mifi.payment.util.ValidateUtils;

@RunWith(PowerMockRunner.class)
@PrepareForTest({ValidateUtils.class, ConvertUtils.class})
public class ServiceProxyTest {
    @InjectMocks
    ServiceProxy serviceProxy;
    @Mock
    private PaymentGatewayRegistry registry;
    private TPWithdrawRequest request;
    private PaymentGateway paymentGateway;
    private Map<PaymentRequestParam, String> params;
    private Map<PaymentResponseParam, String> responseValues;
    @Mock
    private TradeBiz tradeBiz;

    @Mock
    private RefundBiz refundBiz;

    @Mock
    private NotifyBiz notifyBiz;

    @Mock
    private DeductBiz deductBiz;

    @Mock
    private SupportChannelsBiz supportChannelsBiz;

    @Mock
    private PaymentFacadeRegistry paymentFacadeRegistry;

    @Mock
    private AlipayPaymentFacade alipayPaymentFacade;

    @Mock
    private MiCashPaymentFacade miCashPaymentFacade;

    @Mock
    private StatisticBiz statisticBiz;

    @Before
    public void init() {
        PowerMockito.mockStatic(ConvertUtils.class);
        PowerMockito.mockStatic(ValidateUtils.class);
    }

    @Test
    public void testPaymentGatewayIsNull() {
        when(registry.getPaymentGateway(any(PaymentGatewayName.class))).thenReturn(null);
        serviceProxy = new ServiceProxy();
        serviceProxy.registry = registry;
        request = new TPWithdrawRequest();
        PaymentGatewayName gateway = PaymentGatewayName.CASHPAY;
        request.setGateway(gateway);
        assertEquals(ErrorCode.GATEWAY_NOT_FOUND.code, serviceProxy.requestWithdraw(request).getResponse().code);
        verify(registry).getPaymentGateway(gateway);
    }

    @Test
    public void testParamsIsNull() throws Exception {
        serviceProxy = new ServiceProxy();
        serviceProxy.registry = registry;
        request = new TPWithdrawRequest();
        PaymentGatewayName gateway = PaymentGatewayName.CASHPAY;
        request.setGateway(gateway);
        paymentGateway = new MiCashpayPaymentGateway();
        when(registry.getPaymentGateway(gateway)).thenReturn(paymentGateway);
        assertEquals(ErrorCode.MISS_PARAM.code, serviceProxy.requestWithdraw(request).getResponse().code);
        verify(registry).getPaymentGateway(gateway);
    }

    @Test
    public void testRequestWithdraw() throws PaymentGatewayResponseException, ServiceLogicException {
        serviceProxy = new ServiceProxy();
        serviceProxy.registry = registry;
        request = new TPWithdrawRequest();
        PaymentGatewayName gateway = PaymentGatewayName.CASHPAY;
        request.setGateway(gateway);
        params = new HashMap<>();
        request.setParams(params);
        paymentGateway = mock(PaymentGateway.class);
        when(registry.getPaymentGateway(gateway)).thenReturn(paymentGateway);
        responseValues = new HashMap<>();
        when(paymentGateway.applyWithdraw(params)).thenReturn(responseValues);
        assertEquals(ResponseUtils.getSuccessResponse(), serviceProxy.requestWithdraw(request).getResponse());
        verify(registry).getPaymentGateway(gateway);
        verify(paymentGateway).applyWithdraw(params);
    }

    @Test
    public void testRefundRepeatedRefund() throws PaymentInternalException {
        when(refundBiz.findRefundByOrderId(anyInt())).thenReturn(new RefundDetail());
        PowerMockito.when(ValidateUtils.validateTPRefund(any(TPRefund.class))).thenReturn(true);
        assertEquals(ErrorCode.REPEATED_REFUND.code, serviceProxy.refund(new TPRefund()).getResponse().getCode());
    }

    @Test
    public void testRefundRepeatedNotify() throws PaymentInternalException {
        when(refundBiz.findRefundByOrderId(anyLong())).thenReturn(null);
        when(notifyBiz.findNotifyByOrderId(anyLong(), anyInt())).thenReturn(new Notify());
        PowerMockito.when(ValidateUtils.validateTPRefund(any(TPRefund.class))).thenReturn(true);
        assertEquals(ErrorCode.INCORRECT_TRANSACTION_STATUS.code,
                serviceProxy.refund(new TPRefund()).getResponse().getCode());
    }

    @Test
    public void testRefundOrderNotExists() throws PaymentInternalException {
        when(refundBiz.findRefundByOrderId(anyLong())).thenReturn(null);
        when(notifyBiz.findNotifyByOrderId(anyLong(), anyInt())).thenReturn(null);
        when(tradeBiz.queryPaymentInfo(anyLong())).thenReturn(null);
        when(deductBiz.findByOrderId(anyLong())).thenReturn(null);
        PowerMockito.when(ValidateUtils.validateTPRefund(any(TPRefund.class))).thenReturn(true);
        assertEquals(ErrorCode.ORDER_NOT_FOUND.code, serviceProxy.refund(new TPRefund()).getResponse().getCode());
    }

    @Test
    public void testQueryPaymentInfo() {
        when(tradeBiz.queryPaymentInfo(anyLong())).thenReturn(new TradeDetail());
        serviceProxy.queryPaymentInfo(12345L);
        verify(tradeBiz, times(1)).queryPaymentInfo(anyLong());
    }

    @Test
    public void testQueryTradeDetails() {
        long now = System.currentTimeMillis();
        List<TradeDetail> list = new ArrayList<>();
        TradeDetail tradeDetail = new TradeDetail();
        tradeDetail.setOrderId(12345L);
        list.add(tradeDetail);
        when(tradeBiz.queryTradeDetails(now, now + 1000L, TradeStatus.SUCCESS, 0, 30)).thenReturn(list);
        TRTradeDetailList trTradeDetailList = serviceProxy.queryTradeDetails(now, now + 1000L, TradeStatus.SUCCESS, 0, 30);
        verify(tradeBiz, times(1)).queryTradeDetails(now, now + 1000L, TradeStatus.SUCCESS, 0, 30);
        Assert.assertTrue(trTradeDetailList.getResponse().isSuccess());
        Assert.assertEquals(12345L, trTradeDetailList.getDetails().get(0).getOrderId());
    }

    @Test
    public void testSubmitPayNotFound() {
        TPSubmitPayment tpSubmitPayment = new TPSubmitPayment();
        tpSubmitPayment.setPrepayId("12345");
        String sign = "valid sign";
        tpSubmitPayment.setSign(sign);
        when(tradeBiz.verifyTrade(12345L, sign)).thenReturn(true);
        when(tradeBiz.findByTransactionId(anyLong())).thenReturn(null);
        PowerMockito.when(ValidateUtils.validateTPSubmitPayment(any(TPSubmitPayment.class))).thenReturn(true);
        assertEquals(ErrorCode.ORDER_NOT_FOUND.code,
                serviceProxy.submitPayment(tpSubmitPayment).getResponse().getCode());
        verify(tradeBiz).verifyTrade(12345L, sign);
    }

    @Test
    public void testSubmitPayAlreadySuccess() {
        TPSubmitPayment tpSubmitPayment = new TPSubmitPayment();
        tpSubmitPayment.setPrepayId("12345");
        String sign = "valid sign";
        tpSubmitPayment.setSign(sign);
        TradeDetail tradeDetail = new TradeDetail();
        tradeDetail.setTradeStatus(TradeStatus.SUCCESS.getValue());
        when(tradeBiz.verifyTrade(12345L, sign)).thenReturn(true);
        when(tradeBiz.findByTransactionId(anyLong())).thenReturn(tradeDetail);
        PowerMockito.when(ValidateUtils.validateTPSubmitPayment(any(TPSubmitPayment.class))).thenReturn(true);
        assertEquals(ErrorCode.ORDER_PAY_SUCCESS.code,
                serviceProxy.submitPayment(tpSubmitPayment).getResponse().getCode());
        verify(tradeBiz).verifyTrade(12345L, sign);
    }

    @Test
    public void testSubmitPayMatchChannel() throws Exception {
        TPSubmitPayment tpSubmitPayment = new TPSubmitPayment();
        tpSubmitPayment.setPrepayId("12345");
        tpSubmitPayment.setChannelId(1L);
        String sign = "valid sign";
        tpSubmitPayment.setSign(sign);
        TradeDetail tradeDetail = new TradeDetail();
        tradeDetail.setTradeStatus(TradeStatus.INIT.getValue());
        when(tradeBiz.verifyTrade(12345L, sign)).thenReturn(true);
        when(tradeBiz.findByTransactionId(anyLong())).thenReturn(tradeDetail);
        when(notifyBiz.findNotifyByTransactionId(anyLong())).thenReturn(new Notify());
        when(tradeBiz.updateTradeDetail(tradeDetail)).thenReturn(1);
        List<SupportChannels> supportChannels = new ArrayList<>();
        SupportChannels supportChannels1 = new SupportChannels();
        supportChannels1.setChannel(Channel.ALIPAY.getValue());
        supportChannels1.setCardType(CardType.CREDIT.getValue());
        supportChannels.add(supportChannels1);
        when(supportChannelsBiz.querySupportChannels(anyLong())).thenReturn(supportChannels);
        when(tradeBiz.submitTrade(tradeDetail, 1)).thenReturn(true);
        when(paymentFacadeRegistry.getPaymentFacade(any(PaymentChannel.class))).thenReturn(alipayPaymentFacade);
        CommitPayResult commitPayResult = new CommitPayResult();
        commitPayResult.setSuccess(true);
        CommitPayRequest commitPayRequest = new CommitPayRequest();
        when(alipayPaymentFacade.generatePayment(tradeDetail)).thenReturn(commitPayRequest);
        when(alipayPaymentFacade.commitPay(any(CommitPayRequest.class))).thenReturn(commitPayResult);
        PowerMockito.when(ValidateUtils.validateTPPay(any(TPPay.class))).thenReturn(true);
        PowerMockito.when(ValidateUtils.validateTPSubmitPayment(any(TPSubmitPayment.class))).thenReturn(true);
        serviceProxy.submitPayment(tpSubmitPayment);
        verify(tradeBiz).verifyTrade(12345L, sign);
        verify(tradeBiz).submitTrade(tradeDetail, 1);
        verify(alipayPaymentFacade).generatePayment(tradeDetail);
        verify(alipayPaymentFacade, times(1)).commitPay(any(CommitPayRequest.class));
    }

    @Test
    public void testSubmitPayment() throws Exception {
        TPSubmitPayment tpSubmitPayment = new TPSubmitPayment();
        tpSubmitPayment.setPrepayId("12345");
        tpSubmitPayment.setChannelId(4L);
        String sign = "valid sign";
        tpSubmitPayment.setSign(sign);
        TradeDetail tradeDetail = new TradeDetail();
        tradeDetail.setTradeStatus(TradeStatus.INIT.getValue());
        when(tradeBiz.verifyTrade(12345L, sign)).thenReturn(true);
        when(tradeBiz.findByTransactionId(anyLong())).thenReturn(tradeDetail);
        when(tradeBiz.updateTradeDetail(tradeDetail)).thenReturn(1);
        List<SupportChannels> supportChannels = new ArrayList<>();
        SupportChannels supportChannels1 = new SupportChannels();
        supportChannels1.setChannel(Channel.ALIPAY.getValue());
        supportChannels1.setCardType(2);
        supportChannels.add(supportChannels1);
        SupportChannels supportChannels2 = new SupportChannels();
        supportChannels2.setChannel(Channel.CASHPAY.getValue());
        supportChannels2.setCardType(2);
        supportChannels.add(supportChannels2);
        when(supportChannelsBiz.querySupportChannels(anyLong())).thenReturn(supportChannels);
        when(tradeBiz.submitTrade(tradeDetail, 4)).thenReturn(true);
        when(paymentFacadeRegistry.getPaymentFacade(any(PaymentChannel.class))).thenReturn(miCashPaymentFacade);
        CommitPayResult commitPayResult = new CommitPayResult();
        commitPayResult.setSuccess(true);
        CommitPayRequest commitPayRequest = new CommitPayRequest();
        when(miCashPaymentFacade.generatePayment(tradeDetail)).thenReturn(commitPayRequest);
        when(miCashPaymentFacade.commitPay(any(CommitPayRequest.class))).thenReturn(commitPayResult);
        PowerMockito.when(ValidateUtils.validateTPPay(any(TPPay.class))).thenReturn(true);
        PowerMockito.when(ValidateUtils.validateTPSubmitPayment(any(TPSubmitPayment.class))).thenReturn(true);
        serviceProxy.submitPayment(tpSubmitPayment);
        verify(tradeBiz).verifyTrade(12345L, sign);
        verify(tradeBiz).submitTrade(tradeDetail, 4);
        verify(miCashPaymentFacade).generatePayment(tradeDetail);
        verify(miCashPaymentFacade, times(1)).commitPay(any(CommitPayRequest.class));
    }

    @Test
    public void testSubmitPaymentInvalidSign() throws Exception {
        TPSubmitPayment tpSubmitPayment = new TPSubmitPayment();
        tpSubmitPayment.setPrepayId("12345");
        tpSubmitPayment.setChannelId(4L);
        String sign = "invalid valid sign";
        tpSubmitPayment.setSign(sign);
        PowerMockito.when(ValidateUtils.validateTPSubmitPayment(any(TPSubmitPayment.class))).thenReturn(true);
        when(tradeBiz.verifyTrade(12345L, sign)).thenReturn(false);
        TRSubmitPayment response = serviceProxy.submitPayment(tpSubmitPayment);
        verify(tradeBiz).verifyTrade(12345L, sign);
        Assert.assertEquals(ErrorCode.INVALID_PARAM.code, response.getResponse().code);
    }

    public void testQuerySuccessTradeRefundDetails() throws Exception{
        TRDetailListResponse response1 = new TRDetailListResponse();
        TRDetailListResponse response2 = new TRDetailListResponse();
        TRDetailListRequest request = new TRDetailListRequest();
        when(tradeBiz.querySuccessTradeDetailList(request)).thenReturn(response1);
        when(refundBiz.querySuccessRefundDetailList(request)).thenReturn(response2);

        TRDetailListResponse tradeList2 = tradeBiz.querySuccessTradeDetailList(request);
        TRDetailListResponse refundList2 =refundBiz.querySuccessRefundDetailList(request);

        verify(tradeBiz).querySuccessTradeDetailList(request);
        verify(refundBiz).querySuccessRefundDetailList(request);

        assertEquals(response1, tradeList2);
        assertEquals(response2, refundList2);
    }

    @Test
    public void testRefundNotSuccess() throws PaymentInternalException {
        TPRefund tpRefund = new TPRefund();
        when(refundBiz.findRefundByOrderId(anyInt())).thenReturn(null);
        when(notifyBiz.findNotifyByOrderId(anyLong(), anyInt())).thenReturn(null);
        TradeDetail tradeDetail = new TradeDetail();
        tradeDetail.setPaymentStatus(PaymentStatus.COMMIT.getValue());
        tradeDetail.setTradeStatus(TradeStatus.INIT.getValue());
        when(tradeBiz.queryPaymentInfo(anyLong())).thenReturn(new TradeDetail());
        PowerMockito.when(ValidateUtils.validateTPRefund(any(TPRefund.class))).thenReturn(true);
        Assert.assertEquals(ErrorCode.INCORRECT_TRANSACTION_STATUS.code,
                serviceProxy.refund(tpRefund).getResponse().getCode());
    }

    @Test
    public void testRefundFeeNotEqual() throws PaymentInternalException {
        TPRefund tpRefund = new TPRefund();
        tpRefund.setAmount(1234L);
        when(refundBiz.findRefundByOrderId(anyInt())).thenReturn(null);
        when(notifyBiz.findNotifyByOrderId(anyLong(), anyInt())).thenReturn(null);
        TradeDetail tradeDetail = new TradeDetail();
        tradeDetail.setTotalFee(1233L);
        tradeDetail.setPaymentStatus(PaymentStatus.SUCCESS.getValue());
        tradeDetail.setTradeStatus(TradeStatus.SUCCESS.getValue());
        when(tradeBiz.queryPaymentInfo(anyLong())).thenReturn(new TradeDetail());
        Assert.assertEquals(ErrorCode.PARAMETER_ERROR.code, serviceProxy.refund(tpRefund).getResponse().getCode());
    }
    @Test
    public void notifyCashpayPay() throws Exception {
        when(paymentFacadeRegistry.getPaymentFacade(PaymentChannel.MICASH)).thenReturn(miCashPaymentFacade);
        Assert.assertFalse(serviceProxy.notifyCashpayPay(new HashMap<String, String>()));
    }

    @Test
    public void notifyCashpayRefund() throws Exception {
        when(paymentFacadeRegistry.getPaymentFacade(PaymentChannel.MICASH)).thenReturn(miCashPaymentFacade);
        Assert.assertFalse(serviceProxy.notifyCashpayRefund(new HashMap<String, String>()));
    }

    @Test
    public void asyncNotifyAlipayPay() throws Exception {
        Assert.assertFalse(serviceProxy.notifyAlipayPay(new HashMap<String, String>()));
    }

    @Test
    public void receiveReturnUrl() throws Exception {
        Map<String, String> map = new HashMap<>();
        map.put("channel", "1");
        map.put("out_trade_no", "12345678");
        TradeDetail tradeDetail = new TradeDetail();
        tradeDetail.setTransactionId(12345678L);
        tradeDetail.setReturnUrl("testUrl");
        when(paymentFacadeRegistry.getPaymentFacade(PaymentChannel.ALIPAY)).thenReturn(alipayPaymentFacade);
        when(alipayPaymentFacade.getTradeDetailFromReturnParam(map)).thenReturn(tradeDetail);
        TRReturnResponse trReturnResponse = serviceProxy.receiveReturnUrl(map);
        verify(paymentFacadeRegistry, times(1)).getPaymentFacade(PaymentChannel.ALIPAY);
        verify(alipayPaymentFacade, times(1)).getTradeDetailFromReturnParam(map);
        Assert.assertEquals(ErrorCode.SUCCESS.code, trReturnResponse.getResponse().getCode());
    }

    @Test
    public void receiveReturnUrlForCashPay() throws Exception{
        Map<String, String> map = new HashMap<>();
        map.put("channel", "4");
        map.put("outOrderId", "12345678");
        TradeDetail tradeDetail = new TradeDetail();
        tradeDetail.setTransactionId(12345678L);
        tradeDetail.setReturnUrl("testUrl");
        when(paymentFacadeRegistry.getPaymentFacade(PaymentChannel.MICASH)).thenReturn(miCashPaymentFacade);
        when(miCashPaymentFacade.getTradeDetailFromReturnParam(map)).thenReturn(tradeDetail);
        TRReturnResponse trReturnResponse = serviceProxy.receiveReturnUrl(map);
        verify(paymentFacadeRegistry, times(1)).getPaymentFacade(PaymentChannel.MICASH);
        verify(miCashPaymentFacade, times(1)).getTradeDetailFromReturnParam(map);
        Assert.assertEquals(ErrorCode.SUCCESS.code, trReturnResponse.getResponse().getCode());
    }

    @Test
    public void testSetExpiredTrade() {
        long transactionId = 88888888L;
        when(tradeBiz.isExpiredAndUpdate(transactionId)).thenReturn(true);
        when(tradeBiz.findByTransactionId(transactionId)).thenReturn(new TradeDetail());
        when(tradeBiz.setTradeExpired(transactionId)).thenReturn(ResponseUtils.getSuccessResponse());
        TRResponse trResponse = serviceProxy.setTradeExpired(transactionId);
        Assert.assertTrue(trResponse.isSuccess());
    }

    @Test
    public void testQueryOrderStatus() {
        TradeDetail tradeDetail = new TradeDetail();
        tradeDetail.setOrderId(12345L);
        RefundDetail refundDetail = new RefundDetail();
        refundDetail.setOrderId(12345L);
        when(tradeBiz.queryPaymentInfo(12345L)).thenReturn(tradeDetail);
        when(refundBiz.findRefundByOrderId(12345L)).thenReturn(refundDetail);
        com.xiaomi.mifi.insurance.payment.thrift.TradeDetail td = new com.xiaomi.mifi.insurance.payment.thrift.TradeDetail();
        td.setOrderId(tradeDetail.getOrderId());
        com.xiaomi.mifi.insurance.payment.thrift.RefundDetail rd = new com.xiaomi.mifi.insurance.payment.thrift.RefundDetail();
        rd.setOrderId(refundDetail.getOrderId());
        PowerMockito.when(ConvertUtils.convertTradeDetail(tradeDetail)).thenReturn(td);
        PowerMockito.when(ConvertUtils.convertRefundDetail(refundDetail)).thenReturn(rd);
        TRQueryOrderStatus trQueryOrderStatus = serviceProxy.queryOrderStatus(12345L);
        Assert.assertTrue(trQueryOrderStatus.getResponse().isSuccess());
        Assert.assertEquals(12345L, trQueryOrderStatus.getTradeDetail().getOrderId());
        Assert.assertEquals(12345L, trQueryOrderStatus.getRefundDetail().getOrderId());
    }

    @Test
    public void testReportPaymentStatistic() {
        PaymentStatistic paymentStatistic = new PaymentStatistic();
        paymentStatistic.setDate("2017年5月25日");
        paymentStatistic.setChannel(Channel.ALIPAY.getValue());
        paymentStatistic.setResultType(TradeStatus.SUCCESS.getValue());
        paymentStatistic.setCount(8);
        PaymentStatistic paymentStatistic2 = new PaymentStatistic();
        paymentStatistic2.setDate("2017年5月25日");
        paymentStatistic2.setChannel(Channel.CASHPAY.getValue());
        paymentStatistic2.setResultType(TradeStatus.FAIL.getValue());
        paymentStatistic2.setCount(5);
        when(statisticBiz.reportDailyStatistic(paymentStatistic)).thenReturn(1L);
        when(statisticBiz.reportDailyStatistic(paymentStatistic2)).thenReturn(2L);
        List<PaymentStatistic> list = new ArrayList<>();
        list.add(paymentStatistic);
        list.add(paymentStatistic2);
        Assert.assertTrue(serviceProxy.reportDailyStatistic(list));
    }
}
