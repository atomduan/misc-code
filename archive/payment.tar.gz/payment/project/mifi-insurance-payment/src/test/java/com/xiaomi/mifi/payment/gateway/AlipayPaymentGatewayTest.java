package com.xiaomi.mifi.payment.gateway;

import java.util.HashMap;

import org.junit.Assert;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.mifi.insurance.payment.util.ResponseStatus;
import com.xiaomi.mifi.insurance.payment.thrift.PaymentRequestParam;
import com.xiaomi.mifi.insurance.payment.thrift.RefundRequestParam;
import com.xiaomi.mifi.payment.model.PayResult;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:applicationContext.xml")
public class AlipayPaymentGatewayTest {

    private static final Logger LOGGER = LoggerFactory.getLogger(AlipayPaymentGatewayTest.class);

    @Autowired
    AlipayPaymentGateway gateway;

    @Test
    public void pay() throws Exception {
        HashMap<PaymentRequestParam, String> params = new HashMap<>();
        String transactionId = System.currentTimeMillis() + "";
        String subject = "test中文";
        String description = "test description中文";
        String amount = "1.00";
        String notifyUrl = "http://ins.staging.mifi.pt.xiaomi.com/api/notify/alipay/pay";
        String returnUrl = "http://staging.mifi.pt.xiaomi.com/cashpay/xxx";

        params.put(PaymentRequestParam.MERCHANT_TRANSACTION_ID, transactionId);
        params.put(PaymentRequestParam.PAY_SUBJECT, subject);
        params.put(PaymentRequestParam.PAY_DESCRIPTION, description);
        params.put(PaymentRequestParam.PAY_AMOUNT, amount);
        params.put(PaymentRequestParam.NOTIFY_URL, notifyUrl);
        params.put(PaymentRequestParam.RETURN_URL, returnUrl);
        String response = gateway.createPayRequest(params);

        LOGGER.debug("get response: {}", response);
        Assert.assertNotNull(response);
    }

    @Ignore
    @Test
    public void refund() throws Exception {
        HashMap<RefundRequestParam, String> params = new HashMap<>();
        String transactionId = System.currentTimeMillis() + "";
        params.put(RefundRequestParam.OUTER_ORDER_ID, "391720703193251840");
        params.put(RefundRequestParam.REFUND_AMOUNT, "98.90");
        String response = gateway.createRefundRequest(params);
        JsonObject jo = new JsonParser().parse(response).getAsJsonObject().get("alipay_trade_refund_response")
                .getAsJsonObject();
        LOGGER.info(jo.toString());
        Assert.assertNotNull(response);
    }

    @Test
    public void parsePayNotify() throws Exception {
        HashMap<String, String> params = new HashMap<>();
        params.put("body", "test description中文");
        params.put("subject", "test中文");
        params.put("sign_type", "RSA2");
        params.put("buyer_logon_id", "liu***@sandbox.com");
        params.put("notify_type", "trade_status_sync");
        params.put("out_trade_no", "1494305279374");
        params.put("point_amount", "0.00");
        params.put("version", "1.0");
        params.put("fund_bill_list", "[{\"amount\":\"1.00\",\"fundChannel\":\"ALIPAYACCOUNT\"}]");
        params.put("total_amount", "1.00");
        params.put("buyer_id", "2088102172232701");
        params.put("trade_no", "2017050921001004700201157334");
        params.put("notify_time", "2017-05-09 12:48:47");
        params.put("charset", "UTF-8");
        params.put("invoice_amount", "1.00");
        params.put("trade_status", "TRADE_SUCCESS");
        params.put("gmt_payment", "2017-05-09 12:48:46");
        params.put("sign", "hNX+by2wdhnMjgagU9bNGnW9Om75vAv+pMDfKi0adLVjiLYHJw6GcVeWyq3TPRP6UpidaPzOE7tGqnr3QB2pdpMxbEGAx8ctQJNsoQUlEC76pLloyvodQRxHIuoM6vEuRCUs2wa9lYax9lp0hC5rUxD+imLhLKxcEBjw1VHOX8DHS4prpjOum7Y5NF5kjmc0oy5McflhK1gTYAPDfJJzOdHc3i4ocM0vySyyyKzwCwAMTYduE5zodjPOIFF9Q+L70q5anQ/6JP8VFPwYNK+D6d06aFmDwhxbxcWijix4EryJCsul8zumqah3/pokoaEwpDwmRIuU+Myok4Rwg+LwPg==");
        params.put("gmt_create", "2017-05-09 12:48:45");
        params.put("buyer_pay_amount", "1.00");
        params.put("receipt_amount", "1.00");
        params.put("seller_id", "2088102169640793");
        params.put("app_id", "2016080200151033");
        params.put("seller_email", "ewgofn9254@sandbox.com");
        params.put("notify_id", "eae4e2ee2d6af0443cd7f930ab55fd2lei");
        params.put("auth_app_id", "2016080200151033");

        PayResult payResult = gateway.parsePayNotify(params);
        Assert.assertEquals(ResponseStatus.STATUS_SUCCESS, payResult.getStatus());
    }

    @Test
    public void testVerifyReturnParams() {
        HashMap<String, String> params = new HashMap<>();
        params.put("total_amount", "88.88");
        params.put("timestamp", "2017-05-10 18:14:56");
        params.put("sign", "g7uIhc0J3FfObTXUd+btvQV3HiJtU9HLfHrFG2W5F/K1Ag2vVftzYLeWVdgBAUoOdgBp6QCkDuWXuf7ygeRrcoiV78vBass7P27/X6V+YP6nMEV/jhFRhwQ89upZELZ5VgVmg0WruB3SfmF1THNHMlrZsKGwBcuUYs0Nqu1qLq3nDJRetTkJcOCi/4niEoZ2dHRm9iS2QeL/EEFm89lvuxup5hj2QbfRjZG/E8n7FV7+1fmDN4Cv+S5oCXErOOa1M0IeBFyFmez9EHVcIa4Y4ks4Ic1ozfmaL+AOM4yz/9c5ay9jm14DBJSA69AVJp509VXxpBqjgY4IHrBmIW0Tjg");
        params.put("trade_no", "2017051021001004700201160371");
        params.put("sign_type", "RSA2");
        params.put("auth_app_id", "2016080200151033");
        params.put("charset", "UTF-8");
        params.put("seller_id", "2088102169640793");
        params.put("method", "alipay.trade.wap.pay.return");
        params.put("app_id", "2016080200151033");
        params.put("out_trade_no", "391750959045279748");
        params.put("version", "1.0");
        params.put("channel", "1");
        params.put("auth_app_id", "2016080200151033");
        Assert.assertTrue(gateway.parseReturnUrl(params));
    }

    // @Test
    public void testGetDownloadUrl() {
        String billType = "trade";
        String billDate = "2017-05-23";
        try {
            String result = gateway.getDownloadUrl(billType, billDate);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
