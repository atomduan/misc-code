package com.xiaomi.mifi.payment.biz;

import com.xiaomi.mifi.insurance.common.util.exception.ServiceLogicException;
import com.xiaomi.mifi.insurance.payment.thrift.*;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyLong;
import static org.mockito.Mockito.*;

import java.util.ArrayList;
import java.util.List;

import com.xiaomi.mifi.payment.dao.ChannelConfigDAO;
import com.xiaomi.mifi.payment.dao.PayChannelDAO;
import com.xiaomi.mifi.payment.proxy.BServiceProxy;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import com.xiaomi.mifi.payment.dao.SupportChannelsDAO;
import com.xiaomi.mifi.payment.thrift.SupportChannels;

/**
 * Created by mars on 17-4-26.
 */
@RunWith(MockitoJUnitRunner.class)
public class SupportChannelsBizTest {

    @InjectMocks
    private SupportChannelsBiz supportChannelsBiz;

    @Mock
    private SupportChannelsDAO supportChannelsDAO;

    @Mock
    ChannelConfigDAO channelConfigDAO;

    @Mock
    PayChannelDAO payChannelDAO;

    @Mock
    BServiceProxy bServiceProxy;

    @Test
    public void testInsert() {
        List<SupportChannels> list = new ArrayList<>();
        SupportChannels supportChannels = new SupportChannels();
        supportChannels.setTransactionId(123L);
        list.add(supportChannels);
        when(supportChannelsDAO.insert(any(SupportChannels.class))).thenReturn(1L);
        long row = supportChannelsBiz.insertSupportChannels(list);
        Assert.assertTrue(row > 0);
        verify(supportChannelsDAO, times(1)).insert(any(SupportChannels.class));
    }

    @Test
    public void testQueryChannels() {
        when(supportChannelsDAO.findByOrderId(anyLong())).thenReturn(new ArrayList<SupportChannels>());
        Assert.assertNotNull(supportChannelsBiz.querySupportChannels(12345L));
    }

    @Test
    public void testUpdateChannels() {
        SupportChannels supportChannels = new SupportChannels();
        supportChannels.setTransactionId(123L);
        when(supportChannelsDAO.updateSupportChannels(any(SupportChannels.class))).thenReturn(1);
        Assert.assertTrue(supportChannelsBiz.updateTradeDetail(supportChannels) > 0);
    }

    @Test
    public void testBitMap() {
        TPSubmitPayment tpSubmitPayment = new TPSubmitPayment();
        tpSubmitPayment.setChannelId(1L);
        int channelBitMap = 0;
        List<SupportChannels> querySupportChannels = new ArrayList<>();
        SupportChannels supportChannels = new SupportChannels();
        supportChannels.setTransactionId(123L);
        supportChannels.setChannel(1);
        supportChannels.setCardType(2);
        querySupportChannels.add(supportChannels);
        for (SupportChannels payChannel : querySupportChannels) {
            channelBitMap |= payChannel.getChannel();
        }
        Assert.assertTrue((channelBitMap & (int) tpSubmitPayment.getChannelId()) > 0);
    }

    @Test
    public void getChannelConfig() throws Exception {
        long ts = 1382313211231L;
        int tradeTypeId = TradeType.TRANSFER.getValue();
        long transactionId = 1231239821312L;

        ArrayList<ChannelConfig> configList = new ArrayList<>();
        // 添加一些channel config
        ChannelConfig config = new ChannelConfig();
        config.setId(1L);
        config.setChannelId(1);
        config.setStartTime(100000L);
        config.setEndTime(200000L);
        config.setTradeType(tradeTypeId);
        config.setPriority(9);
        config.setSubtitle("推荐1");
        configList.add(config);

        config = new ChannelConfig();
        config.setId(2L);
        config.setChannelId(2);
        config.setStartTime(120000L);
        config.setEndTime(220000L);
        config.setTradeType(tradeTypeId);
        config.setPriority(8);
        config.setSubtitle("推荐2");
        configList.add(config);

        config = new ChannelConfig();
        config.setId(3L);
        config.setChannelId(1);
        config.setStartTime(120000L);
        config.setEndTime(210000L);
        config.setTradeType(tradeTypeId);
        config.setPriority(4);
        config.setSubtitle("推荐3");
        configList.add(config);

        config = new ChannelConfig();
        config.setId(4L);
        config.setChannelId(127); // 不存在的支付渠道
        config.setStartTime(120000L);
        config.setEndTime(210000L);
        config.setTradeType(tradeTypeId);
        config.setPriority(9);
        config.setSubtitle("推荐4");
        configList.add(config);

        PayChannel channel1 = new PayChannel();
        channel1.setId(1L);
        channel1.setName("alipay");
        channel1.setDisplayName("支付宝");
        channel1.setIconUrl("http://xx.com/alipay.png");
        channel1.setChannelId(1);

        PayChannel channel2 = new PayChannel();
        channel2.setId(2L);
        channel2.setName("wxpay");
        channel2.setDisplayName("微信支付");
        channel2.setIconUrl("http://xx.com/wxpay.png");
        channel2.setChannelId(2);

        ArrayList<SupportChannels> supportChannels = new ArrayList<>();
        when(bServiceProxy.getTimestamp()).thenReturn(ts);
        // empty support channels
        when(supportChannelsDAO.findByTransactionId(transactionId)).thenReturn(supportChannels);
        try {
            supportChannelsBiz.getChannelConfig(TradeType.TRANSFER, transactionId);
            Assert.fail();
        } catch (ServiceLogicException e) {
            Assert.assertEquals(ServiceLogicException.INCORRECT_TRANSACTION_STATUS, e);
        }
        verify(supportChannelsDAO).findByTransactionId(transactionId);


        reset(bServiceProxy);
        reset(supportChannelsDAO);
        SupportChannels sc = new SupportChannels();
        sc.setTransactionId(transactionId);
        sc.setChannel(1);
        supportChannels.add(sc);

        when(bServiceProxy.getTimestamp()).thenReturn(ts);
        when(supportChannelsDAO.findByTransactionId(transactionId)).thenReturn(supportChannels);
        when(channelConfigDAO.findValidChannelsByTradeTypeAndTime(tradeTypeId, ts)).thenReturn(configList);
        when(payChannelDAO.findByChannelId(1)).thenReturn(channel1);
        when(payChannelDAO.findByChannelId(2)).thenReturn(channel2);

        List<PayChannelInfo> payChannelInfoList = supportChannelsBiz.getChannelConfig(TradeType.TRANSFER, transactionId);
        verify(bServiceProxy).getTimestamp();
        verify(supportChannelsDAO).findByTransactionId(transactionId);

        Assert.assertNotNull(payChannelInfoList);
        Assert.assertEquals(1, payChannelInfoList.size());

        PayChannelInfo one = payChannelInfoList.get(0);
        Assert.assertEquals(1, one.getChannelId());
        Assert.assertEquals("alipay", one.getName());
        Assert.assertEquals("支付宝", one.getDisplayName());
        Assert.assertEquals("推荐1", one.getSubtitle());
        Assert.assertEquals("http://xx.com/alipay.png", one.getIconUrl());
        Assert.assertTrue(one.isDefaultChannel());
    }
}
