package com.xiaomi.mifi.payment.gateway;

import com.mifi.insurance.payment.util.ResponseStatus;
import com.xiaomi.mifi.insurance.common.util.exception.ServiceLogicException;
import com.xiaomi.mifi.insurance.payment.thrift.BillType;
import com.xiaomi.mifi.insurance.payment.thrift.PaymentRequestParam;
import com.xiaomi.mifi.insurance.payment.thrift.RefundRequestParam;
import com.xiaomi.mifi.insurance.payment.thrift.TRBillDetail;

import com.xiaomi.mifi.payment.exception.PaymentGatewayResponseException;
import com.xiaomi.mifi.payment.model.PayResult;
import org.apache.commons.lang3.StringUtils;
import org.junit.Assert;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.w3c.dom.Document;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * MiCashPaymentGateway的集成测试
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:applicationContext.xml")
public class MiCashPaymentGatewayIntTest {

    private static final Logger LOGGER = LoggerFactory.getLogger(MiCashPaymentGatewayIntTest.class);

    @Autowired
    MiCashpayPaymentGateway gateway;

    @Test
    public void dummy() throws Exception {
        // 加个空的测试方法。如果没有test case，junit在运行时会报错。
    }

    //    @Test
    public void testQueryBill() throws Exception {
        String billDate = "2017-02-22";
        BillType type = BillType.OUTCOME;
        List<TRBillDetail> billList = gateway.queryBill(billDate, type);

        LOGGER.info("get bill list: {}", billList);
    }

    @Test
    public void parsePayNotify() throws Exception {
        HashMap<String, String> params = new HashMap<>();
        params.put("isSuccess", "T");
        params.put("partnerId", "1000003248");
        params.put("notifyType", "NOTIFY");
        params.put("outOrderId", "391721540855529472");
        params.put("tradeId", "20170509110542673001020300887444");
        params.put("payBank", "NOT_APPLICABLE");
        params.put("totalFee", "2222");
        params.put("orderDesc", "orderDesc3ZF6Q");
        params.put("payTime", "1494306037");
        params.put("tradeStatus", "TRADE_SUCCESS");
        params.put("errorCode", "200");
        params.put("sign","a5FNxTMEUIIxka_3IvhJrE8gwVeIkSfDdZyG5fD_j_Frr92Ex-31VRNVqQu0-YAOLYydRprJAn7jjSTMSQk41zVBJYpUKHFv6ay12OZDirDCyNXoPQcGAdRyaXJUEVeiOvsxBl3KnozKo1Y_dm5RJ9cltOm3WCM1L4Ifij7utQk.");
        PayResult payResult = gateway.parsePayNotify(params);
        Assert.assertEquals(ResponseStatus.STATUS_SUCCESS, payResult.getStatus());
    }

    @Test
    public void cashpayParseReturnUrl() throws Exception{
        Map<String, String> params = new HashMap<>();
        params.put("errorCode", "200");
        params.put("isSuccess", "T");
        params.put("notifyType", "RETURN");
        String orderDesc = URLDecoder
                .decode("%E6%B5%8B%E8%AF%95%E5%B7%A5%E5%85%B7%E5%B9%B3%E5%8F%B0%E4%B8%8B%E5%8D%95-vWaGVQEEbS", "UTF-8");
        params.put("orderDesc", orderDesc);
        params.put("outOrderId", "391770573697712128");
        params.put("partnerId", "1000003248");
        params.put("payBank", "NOT_APPLICABLE");
        params.put("payTime", "1494486165");
        params.put("totalFee", "1234");
        params.put("tradeId", "20170511150225061001020300880263");
        params.put("tradeStatus", "TRADE_SUCCESS");
        params.put("sign",
                "FqYR3q1CLQ6iZ-TWcMRlSLuLhQE3SBLXUfjwmz_dFa8yyVz_naM2KO3wPLLabBTBoqFHgii-m0WcLUD1VzrEhmHTKij5Yvf1tSIuaikmZ1nFvD4HHS304QZV6_PLl16RSQZIq4R42UVfHlm3_cKGaGww7ebyOLxhIT3piWw-2_Q.");
        boolean parseReturnUrl = gateway.parseReturnUrl(params);
        Assert.assertTrue(parseReturnUrl);
    }

    @Test
    public void testPay() throws PaymentGatewayResponseException, ServiceLogicException, IOException {
        Map<PaymentRequestParam, String> params = new HashMap<>();
        params.put(PaymentRequestParam.MERCHANT_TRANSACTION_ID, "30000");
        params.put(PaymentRequestParam.PAY_SUBJECT, "MiPad2");
        params.put(PaymentRequestParam.PAY_DESCRIPTION, "This is a pay request test");
        params.put(PaymentRequestParam.PAY_AMOUNT, "40000");
        params.put(PaymentRequestParam.NOTIFY_URL, "http://staging.m.pay.xiaomi.com/pay/notify");
        params.put(PaymentRequestParam.RETURN_URL, "http://staging.m.pay.xiaomi.com/pay/return");
        params.put(PaymentRequestParam.PAY_TIMEOUT, "30m");
        params.put(PaymentRequestParam.PAY_ALLOW_CREDIT_CARD, "true");

        String response = gateway.createPayRequest(params);
        Assert.assertNotNull(response);

        Map<String, String> responseParams = parsePayRequestUrl(response);
        Assert.assertEquals("30000", responseParams.get("outOrderId"));
        Assert.assertEquals("MiPad2", responseParams.get("productName"));
        Assert.assertEquals(URLEncoder.encode("This is a pay request test", "UTF-8"), responseParams.get("orderDesc"));
        Assert.assertEquals("40000", responseParams.get("totalFee"));
        Assert.assertEquals(URLEncoder.encode("http://staging.m.pay.xiaomi.com/pay/notify", "UTF-8"),
                responseParams.get("notifyUrl"));
        Assert.assertEquals(URLEncoder.encode("http://staging.m.pay.xiaomi.com/pay/return", "UTF-8"),
                responseParams.get("returnUrl"));
        Assert.assertEquals("30m", responseParams.get("expireTime"));
        Assert.assertEquals("CREDIT_CARD", responseParams.get("cardType"));
    }

    private Map<String, String> parsePayRequestUrl(String url) {
        Map<String, String> map = new HashMap<>();
        if (StringUtils.isEmpty(url)) {
            return map;
        }
        String[] tokens = StringUtils.split(url, "&");
        for (int i = 0; i < tokens.length; i++) {
            String[] token = StringUtils.split(tokens[i],"=");
            if (null != token && token.length == 2) {
                map.put(token[0], token[1]);
            }
        }
        return map;
    }

    public void testRefund() throws PaymentGatewayResponseException, ServiceLogicException, IOException, SAXException, ParserConfigurationException {

        String orderId = "391883036315877376";
        long refundFee = 1;
        String partnerRefundId = StringUtils.repeat("8763", 8);

        HashMap<RefundRequestParam, String> params = new HashMap<>();
        params.put(RefundRequestParam.OUTER_ORDER_ID, orderId);
        params.put(RefundRequestParam.OUTER_REQUEST_NO, partnerRefundId);
        params.put(RefundRequestParam.REFUND_AMOUNT, String.valueOf(refundFee));

        String response = gateway.createRefundRequest(params);
        Assert.assertNotNull(response);

        DocumentBuilder db = DocumentBuilderFactory.newInstance().newDocumentBuilder();
        Document doc = db.parse(new ByteArrayInputStream(response.getBytes()));

        String isSuccess = doc.getElementsByTagName("isSuccess").item(0).getTextContent();
        String responseCode = doc.getElementsByTagName("responseCode").item(0).getTextContent();
        if ("T".equals(isSuccess)) {// 数据库里面有相应的记录
            Assert.assertEquals("T", isSuccess);
            Assert.assertTrue("SUCCESS".equals(responseCode) || "APPLY_REFUND_MORE_THAN_ONCE_ERROR".equals(responseCode));
            String refundStatus = doc.getElementsByTagName("refundStatus").item(0).getTextContent();
            Assert.assertEquals("REFUND_SUCCESS", refundStatus);
        } else {// 数据库里面没有相应的记录
            Assert.assertEquals("F", isSuccess);
            Assert.assertEquals("CALL_SERVICE_FAILED", responseCode);
        }
    }
}
