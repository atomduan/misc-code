package com.xiaomi.mifi.payment.gateway;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.xiaomi.mifi.payment.model.CommitBindDeductRequest;
import com.xiaomi.mifi.payment.model.CommitBindDeductResult;
import com.xiaomi.mifi.payment.model.CommitDeductRequest;
import com.xiaomi.mifi.payment.thrift.BankCardType;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:applicationContext.xml")
public class MiCashPaymentGatewayDeductTest {

    private static final Logger LOGGER = LoggerFactory.getLogger(MiCashPaymentGatewayDeductTest.class);

    @Autowired
    MiCashpayPaymentGateway gateway;

    @Test
    public void createDeductSign() throws Exception {
        CommitBindDeductRequest request = new CommitBindDeductRequest();
        request.setBizType(1);
        request.setBankList("");
        request.setReturnUrl("http://www.baidu.com");
        request.setExtraInfo("");
        request.setProductName("小米保险");
        CommitBindDeductResult result = gateway.createDeductSign(request);
    }

    @Test
    public void commitDeduct() {
        try {
            CommitDeductRequest request = new CommitDeductRequest();
            request.setDeductId("20160624100043647016020300880023");
            request.setXiaomiId(4166015);
            request.setExpireTime(1000);
            request.setCardType(BankCardType.DEBIT_CARD);
            request.setTransactionId(1000000000009l);
            request.setOrderId(20000000002L);
            request.setProductName("小米保险");
            request.setTotalFee(1);
            request.setOrderDesc("小米");
            request.setNotifyURL("http://ins.staging.mifi.pt.xiaomi.com/api/notify/cashpay/deduct");
            gateway.commitDeduct(request);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
