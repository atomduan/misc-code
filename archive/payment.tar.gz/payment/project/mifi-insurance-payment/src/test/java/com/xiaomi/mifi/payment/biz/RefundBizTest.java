package com.xiaomi.mifi.payment.biz;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyLong;
import static org.mockito.Mockito.when;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import com.xiaomi.mifi.common.thrift.model.TRResponse;
import com.xiaomi.mifi.payment.dao.RefundDetailDAO;
import com.xiaomi.mifi.payment.thrift.RefundDetail;
import com.xiaomi.mifi.payment.thrift.TRTradeDetail;
import com.xiaomi.mifi.payment.thrift.TradeDetail;

/**
 * Created by mars on 17-4-27.
 */
@RunWith(MockitoJUnitRunner.class)
public class RefundBizTest {

    @InjectMocks
    private RefundBiz refundBiz;

    @Mock
    private RefundDetailDAO detailDAO;

    @Mock
    private TradeBiz tradeBiz;

    @Test
    public void testInsert() {
        when(detailDAO.insert(any(RefundDetail.class))).thenReturn(1L);
        RefundDetail refundDetail = new RefundDetail();
        refundDetail.setRefundTransactionId(123L);
        Assert.assertTrue(refundBiz.insertRefundDetail(refundDetail) > 0);
    }

    @Test
    public void testUpdate() {
        when(detailDAO.updateRefund(any(RefundDetail.class))).thenReturn(1);
        RefundDetail refundDetail = new RefundDetail();
        refundDetail.setRefundTransactionId(123L);
        Assert.assertTrue(refundBiz.updateRefundDetail(refundDetail) > 0);
    }

    @Test
    public void testFindByTransactionId() {
        when(detailDAO.findRefundDetailByRefundTransactionId(anyLong())).thenReturn(new RefundDetail());
        Assert.assertNotNull(refundBiz.findRefundByTransactionId(12345L));
    }

    @Test
    public void testFindByOrderId() {
        RefundDetail refundDetail = new RefundDetail();
        refundDetail.setOrderId(12345L);
        when(detailDAO.findByOrderId(anyLong())).thenReturn(refundDetail);
        Assert.assertNotNull(refundBiz.findRefundByOrderId(12345L));
    }

}
