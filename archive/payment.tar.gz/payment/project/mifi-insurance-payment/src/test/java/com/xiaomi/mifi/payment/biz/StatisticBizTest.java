package com.xiaomi.mifi.payment.biz;

import com.xiaomi.mifi.insurance.payment.thrift.PaymentStatistic;
import com.xiaomi.mifi.payment.dao.DailyStatisticDAO;
import com.xiaomi.mifi.payment.thrift.Channel;
import com.xiaomi.mifi.payment.thrift.TradeStatus;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import static org.mockito.Mockito.when;
import org.mockito.runners.MockitoJUnitRunner;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by mars on 17-5-27.
 */
@RunWith(MockitoJUnitRunner.class)
public class StatisticBizTest {
    private static final Logger LOGGER = LoggerFactory.getLogger(StatisticBizTest.class);

    @InjectMocks
    private StatisticBiz statisticBiz;

    @Mock
    private DailyStatisticDAO dao;

    @Test
    public void testInsert() {
        PaymentStatistic paymentStatistic = new PaymentStatistic();
        paymentStatistic.setDate("2017年5月25日");
        paymentStatistic.setChannel(Channel.ALIPAY.getValue());
        paymentStatistic.setResultType(TradeStatus.SUCCESS.getValue());
        paymentStatistic.setCount(8);
        when(dao.insert(paymentStatistic)).thenReturn(1L);
        PaymentStatistic paymentStatistic2 = new PaymentStatistic();
        paymentStatistic2.setDate("2017年5月25日");
        paymentStatistic2.setChannel(Channel.CASHPAY.getValue());
        paymentStatistic2.setResultType(TradeStatus.FAIL.getValue());
        paymentStatistic2.setCount(5);
        when(dao.insert(paymentStatistic2)).thenReturn(2L);
        List<PaymentStatistic> list = new ArrayList<>();
        list.add(paymentStatistic);
        list.add(paymentStatistic2);
        Assert.assertEquals(1, statisticBiz.reportDailyStatistic(paymentStatistic));
        Assert.assertEquals(2, statisticBiz.reportDailyStatistic(paymentStatistic2));
    }

    @Test
    public void testQuery() {
        PaymentStatistic paymentStatistic = new PaymentStatistic();
        paymentStatistic.setDate("2017年5月25日");
        paymentStatistic.setChannel(Channel.ALIPAY.getValue());
        paymentStatistic.setResultType(TradeStatus.SUCCESS.getValue());
        paymentStatistic.setCount(8);
        PaymentStatistic paymentStatistic2 = new PaymentStatistic();
        paymentStatistic2.setDate("2017年5月25日");
        paymentStatistic2.setChannel(Channel.CASHPAY.getValue());
        paymentStatistic2.setResultType(TradeStatus.FAIL.getValue());
        paymentStatistic2.setCount(5);
        List<PaymentStatistic> paymentStatistics = new ArrayList<>();
        paymentStatistics.add(paymentStatistic);
        paymentStatistics.add(paymentStatistic2);
        when(dao.queryByDate("2017年5月25日")).thenReturn(paymentStatistics);
        List<PaymentStatistic> list = statisticBiz.queryPaymentStatisticByDate("2017年5月25日");
        Assert.assertEquals(2, list.size());
        Assert.assertEquals(8, list.get(0).getCount());
    }
}
