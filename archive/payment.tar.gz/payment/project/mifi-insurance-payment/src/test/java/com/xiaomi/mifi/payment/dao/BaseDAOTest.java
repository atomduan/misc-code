package com.xiaomi.mifi.payment.dao;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

import javax.sql.DataSource;

import org.junit.After;
import org.junit.Before;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.DefaultResourceLoader;

public abstract class BaseDAOTest {

    @Autowired
    public DataSource dataSource;

    Connection conn;

    @Before
    public void setUp() throws Exception {
        try {
            conn = dataSource.getConnection();
            Statement st = conn.createStatement();
            st.execute("drop all objects;");
            if (System.getProperty("os.name", "Linux").toLowerCase().contains("win")) {
                st.execute("runscript from '"
                        + new DefaultResourceLoader().getResource("createTables.sql").getFile().getAbsolutePath()
                        + "'");
            } else {
                st.execute("runscript from '"
                        + new DefaultResourceLoader().getResource("createTables.sql").getURL().toString() + "'");

            }
            st.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @After
    public void tearDown() throws Exception {
        if (conn != null) {
            conn.close();
            conn = null;
        }
    }

}
