package com.xiaomi.mifi.payment.crypto;

import org.junit.Assert;
import org.junit.Test;

/**
 * Created by niqunhao on 17/2/9.
 */
public class SHA1WithRSASignatureTest {
    @Test
    public void testGetSignatureAlgorithm() {
        String expected = "SHA1WithRSA";
        SHA1WithRSASignature sHA1WithRSASignature = new SHA1WithRSASignature();
        Assert.assertEquals(expected, sHA1WithRSASignature.getSignatureAlgorithm());
    }
}