package com.xiaomi.mifi.payment.dao;

import com.xiaomi.mifi.insurance.payment.thrift.ChannelConfig;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.sql.ResultSet;
import java.sql.Statement;
import java.util.List;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:applicationContext.xml")
public class ChannelConfigDAOTest extends BaseDAOTest {

    @Autowired
    ChannelConfigDAO dao;

    @Override
    @Before
    public void setUp() throws Exception {
        super.setUp();

        try (Statement st = conn.createStatement()) {
            st.executeUpdate("INSERT INTO " + ChannelConfigDAO.TABLE_NAME + "(" + ChannelConfigDAO.INSERT_COLUMNS + ")VALUES(1,100,200,1,6,'推荐', 1)");
            st.executeUpdate("INSERT INTO " + ChannelConfigDAO.TABLE_NAME + "(" + ChannelConfigDAO.INSERT_COLUMNS + ")VALUES(1,200,300,1,6,'推荐', 1)");
            st.executeUpdate("INSERT INTO " + ChannelConfigDAO.TABLE_NAME + "(" + ChannelConfigDAO.INSERT_COLUMNS + ")VALUES(1,80,160,1,6,'推荐', 1)");
            st.executeUpdate("INSERT INTO " + ChannelConfigDAO.TABLE_NAME + "(" + ChannelConfigDAO.INSERT_COLUMNS + ")VALUES(1,600,900,1,6,'推荐', 1)");
            st.executeUpdate("INSERT INTO " + ChannelConfigDAO.TABLE_NAME + "(" + ChannelConfigDAO.INSERT_COLUMNS + ")VALUES(2,80,160,1,9,'推荐', 1)");
            st.executeUpdate("INSERT INTO " + ChannelConfigDAO.TABLE_NAME + "(" + ChannelConfigDAO.INSERT_COLUMNS + ")VALUES(1,600,800,2,6,'推荐', 1)");
        }
    }

    @Test
    public void insert() throws Exception {
        ChannelConfig one = new ChannelConfig();
        one.setChannelId(1);
        one.setStartTime(1000L);
        one.setEndTime(2000L);
        one.setTradeType(1);
        one.setSubtitle("推荐");
        one.setPriority(9);
        one.setSwitchOn(1);

        dao.insert(one);

        try (Statement st = conn.createStatement()) {
            ResultSet rs = st.executeQuery("SELECT " + ChannelConfigDAO.SELECT_COLUMNS + " FROM " + ChannelConfigDAO.TABLE_NAME + " WHERE id=7");
            Assert.assertTrue(rs.next());

            Assert.assertEquals(1L, rs.getLong("channel_id"));
            Assert.assertEquals(1000L, rs.getLong("start_time"));
            Assert.assertEquals(2000L, rs.getLong("end_time"));
            Assert.assertEquals(1, rs.getInt("trade_type"));
            Assert.assertEquals("推荐", rs.getString("subtitle"));
            Assert.assertEquals(9, rs.getInt("priority"));
            Assert.assertEquals(1, rs.getInt("switch_on"));
        }
    }

    @Test
    public void findByTradeTypeAndTime() throws Exception {
        List<ChannelConfig> ones = dao.findValidChannelsByTradeTypeAndTime(1, 110);
        Assert.assertEquals(3, ones.size());
        ChannelConfig one = ones.get(0);
        Assert.assertEquals(2, one.getChannelId());
        one = ones.get(1);
        Assert.assertEquals(1, one.getChannelId());
        Assert.assertEquals(100, one.getStartTime());
        one = ones.get(2);
        Assert.assertEquals(1, one.getChannelId());
        Assert.assertEquals(80, one.getStartTime());

        ones = dao.findValidChannelsByTradeTypeAndTime(2, 620);
        Assert.assertEquals(1, ones.size());

        one = ones.get(0);
        Assert.assertEquals(1, one.getChannelId());
        Assert.assertEquals(600L, one.getStartTime());
        Assert.assertEquals(800L, one.getEndTime());
        Assert.assertEquals(2, one.getTradeType());
        Assert.assertEquals(6, one.getPriority());
        Assert.assertEquals("推荐", one.getSubtitle());
    }

    @Test
    public void testFindChannelConfigs() {
        List<ChannelConfig> list = dao.findChannelConfigs();
        Assert.assertEquals(6, list.size());
        Assert.assertEquals(1, list.get(4).getSwitchOn());
    }

    @Test
    public void testUpdateChannel() {
        int row = dao.updateChannel(2, 0);
        Assert.assertTrue(row > 0);
        List<ChannelConfig> list = dao.findChannelConfigs();
        Assert.assertTrue(list.size() == 6);
        for (ChannelConfig channelConfig : list) {
            if (channelConfig.getChannelId() == 2) {
                Assert.assertEquals(0, channelConfig.getSwitchOn());
            }
        }
    }
}