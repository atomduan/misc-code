package com.xiaomi.mifi.payment.gateway;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;

import com.xiaomi.mifi.insurance.payment.thrift.BillType;
import com.xiaomi.mifi.insurance.payment.thrift.TRBillDetail;
import com.xiaomi.mifi.payment.crypto.MultiFieldsSignature;
import com.xiaomi.mifi.payment.util.download.CsvDownloadFileService;

import net.sf.json.JSONObject;

@RunWith(MockitoJUnitRunner.class)
public class AlipayPaymentGatewayQueryBillTest {
    @Mock
    MultiFieldsSignature merchantSignature;

    @InjectMocks
    CsvDownloadFileService csvDownloadFileService;

    Map<String, String> params = new HashMap<String, String>();

    @Before
    public void setup() throws Exception {
        MockitoAnnotations.initMocks(this);
    }

    @After
    public void teardown() throws Exception {
    }

    /**
     * Method: createQueryNewBillRequest(String billDate, BillType billType, String onestr, String twostr, String threestr, String fourstr)
     */
    @Test
    public void testCreateQueryNewBillRequest() throws Exception {
        String billDate = "2017-04-28";
        params.put("app_id", "2016080200151033");
        params.put("method", "alipay.data.dataservice.bill.downloadurl.query");
        params.put("format", "json");
        params.put("charset", "UTF-8");
        params.put("sign_type", "RSA2");
        params.put("timestamp", "2017-04-28");
        params.put("version", "1.0");

        Map<String, String> paramsRequest = new HashMap<String, String>();
        paramsRequest.put("bill_type", "signcustomer");
        paramsRequest.put("bill_date", billDate);
        JSONObject jsonObject = JSONObject.fromObject(paramsRequest);
        params.put("biz_content", jsonObject.toString());
        String sign = "UzUI9r7Sg42oZaFSc0vudcM3UJNM6lMv/JBpdJhzCbpLLSEYZwyc7+PSL/3RZu/zOLbH32EV5avp75LVhy/sRPpcJ7nzoigdzfvllMJfxsTXv+pnAnvoLFxpnZL3MzxZ5e4UP4JDB3oePAoxW399QuUgxNlxcyWZqmkoIq7Q9TRGFFhNpCIHjOswKUbBhbh+urW6yrIk451n7SRd1ipSOkKvRncPH2FjmMusoV2rHuIcwYHG5CmnKjB6KWm7TNqzhXzBzIbsHSJU3vOTEu93QEKhLIjf9HeJkUdGIaSgaK9AZWK5TfYHMLITqvg9WcGFGcIUnjl8jb9XNAbsweOSRw==";
        when(merchantSignature.sign(any(Map.class))).thenReturn(sign);
        merchantSignature.sign(params);
        params.put("sign", sign);
        verify(merchantSignature).sign(any(Map.class));
    }

    /**
     * Method: parseQueryNewBillResponse(String response, String billDate, BillType billType, String threestr, String fourstr)
     */
    @Test
    public void testParseQueryNewBillResponse() throws Exception {
        String billDate = "2017-04-29";
        String filePath = "/home/work/data/mifi-insurance-payment";
        String fileName = "20170429";
        String apiUrl = "http://dwbillcenter.alipaydev.com/downloadBillFile.resource?bizType=signcustomer&userId=20881021696083570156&fileType=csv.zip&bizDates=20170429&downloadFileName=20881021696083570156_20170429.csv.zip&fileId=%2Fsigncustomer%2F20881021696083570156%2F20170429.csv.zip&timestamp=1493701950&token=f8c744917b42f1de4f53952d69a27029";
        BillType billType = BillType.INCOME;
        ArrayList<TRBillDetail> ret = mock(ArrayList.class);
        csvDownloadFileService = mock(CsvDownloadFileService.class);
        when(csvDownloadFileService.getFilePath(anyString(), anyString())).thenReturn(filePath);
        when(csvDownloadFileService.getFileName(anyString())).thenReturn(fileName);
        csvDownloadFileService.downloadFile(anyString(), anyString(), anyString(), anyString());
        csvDownloadFileService.getFilePath(anyString(), anyString());
        csvDownloadFileService.getFileName(anyString());
        verify(csvDownloadFileService).getFilePath(anyString(), anyString());
        verify(csvDownloadFileService).getFileName(anyString());
        verify(csvDownloadFileService).downloadFile(anyString(), anyString(), anyString(), anyString());
    }

}
