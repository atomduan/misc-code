package com.xiaomi.mifi.payment.biz;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Matchers.anyLong;
import static org.mockito.Mockito.when;

import com.xiaomi.mifi.payment.proxy.BServiceProxy;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import com.xiaomi.mifi.common.thrift.model.TRResponse;
import com.xiaomi.mifi.payment.dao.NotifyDAO;
import com.xiaomi.mifi.payment.thrift.Notify;
import com.xiaomi.mifi.payment.thrift.TRTradeDetail;
import com.xiaomi.mifi.payment.thrift.TradeDetail;
import com.xiaomi.mifi.payment.thrift.TradeType;

/**
 * Created by mars on 17-4-27.
 */
@RunWith(MockitoJUnitRunner.class)
public class NotifyBizTest {

    @InjectMocks
    private NotifyBiz notifyBiz;

    @Mock
    private TradeBiz tradeBiz;

    @Mock
    private NotifyDAO notifyDAO;

    @Mock
    BServiceProxy bServiceProxy;

    @Test
    public void testInsert() {
        when(notifyDAO.insert(any(Notify.class))).thenReturn(1L);
        Notify notify = new Notify();
        notify.setNotifyId(123L);
        Assert.assertTrue(notifyBiz.insertNotify(notify) > 0);
    }

    @Test
    public void testUpdate() {
        when(notifyDAO.updateNotify(any(Notify.class))).thenReturn(1);
        Notify notify = new Notify();
        notify.setNotifyId(123L);
        Assert.assertTrue(notifyBiz.updateNotify(notify) > 0);
    }

    @Test
    public void testFind() {
        when(notifyDAO.findByNotifyId(anyInt())).thenReturn(new Notify());
        Assert.assertNotNull(notifyBiz.findNotifyByNotifyId(12345L));
    }

    @Test
    public void testFindNotifyByTransactionId() {
        when(notifyDAO.findByTransactionId(anyLong())).thenReturn(new Notify());
        Assert.assertNotNull(notifyBiz.findNotifyByTransactionId(12345L));
    }

    @Test
    public void testFindByOrderId() {
        TradeDetail tradeDetail = new TradeDetail();
        when(tradeBiz.queryPaymentInfo(anyLong())).thenReturn(tradeDetail);
        when(notifyDAO.findByTransactionIdAndTradeType(anyLong(), anyInt())).thenReturn(new Notify());
        Assert.assertNotNull(notifyBiz.findNotifyByOrderId(12345L, TradeType.PAY.getValue()));
    }
}
